@echo off
echo Iniciando Pixel Game Life...

REM Apenas executa o jogo existente (ja esta compilado)
if exist "PixelGameLife.exe" (
    echo Executando Pixel Game Life.exe...
    start "PixelGameLife" "PixelGameLife.exe"
    echo Jogo iniciado com sucesso!
) else (
    echo ERRO: PixelGameLife.exe nao encontrado!
    echo Execute o build completo primeiro.
    pause
)
