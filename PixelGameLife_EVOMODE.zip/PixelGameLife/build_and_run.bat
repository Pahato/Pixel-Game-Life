@echo off
REM Builds the project and runs the generated executable
echo Starting build process...
call "%~dp0build.bat"
if %ERRORLEVEL% neq 0 (
  echo Build failed, not launching.
  echo Fix the compilation errors above and try again.
  pause
  exit /b %ERRORLEVEL%
)
echo.
echo Build completed successfully!
echo Launching PixelGameLife.exe...
echo.
start "PixelGameLife" "%~dp0PixelGameLife.exe"
echo Game launched. You can close this window.
exit /b 0
