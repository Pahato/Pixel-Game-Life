@echo off
echo Atualizando Pixel Game Life...

REM Verifica se o jogo esta rodando
tasklist /FI "IMAGENAME" /NH | find /I "PixelGameLife.exe" >nul
if %ERRORLEVEL%==0 (
    echo Removendo executavel antigo...
    taskkill /F /IM "PixelGameLife.exe" /T 2 >nul
    timeout /T 2 /nobreak >nul
    if exist "PixelGameLife.exe" del "PixelGameLife.exe"
    if exist "PixelGameLife.exe" (
        echo Falha ao remover executavel antigo
        pause
        exit /b 1
    )
    echo Executavel antigo removido com sucesso.
)

REM Compila todos os arquivos fonte
echo Compilando arquivos fonte...
g++ -std=c++17 -O2 -Wall -Iinclude -Isrc ^
    src/Ambiente.cpp ^
    src/AssetManager.cpp ^
    src/CameraSystem.cpp ^
    src/Collision.cpp ^
    src/HatSystem.cpp ^
    src/LanguageSelector.cpp ^
    src/Localization.cpp ^
    src/Organismo.cpp ^
    src/ParticleSystem.cpp ^
    src/Populacao.cpp ^
    src/Shop.cpp ^
    src/Simulador.cpp ^
    src/SpeedManager.cpp ^
    src/Transition.cpp ^
    src/UIFont.cpp ^
    src/UISystem.cpp ^
    src/AchievementSystem.cpp ^
    -o PixelGameLife.exe ^
    -lraylib -lopengl32 -lgdi32 -lwinmm

if %ERRORLEVEL% neq 0 (
    echo Falha na compilacao - codigo de erro %ERRORLEVEL%
    pause
    exit /b %ERRORLEVEL%
)

echo Compilacao concluida com sucesso.
echo Novo executavel criado com sucesso.

REM Inicia o jogo
echo.
echo Iniciando Pixel Game Life...
echo.
PixelGameLife.exe

if %ERRORLEVEL% neq 0 (
    echo O jogo travou - codigo de erro %ERRORLEVEL%
    pause
)
