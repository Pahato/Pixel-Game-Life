#include "../include/AchievementSystem.h"
#include "Localization.h"
#include <algorithm>

// Static member definitions
std::vector<Achievement> AchievementSystem::s_achievements;
bool AchievementSystem::s_initialized = false;
int AchievementSystem::s_totalEnemiesKilled = 0;
int AchievementSystem::s_currentLevelEnemiesKilled = 0;

void AchievementSystem::initialize() {
    if (s_initialized) return;
    
    initializeDefaultAchievements();
    s_initialized = true;
}

void AchievementSystem::initializeDefaultAchievements() {
    s_achievements.clear();
    
    // Create default achievements
    s_achievements.push_back(Achievement("first_blood", Localization::getText("ach_first_blood"), Localization::getText("ach_first_blood_desc")));
    s_achievements.push_back(Achievement("survivor", Localization::getText("ach_survivor"), Localization::getText("ach_survivor_desc")));
    s_achievements.push_back(Achievement("level_10", Localization::getText("ach_level_10"), Localization::getText("ach_level_10_desc")));
    s_achievements.push_back(Achievement("level_25", Localization::getText("ach_level_25"), Localization::getText("ach_level_25_desc")));
    s_achievements.push_back(Achievement("predator", Localization::getText("ach_predator"), Localization::getText("ach_predator_desc")));
    s_achievements.push_back(Achievement("speed_demon", Localization::getText("ach_speed_demon"), Localization::getText("ach_speed_demon_desc")));
    s_achievements.push_back(Achievement("tank", Localization::getText("ach_tank"), Localization::getText("ach_tank_desc")));
    s_achievements.push_back(Achievement("perfectionist", Localization::getText("ach_perfectionist"), Localization::getText("ach_perfectionist_desc")));
}

void AchievementSystem::checkAchievements(int level, int score, int enemiesKilled, float timeAlive) {
    if (!s_initialized) return;
    
    // Update enemy kill counters
    s_totalEnemiesKilled += enemiesKilled;
    s_currentLevelEnemiesKilled += enemiesKilled;
    
    // Check first kill achievement
    if (s_totalEnemiesKilled >= 1 && !s_achievements[0].unlocked) {
        s_achievements[0].unlocked = true;
    }
    
    // Check survivor achievement (survive 5 minutes)
    if (timeAlive >= 300.0f && !s_achievements[1].unlocked) {
        s_achievements[1].unlocked = true;
    }
    
    // Check level achievements
    if (level >= 10 && !s_achievements[2].unlocked) {
        s_achievements[2].unlocked = true;
    }
    if (level >= 25 && !s_achievements[3].unlocked) {
        s_achievements[3].unlocked = true;
    }
    
    // Check predator achievement (kill 100 enemies)
    if (s_totalEnemiesKilled >= 100 && !s_achievements[4].unlocked) {
        s_achievements[4].unlocked = true;
    }
    
    // Check speed demon achievement (reach level 10 in under 2 minutes)
    if (level >= 10 && timeAlive < 120.0f && !s_achievements[5].unlocked) {
        s_achievements[5].unlocked = true;
    }
    
    // Check tank achievement (reach radius 50)
    if (score >= 50 && !s_achievements[6].unlocked) {
        s_achievements[6].unlocked = true;
    }
    
    // Check perfectionist achievement (complete level without taking damage)
    if (s_currentLevelEnemiesKilled >= 10 && !s_achievements[7].unlocked) {
        s_achievements[7].unlocked = true;
    }
}

const std::vector<Achievement>& AchievementSystem::getAchievements() {
    return s_achievements;
}

int AchievementSystem::getUnlockedCount() {
    int count = 0;
    for (const auto& ach : s_achievements) {
        if (ach.unlocked) count++;
    }
    return count;
}

void AchievementSystem::reset() {
    s_totalEnemiesKilled = 0;
    s_currentLevelEnemiesKilled = 0;
    for (auto& ach : s_achievements) {
        ach.unlocked = false;
    }
}
