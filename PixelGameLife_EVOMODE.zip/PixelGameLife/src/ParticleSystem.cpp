#include "../include/ParticleSystem.h"
#include <algorithm>

// Static member definitions
std::vector<Particle> ParticleSystem::s_particles;
bool ParticleSystem::s_initialized = false;

void ParticleSystem::initialize() {
    s_particles.clear();
    s_initialized = true;
}

void ParticleSystem::spawnParticles(float x, float y, int count, int r, int g, int b, int a) {
    if (!s_initialized) return;
    
    for (int i = 0; i < count; i++) {
        Particle p;
        p.x = x + GetRandomValue(-6, 6);
        p.y = y + GetRandomValue(-6, 6);
        p.vx = ((float)(rand() % 100 - 50)) / 50.0f;
        p.vy = ((float)(rand() % 100 - 50)) / 50.0f;
        p.life = 0.0f;
        p.maxLife = 0.5f + (float)(rand() % 100) / 100.0f;
        p.r = r;
        p.g = g;
        p.b = b;
        p.a = a;
        s_particles.push_back(p);
    }
}

void ParticleSystem::spawnEnemyParticles(float x, float y, int r, int g, int b) {
    if (!s_initialized) return;
    
    for (int i = 0; i < 5; i++) {
        Particle p;
        p.x = x + GetRandomValue(-3, 3);
        p.y = y + GetRandomValue(-3, 3);
        p.vx = ((float)(rand() % 100 - 50)) / 100.0f;
        p.vy = ((float)(rand() % 100 - 50)) / 100.0f;
        p.life = 0.0f;
        p.maxLife = 0.3f + (float)(rand() % 50) / 100.0f;
        p.r = r;
        p.g = g;
        p.b = b;
        p.a = 255;
        s_particles.push_back(p);
    }
}

void ParticleSystem::update(float deltaTime) {
    if (!s_initialized) return;
    
    for (auto &p : s_particles) {
        p.x += p.vx * deltaTime;
        p.y += p.vy * deltaTime;
        p.vx *= 0.98f;
        p.vy *= 0.98f;
        p.life += deltaTime * 1.0f;
    }
    
    // Remove dead particles
    s_particles.erase(
        std::remove_if(s_particles.begin(), s_particles.end(), 
            [](const Particle& p) { return p.life >= p.maxLife; }),
        s_particles.end()
    );
}

void ParticleSystem::draw() {
    if (!s_initialized) return;
    
    for (const auto& p : s_particles) {
        float alpha = 1.0f - (p.life / p.maxLife);
        Color col = {(unsigned char)p.r, (unsigned char)p.g, (unsigned char)p.b, (unsigned char)(p.a * alpha)};
        float particleSize = 2.0f * (1.0f - p.life / p.maxLife) + 1.5f;
        if (particleSize >= 1.5f) {
            DrawCircle((int)p.x, (int)p.y, particleSize, col);
        }
    }
}

void ParticleSystem::clear() {
    if (!s_initialized) return;
    s_particles.clear();
}

size_t ParticleSystem::getParticleCount() {
    return s_particles.size();
}
