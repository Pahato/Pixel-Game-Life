#include "../include/AssetManager.h"
#include <filesystem>
#include <iostream>

// Static member definitions
std::unordered_map<std::string, Texture2D> AssetManager::s_sprites;
bool AssetManager::s_initialized = false;

void AssetManager::initialize() {
    if (s_initialized) return;
    
    initializeSpriteMappings();
    s_initialized = true;
}

void AssetManager::initializeSpriteMappings() {
    printf("[DEBUG] Initializing sprite mappings...\n");
    
    // Player sprites
    loadSprite("player", "c:/Users/rodri/Desktop/PixelGameLife/Sprites/Player_sprite.png");
    
    // Enemy sprites - Infinite Mode
    loadSprite("enemy_dangerous", "c:/Users/rodri/Desktop/PixelGameLife/Sprites/InfiniteModeDangerousEnemy_sprite.png");
    loadSprite("enemy_safe", "c:/Users/rodri/Desktop/PixelGameLife/Sprites/InfiniteModeNonDangerousEnemy_sprite.png");
    
    // Enemy sprites - Evolution Mode
    loadSprite("enemy_tank", "c:/Users/rodri/Desktop/PixelGameLife/Sprites/TankEnemyEvolutionMode_sprite.png");
    
    // Projectile sprites
    loadSprite("projectile", "c:/Users/rodri/Desktop/PixelGameLife/Sprites/Projetil_sprite.png");
    loadSprite("projectile_multishot", "c:/Users/rodri/Desktop/PixelGameLife/Sprites/MultishotsSameAsNormalProjectileJustSpamItAsMultiShotGetsEvolved_sprite.png");
    
    // Effect sprites
    loadSprite("explosion", "c:/Users/rodri/Desktop/PixelGameLife/Sprites/ExplosiveKills_sprite.png");
    loadSprite("frost_field", "c:/Users/rodri/Desktop/PixelGameLife/Sprites/FrostField_sprite.png");
    loadSprite("black_hole", "c:/Users/rodri/Desktop/PixelGameLife/Sprites/BlackHole_sprite.png");
    loadSprite("chain_lightning", "c:/Users/rodri/Desktop/PixelGameLife/Sprites/ChainLighting_sprite.png");
    loadSprite("cone_blast", "c:/Users/rodri/Desktop/PixelGameLife/Sprites/ConeBlast_sprite.png");
    
    // Ability sprites
    loadSprite("energy_shield", "c:/Users/rodri/Desktop/PixelGameLife/Sprites/EnergyShieldChangeThePlayerSpriteForThis_sprite.png");
    
    // Environment sprites
    loadSprite("meteor", "c:/Users/rodri/Desktop/PixelGameLife/Sprites/MeteorStrike_sprite.png");
    
    // Orbital blade upgrade sprites
    loadSprite("orbital_blades_0", "c:/Users/rodri/Desktop/PixelGameLife/Sprites/OrbitBladesUpgradeZero_sprite.png");
    loadSprite("orbital_blades_1", "c:/Users/rodri/Desktop/PixelGameLife/Sprites/OrbitBladesUpgradeOne_sprite.png");
    loadSprite("orbital_blades_2", "c:/Users/rodri/Desktop/PixelGameLife/Sprites/OrbitalBladesUpgradeTwo_sprite.png");
    loadSprite("orbital_blades_3", "c:/Users/rodri/Desktop/PixelGameLife/Sprites/OrbitalBladesUpgradeThree_sprite.png");
    loadSprite("orbital_blades_4", "c:/Users/rodri/Desktop/PixelGameLife/Sprites/OrbitalBladesUpgradeFour_sprite.png");
    loadSprite("orbital_blades_5", "c:/Users/rodri/Desktop/PixelGameLife/Sprites/OrbitalBladesUpgradeFive_sprite.png");
    loadSprite("orbital_blades_6", "c:/Users/rodri/Desktop/PixelGameLife/Sprites/OrbitalBladesUpgradeSix_sprite.png");
    
    // Other ability sprites
    loadSprite("overload", "c:/Users/rodri/Desktop/PixelGameLife/Sprites/Overload_sprite.png");
    loadSprite("repulsion_pulse", "c:/Users/rodri/Desktop/PixelGameLife/Sprites/RepulsionPulse_sprite.png");
    loadSprite("ricochet_shots", "c:/Users/rodri/Desktop/PixelGameLife/Sprites/RicochetShots_sprite.png");
    
    printf("[DEBUG] Sprite initialization complete. Total sprites loaded: %d\n", (int)s_sprites.size());
}

bool AssetManager::loadSprite(const std::string& key, const std::string& filename) {
    if (s_sprites.find(key) != s_sprites.end()) {
        printf("[DEBUG] Sprite %s already loaded\n", key.c_str());
        return true; // Already loaded
    }
    
    printf("[DEBUG] Loading sprite: %s from %s\n", key.c_str(), filename.c_str());
    Texture2D texture = LoadTexture(filename.c_str());
    if (texture.id > 0) {
        s_sprites[key] = texture;
        printf("[DEBUG] Successfully loaded sprite: %s (id: %d, w: %d, h: %d)\n", key.c_str(), texture.id, texture.width, texture.height);
        return true;
    } else {
        printf("[DEBUG] FAILED to load sprite: %s from %s\n", key.c_str(), filename.c_str());
    }
    
    return false;
}

Texture2D AssetManager::getSprite(const std::string& key) {
    auto it = s_sprites.find(key);
    if (it != s_sprites.end()) {
        printf("[DEBUG] Found sprite: %s (id: %d)\n", key.c_str(), it->second.id);
        return it->second;
    }
    
    printf("[DEBUG] MISSING sprite: %s\n", key.c_str());
    // Return empty texture if not found
    static Texture2D emptyTexture = { 0 };
    return emptyTexture;
}

bool AssetManager::hasSprite(const std::string& key) {
    bool found = s_sprites.find(key) != s_sprites.end();
    printf("[DEBUG] hasSprite(%s): %s\n", key.c_str(), found ? "true" : "false");
    return found;
}

Color AssetManager::getFallbackColor(const std::string& key) {
    // Return appropriate fallback colors for missing sprites
    if (key.find("player") != std::string::npos) return BLACK;
    if (key.find("enemy") != std::string::npos) return RED;
    if (key.find("projectile") != std::string::npos) return YELLOW;
    if (key.find("explosion") != std::string::npos) return ORANGE;
    if (key.find("frost") != std::string::npos) return SKYBLUE;
    if (key.find("shield") != std::string::npos) return GREEN;
    if (key.find("black_hole") != std::string::npos) return PURPLE;
    if (key.find("lightning") != std::string::npos) return WHITE;
    if (key.find("cone") != std::string::npos) return GOLD;
    if (key.find("meteor") != std::string::npos) return GRAY;
    
    return WHITE; // Default fallback
}

void AssetManager::cleanup() {
    for (auto& pair : s_sprites) {
        UnloadTexture(pair.second);
    }
    s_sprites.clear();
    s_initialized = false;
}
