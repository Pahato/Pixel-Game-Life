#include "../include/LanguageSelector.h"
#include "../include/Localization.h"

// Static member definitions
bool LanguageSelector::s_visible = false;

// Flag color definitions (simplified geometric representations)
const int LanguageSelector::ENGLISH_FLAG_COLOR[] = {255, 255, 255, 255, 0, 0, 0, 255}; // White background, Red cross
const int LanguageSelector::PORTUGUESE_FLAG_COLOR[] = {0, 128, 0, 255, 255, 0, 0, 255}; // Green background, Red vertical band

void LanguageSelector::update() {
    // Language selector doesn't need per-frame updates
}

void LanguageSelector::draw() {
    if (!s_visible) return;
    
    // Use real window dimensions
    int windowWidth = GetScreenWidth();
    int windowHeight = GetScreenHeight();
    
    // Position flags in bottom-right corner of window
    int englishX = windowWidth - FLAG_SIZE * 2 - PADDING * 3;
    int portugueseX = windowWidth - FLAG_SIZE - PADDING;
    int flagY = windowHeight - FLAG_SIZE - PADDING;
    
    // Draw English flag (simplified - white with red cross)
    drawFlag(englishX, flagY, true);
    
    // Draw Portuguese flag (simplified - blue/green vertical)
    drawFlag(portugueseX, flagY, false);
    
    // Highlight current language
    Language current = Localization::getCurrentLanguage();
    int highlightX = (current == LANG_ENGLISH) ? englishX : portugueseX;
    DrawRectangleLines(highlightX - 2, flagY - 2, FLAG_SIZE + 4, FLAG_SIZE + 4, YELLOW);
}

void LanguageSelector::handleInput() {
    if (!s_visible) return;
    
    if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
        // Use real window dimensions
        int windowWidth = GetScreenWidth();
        int windowHeight = GetScreenHeight();
        
        // Calculate flag positions using real window coordinates
        int englishX = windowWidth - FLAG_SIZE * 2 - PADDING * 3;
        int portugueseX = windowWidth - FLAG_SIZE - PADDING;
        int flagY = windowHeight - FLAG_SIZE - PADDING;
        
        // Get mouse position
        Vector2 mousePos = GetMousePosition();
        
        // Check English flag click
        if (mousePos.x >= englishX && mousePos.x <= englishX + FLAG_SIZE &&
            mousePos.y >= flagY && mousePos.y <= flagY + FLAG_SIZE) {
            Localization::setLanguage(LANG_ENGLISH);
        }
        
        // Check Portuguese flag click
        if (mousePos.x >= portugueseX && mousePos.x <= portugueseX + FLAG_SIZE &&
            mousePos.y >= flagY && mousePos.y <= flagY + FLAG_SIZE) {
            Localization::setLanguage(LANG_PORTUGUESE);
        }
    }
}

void LanguageSelector::drawFlag(int x, int y, bool isEnglish) {
    if (isEnglish) {
        // English flag: white background with red cross
        DrawRectangle(x, y, FLAG_SIZE, FLAG_SIZE, WHITE);
        // Red cross (simplified)
        DrawRectangle(x + FLAG_SIZE/3, y, FLAG_SIZE/3, FLAG_SIZE, RED);
        DrawRectangle(x, y + FLAG_SIZE/3, FLAG_SIZE, FLAG_SIZE/3, RED);
    } else {
        // Portuguese flag: green background with red vertical band
        DrawRectangle(x, y, FLAG_SIZE, FLAG_SIZE, (Color){0, 128, 0, 255}); // Green background
        DrawRectangle(x + FLAG_SIZE/2, y, FLAG_SIZE/2, FLAG_SIZE, (Color){255, 0, 0, 255}); // Red band
    }
}

bool LanguageSelector::isFlagClicked(int x, int y, int mouseX, int mouseY) {
    return mouseX >= x && mouseX <= x + FLAG_SIZE &&
           mouseY >= y && mouseY <= y + FLAG_SIZE;
}

void LanguageSelector::setVisible(bool visible) {
    s_visible = visible;
}

bool LanguageSelector::isVisible() {
    return s_visible;
}
