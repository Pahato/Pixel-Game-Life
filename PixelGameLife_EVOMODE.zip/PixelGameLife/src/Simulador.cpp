#include "../include/Simulador.h"
#include <random>
#include <algorithm>
#include <string>
#include <cmath>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <vector>
#include "raylib.h"

// Speed management functions (to avoid circular dependency)
int getValidSpeedIndex(int requestedIndex, int currentMode) {
    const int MODE_INFINITE = 0;
    const int MODE_EVOLUTION = 1;
    
    if (currentMode == MODE_EVOLUTION) {
        // Evolution mode: only allow 1x (index 1) and 2x (index 2)
        return (requestedIndex >= 1 && requestedIndex <= 2) ? requestedIndex : 1;
    }
    // Infinite mode: allow all speeds (0, 1, 2)
    return (requestedIndex >= 0 && requestedIndex <= 2) ? requestedIndex : 1;
}

int clampSpeedIndex(int index, int minIndex, int maxIndex) {
    if (index < minIndex) return minIndex;
    if (index > maxIndex) return maxIndex;
    return index;
}

Simulador::Simulador(int w,int h): width(WORLD_W), height(WORLD_H), windowWidth(w), windowHeight(h), running(true), currentSpeedIndex(1), menuTimer(0.0f), timeAlive(0.0f) {
    // Initialize asset manager first
    AssetManager::initialize();
    
    // Initialize localization system
    Localization::initialize();
    
    // Set different initial population based on mode
    initialPopulation = (currentMode == Evolution) ? 60 : 20; // Larger map for Evolution Mode
    
    // Use appropriate world dimensions for initialization
    int initWidth = WORLD_W;
    int initHeight = WORLD_H;
    
    pop.inicializar(initialPopulation, initWidth, initHeight);
    showMenu = true;
    showOptions = false;
    showTutorial = false;
    pauseMenu = false;
    
    // Initialize player with sprite key
    player.radius = 12.0f;
    player.score = 0;
    player.x = WORLD_W / 2.0f;
    player.y = WORLD_H / 2.0f;
    player.spriteKey = "player"; // Set player sprite key
    gameOver = false;
    isFullscreen = false;
    nivel = 1;
    nivelMeta = 5;
    levelUpAnimating = false;
    levelUpTimer = 0.0f;
    levelUpDuration = 1.8f;
    playerHighlightActive = false;
    playerHighlightTimer = 0.0f;
    playerHighlightDuration = 2.0f;
    // Use appropriate world dimensions for ambient initialization
    int ambWidth = WORLD_W;
    int ambHeight = WORLD_H;
    
    amb.gerarNivel(nivel, ambWidth, ambHeight);
    
    bgOffset = 0.0f;
    screenShake = 0.0f;
    screenShakeTimer = 0.0f;
    debugHitboxes = false;  // Set to true to enable hitbox visualization
    
    // Initialize biome system
    currentBiome = NONE;
    biomeEnemySpeedMultiplier = 1.0f;
    biomeBackgroundColor = BLACK;
    
    // Random biome selection for Infinite Mode (10% chance)
    if (currentMode == Infinite) {
        float biomeRoll = (float)rand() / RAND_MAX;
        if (biomeRoll < 0.10f) {
            int biomeChoice = rand() % 3;
            switch (biomeChoice) {
                case 0:
                    currentBiome = BLOODSTREAM;
                    biomeEnemySpeedMultiplier = 1.2f;
                    biomeBackgroundColor = (Color){20, 5, 10, 255};
                    break;
                case 1:
                    currentBiome = TISSUE;
                    biomeEnemySpeedMultiplier = 0.8f;
                    biomeBackgroundColor = (Color){10, 15, 5, 255};
                    break;
                case 2:
                    currentBiome = NEURAL;
                    biomeEnemySpeedMultiplier = 1.0f;
                    biomeBackgroundColor = (Color){5, 10, 20, 255};
                    break;
            }
        }
    }
    
    // Initialize Evolution Mode state
    currentMode = Infinite;
    evolution.isActive = false;
    evolution.runStartTime = 0.0f;
    evolution.survivalTime = 0.0f;
    evolution.enemiesKilled = 0;
    evolution.xpCollected = 0;
    evolution.playerLevel = 1;
    evolution.currentWave = 1;
    evolution.nextDifficultyTime = 30.0f;
    evolution.difficultyMultiplier = 1.0f;
    evolution.upgradeMenuVisible = false;
    evolution.selectedUpgradeIndex = 0;
    evolution.currentUpgrades.clear();
    evolution.currentUpgradeChoices.clear();
    
    // Initialize active skill states
    for (int i = 0; i < UPGRADE_TYPE_COUNT; i++) evolution.skillLevel[i] = 0;
    evolution.orbitAngle = 0.0f;
    evolution.coneBlastTimer = 0.0f;
    evolution.coneBlastAngle = 0.0f;
    evolution.shieldUp = false;
    evolution.shieldRechargeTimer = 0.0f;
    evolution.repulsionTimer = 0.0f;
    evolution.blackHoleTimer = 0.0f;
    evolution.blackHoleX = 0.0f;
    evolution.blackHoleY = 0.0f;
    evolution.blackHoleLife = 0.0f;
    evolution.blackHoleActive = false;
    evolution.meteorTimer = 0.0f;
    evolution.overloadTimer = 0.0f;
    
    
    // Initialize boss system
    evolution.enemiesInWave = 12; // Start with more enemies
    evolution.enemiesSpawned = 0;
    
    showOptions = false;
    menuSelection = 0;
    pauseSelection = 0;
    optionsSelection = 0;
    menuTimer = 0.0f;
    menuInputCooldown = 0.0f;
    firstSpawnDone = false;
    
    // Initialize achievements scrolling
    achievementsScrollOffset = 0;
    maxAchievementsVisible = 8;
    
    // Initialize achievements
    achievements.push_back(Achievement("kill_10_antibodies", Localization::getText("ach_kill_10_antibodies"), Localization::getText("ach_kill_10_antibodies_desc")));
    achievements.push_back(Achievement("kill_50_antibodies", Localization::getText("ach_kill_50_antibodies"), Localization::getText("ach_kill_50_antibodies_desc")));
    achievements.push_back(Achievement("reach_level_5", Localization::getText("ach_reach_level_5"), Localization::getText("ach_reach_level_5_desc")));
    achievements.push_back(Achievement("reach_level_10", Localization::getText("ach_reach_level_10"), Localization::getText("ach_reach_level_10_desc")));
    achievements.push_back(Achievement("reach_level_20", Localization::getText("ach_reach_level_20"), Localization::getText("ach_reach_level_20_desc")));
    achievements.push_back(Achievement("collect_100_xp", Localization::getText("ach_collect_100_xp"), Localization::getText("ach_collect_100_xp_desc")));
    achievements.push_back(Achievement("grow_large", Localization::getText("ach_grow_large"), Localization::getText("ach_grow_large_desc")));
    achievements.push_back(Achievement("survive_60s", Localization::getText("ach_survive_60s"), Localization::getText("ach_survive_60s_desc")));
    
    // New achievements
    achievements.push_back(Achievement("reach_level_15", Localization::getText("ach_reach_level_15"), Localization::getText("ach_reach_level_15_desc")));
    achievements.push_back(Achievement("reach_level_25", Localization::getText("ach_reach_level_25"), Localization::getText("ach_reach_level_25_desc")));
    achievements.push_back(Achievement("reach_level_30", Localization::getText("ach_reach_level_30"), Localization::getText("ach_reach_level_30_desc")));
    achievements.push_back(Achievement("survive_120s", Localization::getText("ach_survive_120s"), Localization::getText("ach_survive_120s_desc")));
    achievements.push_back(Achievement("survive_300s", Localization::getText("ach_survive_300s"), Localization::getText("ach_survive_300s_desc")));
    achievements.push_back(Achievement("reach_radius_30", Localization::getText("ach_reach_radius_30"), Localization::getText("ach_reach_radius_30_desc")));
    achievements.push_back(Achievement("reach_radius_60", Localization::getText("ach_reach_radius_60"), Localization::getText("ach_reach_radius_60_desc")));
    achievements.push_back(Achievement("reach_radius_100", Localization::getText("ach_reach_radius_100"), Localization::getText("ach_reach_radius_100_desc")));
    achievements.push_back(Achievement("eat_5_enemies", Localization::getText("ach_eat_5_enemies"), Localization::getText("ach_eat_5_enemies_desc")));
    achievements.push_back(Achievement("eat_25_enemies", Localization::getText("ach_eat_25_enemies"), Localization::getText("ach_eat_25_enemies_desc")));
    achievements.push_back(Achievement("eat_100_enemies", Localization::getText("ach_eat_100_enemies"), Localization::getText("ach_eat_100_enemies_desc")));
    achievements.push_back(Achievement("collect_250_xp", Localization::getText("ach_collect_250_xp"), Localization::getText("ach_collect_250_xp_desc")));
    achievements.push_back(Achievement("collect_500_xp", Localization::getText("ach_collect_500_xp"), Localization::getText("ach_collect_500_xp_desc")));
    achievements.push_back(Achievement("complete_skin", Localization::getText("ach_complete_skin"), Localization::getText("ach_complete_skin_desc")));
    achievements.push_back(Achievement("complete_tissues", Localization::getText("ach_complete_tissues"), Localization::getText("ach_complete_tissues_desc")));
    achievements.push_back(Achievement("complete_bloodstream", Localization::getText("ach_complete_bloodstream"), Localization::getText("ach_complete_bloodstream_desc")));
    achievements.push_back(Achievement("complete_brain", Localization::getText("ach_complete_brain"), Localization::getText("ach_complete_brain_desc")));
    
    // Session-only achievements: do not load from disk
}

void Simulador::fireBasicAttack() {
    // Find nearest enemy
    Enemy* nearestEnemy = nullptr;
    float nearestDist = 9999.0f;
    
    for (auto &e : enemies) {
        if (!e.alive) continue;
        float dx = e.x - player.x;
        float dy = e.y - player.y;
        float dist = sqrtf(dx*dx + dy*dy);
        if (dist < nearestDist) {
            nearestDist = dist;
            nearestEnemy = &e;
        }
    }
    
    if (nearestEnemy && nearestDist < 300.0f) {
        // Calculate direction to enemy
        float dx = nearestEnemy->x - player.x;
        float dy = nearestEnemy->y - player.y;
        float dist = sqrtf(dx*dx + dy*dy);
        float dirX = dx / dist;
        float dirY = dy / dist;
        
        // Track facing direction for cone blast
        evolution.coneBlastAngle = atan2f(dirY, dirX);
        
        if (evolution.skillLevel[MULTISHOT]) {
            // Level-scaled multishot: 3/4/5/6/7 projectiles
            int msLevel = evolution.skillLevel[MULTISHOT];
            int projCount = 2 + msLevel; // 3,4,5,6,7
            float totalSpread = 0.2f + msLevel * 0.08f; // wider spread at higher levels
            float baseAngle = atan2f(dirY, dirX);
            
            for (int i = 0; i < projCount; i++) {
                float t = (projCount > 1) ? (float)i / (projCount - 1) - 0.5f : 0.0f;
                float angle = baseAngle + t * totalSpread * 2.0f;
                float vx = cosf(angle) * 400.0f;
                float vy = sinf(angle) * 400.0f;
                projectiles.push_back({
                    player.x, player.y, vx, vy, 4.0f, 1, true, YELLOW, false, "projectile_multishot"
                });
            }
        } else {
            // Single shot
            float vx = dirX * 400.0f;
            float vy = dirY * 400.0f;
            projectiles.push_back({
                player.x, player.y, vx, vy, 4.0f, 1, true, YELLOW, false, "projectile"
            });
        }
        
        // Create firing effect
        visualEffects.push_back({
            player.x, player.y, 0.0f, 20.0f, 0.0f, 0.2f, YELLOW, 2, ""
        });
    }
}

void Simulador::updateProjectiles(float deltaTime) {
    for (auto &p : projectiles) {
        if (!p.alive) continue;
        
        // Update position
        p.x += p.vx * deltaTime;
        p.y += p.vy * deltaTime;
        
        // Check if projectile is out of bounds
        if (p.x < 0 || p.x > WORLD_W || p.y < 0 || p.y > WORLD_H) {
            p.alive = false;
            continue;
        }
        
        // Check collision with enemies
        for (auto &e : enemies) {
            if (!e.alive) continue;
            float dx = p.x - e.x;
            float dy = p.y - e.y;
            float dist = sqrtf(dx*dx + dy*dy);
            if (dist < p.radius + e.radius) {
                e.hp -= p.damage;
                e.hitFlashTimer = 0.2f;
                
                // Chain Lightning: on hit, chain to nearby enemies
                if (evolution.skillLevel[CHAIN_LIGHTNING]) {
                    int clLvl = evolution.skillLevel[CHAIN_LIGHTNING];
                    float chainX = e.x;
                    float chainY = e.y;
                    int chainDmg = 1 + clLvl; // 2,3,4,5,6
                    int maxJumps = 2 + clLvl;  // 3,4,5,6,7
                    float chainRange = 80.0f + clLvl * 15.0f; // wider chain range
                    std::vector<int> chained;
                    int hitIdx = (int)(&e - &enemies[0]);
                    chained.push_back(hitIdx);
                    
                    for (int jump = 0; jump < maxJumps; jump++) {
                        float bestDist = chainRange;
                        int bestIdx = -1;
                        for (int ei = 0; ei < (int)enemies.size(); ei++) {
                            if (!enemies[ei].alive) continue;
                            bool already = false;
                            for (int ci : chained) { if (ci == ei) { already = true; break; } }
                            if (already) continue;
                            float cdx = enemies[ei].x - chainX;
                            float cdy = enemies[ei].y - chainY;
                            float cdist = sqrtf(cdx*cdx + cdy*cdy);
                            if (cdist < bestDist) {
                                bestDist = cdist;
                                bestIdx = ei;
                            }
                        }
                        if (bestIdx >= 0) {
                            // Draw chain segment
                            chainSegments.push_back({ chainX, chainY, enemies[bestIdx].x, enemies[bestIdx].y, 0.4f });
                            enemies[bestIdx].hp -= chainDmg;
                            enemies[bestIdx].hitFlashTimer = 0.2f;
                            if (enemies[bestIdx].hp <= 0) {
                                enemies[bestIdx].alive = false;
                                evolution.enemiesKilled++;
                                int xpReward = 1;
                                if (enemies[bestIdx].isBoss) xpReward = 20 + evolution.currentWave * 5;
                                else { switch (enemies[bestIdx].enemyType) { case 0: xpReward = 1; break; case 1: xpReward = 3; break; case 2: xpReward = 5; break; }}
                                player.score += xpReward;
                                // Explosive kills chain from chain lightning kills
                                if (evolution.skillLevel[EXPLOSIVE_KILLS]) {
                                    int exLvl2 = evolution.skillLevel[EXPLOSIVE_KILLS];
                                    float exRad2 = 50.0f + exLvl2 * 12.0f;
                                    int exDmg2 = 2 + exLvl2;
                                    visualEffects.push_back({ enemies[bestIdx].x, enemies[bestIdx].y, 0.0f, exRad2, 0.0f, 0.5f, ORANGE, 3 });
                                    for (auto &ex : enemies) {
                                        if (!ex.alive || &ex == &enemies[bestIdx]) continue;
                                        float edx = ex.x - enemies[bestIdx].x;
                                        float edy = ex.y - enemies[bestIdx].y;
                                        if (sqrtf(edx*edx + edy*edy) < exRad2) {
                                            ex.hp -= exDmg2;
                                            ex.hitFlashTimer = 0.2f;
                                        }
                                    }
                                }
                            }
                            chainX = enemies[bestIdx].x;
                            chainY = enemies[bestIdx].y;
                            chained.push_back(bestIdx);
                        } else {
                            break;
                        }
                    }
                }
                
                // Ricochet: redirect projectile to nearest other enemy
                if (evolution.skillLevel[RICOCHET_SHOTS] && !p.hasRicocheted) {
                    int ricLvl = evolution.skillLevel[RICOCHET_SHOTS];
                    p.hasRicocheted = true;
                    float bestRicDist = 130.0f + ricLvl * 25.0f; // 155, 180, 205, 230, 255
                    Enemy* ricTarget = nullptr;
                    for (auto &re : enemies) {
                        if (!re.alive || &re == &e) continue;
                        float rdx = re.x - p.x;
                        float rdy = re.y - p.y;
                        float rdist = sqrtf(rdx*rdx + rdy*rdy);
                        if (rdist < bestRicDist) {
                            bestRicDist = rdist;
                            ricTarget = &re;
                        }
                    }
                    if (ricTarget) {
                        float rdx = ricTarget->x - p.x;
                        float rdy = ricTarget->y - p.y;
                        float rdist = sqrtf(rdx*rdx + rdy*rdy);
                        p.vx = (rdx / rdist) * 400.0f;
                        p.vy = (rdy / rdist) * 400.0f;
                        p.color = SKYBLUE;
                        // Don't kill projectile - let it continue
                    } else {
                        p.alive = false;
                    }
                } else {
                    p.alive = false;
                }
                
                // Create impact effect
                visualEffects.push_back({
                    p.x, p.y, 0.0f, 15.0f, 0.0f, 0.3f, WHITE, 2, ""
                });
                
                if (e.hp <= 0) {
                    e.alive = false;
                    evolution.enemiesKilled++;
                    
                    // XP based on enemy difficulty
                    int xpReward = 1;
                    if (e.isBoss) {
                        xpReward = 20 + evolution.currentWave * 5;
                    } else {
                        switch (e.enemyType) {
                            case 0: xpReward = 1; break;
                            case 1: xpReward = 3; break;
                            case 2: xpReward = 5; break;
                        }
                    }
                    player.score += xpReward;
                    
                    // Explosive Kills: AoE on death (level-scaled)
                    if (evolution.skillLevel[EXPLOSIVE_KILLS]) {
                        int ekLvl = evolution.skillLevel[EXPLOSIVE_KILLS];
                        float ekRadius = 50.0f + ekLvl * 12.0f; // 62, 74, 86, 98, 110
                        int ekDmg = 2 + ekLvl; // 3, 4, 5, 6, 7
                        visualEffects.push_back({
                            e.x, e.y, 0.0f, ekRadius, 0.0f, 0.5f, ORANGE, 3, "explosion"
                        });
                        for (auto &ex : enemies) {
                            if (!ex.alive || &ex == &e) continue;
                            float edx = ex.x - e.x;
                            float edy = ex.y - e.y;
                            if (sqrtf(edx*edx + edy*edy) < ekRadius) {
                                ex.hp -= ekDmg;
                                ex.hitFlashTimer = 0.2f;
                            }
                        }
                    }
                    
                    // Create death effect
                    visualEffects.push_back({
                        e.x, e.y, 0.0f, 25.0f, 0.0f, 0.5f, e.color, 2, "death_effect"
                    });
                }
                break;
            }
        }
    }
    
    // Remove dead projectiles
    projectiles.erase(
        std::remove_if(projectiles.begin(), projectiles.end(), 
            [](const Projectile& p) { return !p.alive; }),
        projectiles.end()
    );
}

void Simulador::updateVisualEffects(float deltaTime) {
    for (auto &effect : visualEffects) {
        effect.life += deltaTime;
        
        if (effect.life >= effect.maxLife) {
            effect.life = effect.maxLife;
        }
        
        // Update effect based on type
        if (effect.type == 0) { // Toxic pulse - expanding ring
            effect.radius = (effect.life / effect.maxLife) * effect.maxRadius;
        } else if (effect.type == 1) { // Spike defense - quick flash
            effect.radius = effect.maxRadius * (1.0f - effect.life / effect.maxLife);
        } else if (effect.type == 2) { // Basic attack - small burst
            effect.radius = effect.maxRadius * (effect.life / effect.maxLife);
        }
    }
    
    // Remove finished effects
    visualEffects.erase(
        std::remove_if(visualEffects.begin(), visualEffects.end(), 
            [](const VisualEffect& e) { return e.life >= e.maxLife; }),
        visualEffects.end()
    );
}

void Simulador::spawnEvolutionEnemy(bool isBoss) {
    Enemy e;
    
    if (isBoss) {
        e.isBoss = true;
        e.enemyType = 3;
        e.radius = 25.0f;
        e.hp = 5 + evolution.currentWave * 2; // Scales with wave
        e.maxHp = e.hp;
        e.speed = 50.0f + evolution.currentWave * 5.0f;
        e.damage = 2;
        e.color = PURPLE;
        e.eyeType = 7; // X-eyes for boss
        e.mouthType = 4; // Jagged teeth
        e.extraType = 1; // Scar
        e.spriteKey = "enemy_tank"; // Tank enemy sprite for boss
    } else {
        // Random enemy type: 0=normal, 1=fast, 2=tank
        e.enemyType = rand() % 3;
        e.isBoss = false;
        
        switch (e.enemyType) {
            case 0: // Normal
                e.radius = 12.0f;
                e.hp = 1;
                e.maxHp = 1;
                e.speed = 120.0f + evolution.currentWave * 5.0f; // Increased speed
                e.damage = 1;
                e.color = BLUE;
                e.spriteKey = "enemy_safe"; // Safe enemy sprite
                break;
            case 1: // Fast
                e.radius = 10.0f;
                e.hp = 1;
                e.maxHp = 1;
                e.speed = 180.0f + evolution.currentWave * 8.0f; // Increased speed
                e.damage = 1;
                e.color = YELLOW;
                e.eyeType = 3; // Cyclops
                e.spriteKey = "enemy_dangerous"; // Dangerous enemy sprite for fast enemies
                break;
            case 2: // Tank
                e.radius = 18.0f;
                e.hp = 3;
                e.maxHp = 3;
                e.speed = 60.0f + evolution.currentWave * 4.0f; // Increased speed
                e.damage = 2;
                e.color = ORANGE;
                e.mouthType = 0; // Smile
                e.spriteKey = "enemy_tank"; // Tank enemy sprite
                break;
        }
    }
    
    // Spawn position: randomly pick an edge to spawn just outside the arena
    int edge = rand() % 4; // 0: Top, 1: Right, 2: Bottom, 3: Left
    float spawnOffset = 50.0f; // Distance outside the arena

    if (edge == 0) {
        e.x = (float)(rand() % WORLD_W);
        e.y = -spawnOffset;
    } else if (edge == 1) {
        e.x = (float)WORLD_W + spawnOffset;
        e.y = (float)(rand() % WORLD_H);
    } else if (edge == 2) {
        e.x = (float)(rand() % WORLD_W);
        e.y = (float)WORLD_H + spawnOffset;
    } else {
        e.x = -spawnOffset;
        e.y = (float)(rand() % WORLD_H);
    }
    
    // Set velocity towards player with some randomness
    float dx = player.x - e.x;
    float dy = player.y - e.y;
    float dist = sqrtf(dx*dx + dy*dy);
    if (dist > 0) {
        e.vx = (dx / dist) * e.speed;
        e.vy = (dy / dist) * e.speed;
    }
    
    e.alive = true;
    e.hitFlashTimer = 0.0f;
        float alpha = 1.0f - (effect.life / effect.maxLife);
        Color effectColor = Fade(effect.color, alpha * 255);
        
        // Use sprite if available, otherwise fallback to primitive
        if (AssetManager::hasSprite(effect.spriteKey)) {
            drawEntityWithSprite(effect.spriteKey, effect.x, effect.y, effect.radius, effectColor);
        } else {
            if (effect.type == 0) { // Expanding ring
                DrawCircleLines((int)effect.x, (int)effect.y, (int)effect.radius, effectColor);
            } else { // Burst effect
                DrawCircle((int)effect.x, (int)effect.y, (int)effect.radius, effectColor);
            }
        }
    }
    
    // Render enemies with new color system
    for (auto &e : enemies) {
        if (!e.alive) continue;
        
        // Update hit flash
        if (e.hitFlashTimer > 0) {
            e.hitFlashTimer -= GetFrameTime();
        }
        
        // Draw enemy with new color system
        Color enemyColor = e.color;
        if (e.hitFlashTimer > 0) {
            enemyColor = WHITE;
        }
        
        // Draw enemy with sprite or fallback to primitive
        drawEntityWithSprite(e.spriteKey, e.x, e.y, e.radius, enemyColor);
        
        // Draw boss indicator (only if using primitive fallback)
        if (e.isBoss && !AssetManager::hasSprite(e.spriteKey)) {
            Font uiFont = UIFont::getFont(UIFont::UI);
            const char* bossText = Localization::getText("boss");
            Vector2 textSize = MeasureTextEx(uiFont, bossText, 12.0f, 1.0f);
            DrawTextEx(uiFont, bossText, 
                      (Vector2){e.x - textSize.x/2, e.y - e.radius - 15.0f}, 
                      12.0f, 1.0f, RED);
        }
        
        // Draw procedural face
        drawEnemyFace(e.x, e.y, e.radius, e.eyeType, e.mouthType, e.extraType);
    }
    
    // Render projectiles
    for (auto &p : projectiles) {
        if (!p.alive) continue;
        
        // Calculate rotation based on movement direction
        float rotation = atan2f(p.vy, p.vx) * (180.0f / PI);
        
        drawEntityWithSprite(p.spriteKey, p.x, p.y, p.radius, p.color, rotation);
    }
    
    // Render active skill visuals
    renderSkills();
}

void Simulador::generateRandomMap() {
    evolution.mapZones.clear();
    evolution.mapSeed = GetRandomValue(1000, 9999);
    SetRandomSeed(evolution.mapSeed);
    
    // Generate 6-8 random zones
    int numZones = GetRandomValue(6, 8);
    
    for (int i = 0; i < numZones; i++) {
        EvolutionState::MapZone zone;
        
        // Random position and size
        zone.width = GetRandomValue(200, 400);
        zone.height = GetRandomValue(200, 400);
        zone.x = GetRandomValue(100, WORLD_W - (int)zone.width - 100);
        zone.y = GetRandomValue(100, WORLD_H - (int)zone.height - 100);
        
        // Zone type and color
        zone.zoneType = GetRandomValue(0, 2);
        
        switch (zone.zoneType) {
            case 0: // Open area - lighter colors
                zone.zoneColor = (Color){40, 45, 50, 100}; // Dark gray-blue
                break;
            case 1: // Dense area - medium colors
                zone.zoneColor = (Color){35, 40, 45, 120}; // Darker gray
                break;
            case 2: // Special area - tinted colors
                zone.zoneColor = (Color){45, 35, 40, 110}; // Dark purple tint
                break;
        }
        
        evolution.mapZones.push_back(zone);
    }
    
    // Reset random seed
    SetRandomSeed((unsigned int)GetTime());
}

void Simulador::renderMapZones() {
    if (currentMode != Evolution) return;
    
    for (auto &zone : evolution.mapZones) {
        // No camera offset
        float screenX = zone.x;
        float screenY = zone.y;
        
        // Only render if visible on screen
        if (screenX + zone.width > 0 && screenX < width &&
            screenY + zone.height > 0 && screenY < height) {
            
            // Draw zone background
            DrawRectangle((int)screenX, (int)screenY, (int)zone.width, (int)zone.height, zone.zoneColor);
            
            // Add some visual detail based on zone type
            if (zone.zoneType == 1) { // Dense area
                // Add some decorative dots
                for (int i = 0; i < 5; i++) {
                    float dotX = screenX + GetRandomValue(20, (int)zone.width - 20);
                    float dotY = screenY + GetRandomValue(20, (int)zone.height - 20);
                    DrawCircle((int)dotX, (int)dotY, 3, Fade(WHITE, 30));
                }
            } else if (zone.zoneType == 2) { // Special area
                // Add some decorative lines
                for (int i = 0; i < 3; i++) {
                    float lineX = screenX + GetRandomValue(10, (int)zone.width - 10);
                    DrawLine((int)lineX, (int)screenY, (int)lineX, (int)(screenY + zone.height), Fade(YELLOW, 20));
                }
            }
        }
    }
}

Simulador::~Simulador() {
    // Cleanup font system
    UIFont::cleanup();
}



void Simulador::drawSprite(const std::string& spriteKey, float x, float y, float width, float height, float rotation, Color tint) {
    if (AssetManager::hasSprite(spriteKey)) {
        Texture2D sprite = AssetManager::getSprite(spriteKey);
        Rectangle sourceRec = { 0, 0, (float)sprite.width, (float)sprite.height };
        Vector2 origin = { (float)sprite.width / 2.0f, (float)sprite.height / 2.0f };
        Vector2 position = { x, y };
        
        // Scale sprite to fit the requested dimensions
        float scaleX = width / (float)sprite.width;
        float scaleY = height / (float)sprite.height;
        
        DrawTexturePro(sprite, sourceRec, origin, position, rotation, scaleX, scaleY, tint);
    } else {
        // Fallback: draw colored rectangle
        DrawRectangle(x - width/2, y - height/2, width, height, tint);
    }
}

void Simulador::drawEntityWithSprite(const std::string& spriteKey, float x, float y, float radius, Color fallbackColor, float rotation) {
    printf("[DEBUG] drawEntityWithSprite called with key: %s at (%.1f, %.1f)\n", spriteKey.c_str(), x, y);
    
    if (AssetManager::hasSprite(spriteKey)) {
        Texture2D sprite = AssetManager::getSprite(spriteKey);
        if (sprite.id > 0) {
            Rectangle sourceRec = { 0, 0, (float)sprite.width, (float)sprite.height };
            Vector2 origin = { (float)sprite.width / 2.0f, (float)sprite.height / 2.0f };
            Vector2 position = { x, y };
            
            // Scale sprite to fit the entity radius
            float scale = (radius * 2.0f) / (float)sprite.width;
            
            printf("[DEBUG] Drawing sprite %s (scale: %.2f, rotation: %.1f)\n", spriteKey.c_str(), scale, rotation);
            DrawTexturePro(sprite, sourceRec, origin, position, rotation, scale, scale, WHITE);
        } else {
            printf("[DEBUG] Invalid sprite texture for key: %s, falling back to primitive\n", spriteKey.c_str());
            // Fallback: draw colored circle
            DrawCircle((int)x, (int)y, radius, fallbackColor);
            DrawCircleLines((int)x, (int)y, radius, WHITE);
        }
    } else {
        printf("[DEBUG] Sprite %s not found, using fallback primitive\n", spriteKey.c_str());
        // Fallback: draw colored circle
        DrawCircle((int)x, (int)y, radius, fallbackColor);
        DrawCircleLines((int)x, (int)y, radius, WHITE);
    }
}

void Simulador::checkAchievements(){
    // Kill antibodies (enemies)
    static int totalEnemiesKilled = 0;
    static int currentLevelEnemiesKilled = 0;
    
    // Reached level X
    if (nivel >= 5) {
        for (auto &ach : achievements) {
            if (ach.id == "reach_level_5") ach.unlocked = true;
        }
    }
    if (nivel >= 10) {
        for (auto &ach : achievements) {
            if (ach.id == "reach_level_10") ach.unlocked = true;
        }
    }
    if (nivel >= 20) {
        for (auto &ach : achievements) {
            if (ach.id == "reach_level_20") ach.unlocked = true;
        }
    }
    
    // Collect XP
    if (player.score >= 100) {
        for (auto &ach : achievements) {
            if (ach.id == "collect_100_xp") ach.unlocked = true;
        }
    }
    
    // Grow large
    if (player.radius >= 80.0f) {
        for (auto &ach : achievements) {
            if (ach.id == "grow_large") ach.unlocked = true;
        }
    }
    
    // Survive 60 seconds
    if (timeAlive >= 60.0f) {
        for (auto &ach : achievements) {
            if (ach.id == "survive_60s") ach.unlocked = true;
        }
    }
}

void Simulador::toggleFullscreen(){
    if (isFullscreen) {
        isFullscreen = false;
        ToggleBorderlessWindowed();
    } else {
        isFullscreen = true;
        ToggleBorderlessWindowed();
    }
}

void Simulador::setWindowSize(int w, int h){
    width = w;
    height = h;
    SetWindowMinSize(320, 240);
    SetWindowState(FLAG_WINDOW_RESIZABLE);
}

void Simulador::spawnParticles(float x, float y, int count, int r, int g, int b, int a){
    for (int i=0;i<count;i++){
        Particle p;
        p.x = x + GetRandomValue(-6,6);
        p.y = y + GetRandomValue(-6,6);
        p.vx = (GetRandomValue(-100,100) / 100.0f) * 80.0f;
        p.vy = (GetRandomValue(-100,100) / 100.0f) * 80.0f;
        p.life = 1.0f;
        p.r = r; p.g = g; p.b = b; p.a = a;
        particles.push_back(p);
    }
}

void Simulador::spawnEnemyParticles(float x, float y, Color enemyColor){
    for (int i=0;i<5;i++){
        Particle p;
        p.x = x + GetRandomValue(-3,3);
        p.y = y + GetRandomValue(-3,3);
        p.vx = (GetRandomValue(-100,100) / 100.0f) * 40.0f;  // Slower movement
        p.vy = (GetRandomValue(-100,100) / 100.0f) * 40.0f;
        p.life = 0.3f;  // Short lifetime for subtle effect
        p.r = enemyColor.r; p.g = enemyColor.g; p.b = enemyColor.b; p.a = 255;
        particles.push_back(p);
    }
}

void Simulador::drawEnemyFace(float x, float y, float radius, int eyeType, int mouthType, int extraType){
    float scale = radius * 0.1f;  // Scale face elements with enemy size
    
    // Draw eyes based on eyeType (0-7)
    float eyeY = y - radius * 0.2f;
    float eyeSize = scale * 0.8f;
    
    switch(eyeType){
        case 0: // normal eyes
            DrawCircle((int)(x - radius * 0.3f), (int)eyeY, (int)eyeSize, WHITE);
            DrawCircle((int)(x + radius * 0.3f), (int)eyeY, (int)eyeSize, WHITE);
            break;
        case 1: // big eyes
            DrawCircle((int)(x - radius * 0.3f), (int)eyeY, (int)(eyeSize * 1.5f), WHITE);
            DrawCircle((int)(x + radius * 0.3f), (int)eyeY, (int)(eyeSize * 1.5f), WHITE);
            break;
        case 2: // small eyes
            DrawCircle((int)(x - radius * 0.3f), (int)eyeY, (int)(eyeSize * 0.5f), WHITE);
            DrawCircle((int)(x + radius * 0.3f), (int)eyeY, (int)(eyeSize * 0.5f), WHITE);
            break;
        case 3: // cyclops
            DrawCircle((int)x, (int)eyeY, (int)(eyeSize * 1.2f), WHITE);
            break;
        case 4: // closed eyes
            DrawLine((int)(x - radius * 0.4f), (int)eyeY, (int)(x - radius * 0.2f), (int)eyeY, WHITE);
            DrawLine((int)(x + radius * 0.2f), (int)eyeY, (int)(x + radius * 0.4f), (int)eyeY, WHITE);
            break;
        case 5: // angry eyes
            DrawLine((int)(x - radius * 0.4f), (int)(eyeY - eyeSize), (int)(x - radius * 0.2f), (int)(eyeY + eyeSize), WHITE);
            DrawLine((int)(x + radius * 0.2f), (int)(eyeY - eyeSize), (int)(x + radius * 0.4f), (int)(eyeY + eyeSize), WHITE);
            break;
        case 6: // cross-eyed
            DrawCircle((int)(x - radius * 0.2f), (int)eyeY, (int)eyeSize, WHITE);
            DrawCircle((int)(x + radius * 0.2f), (int)eyeY, (int)eyeSize, WHITE);
            break;
        case 7: // X-eyes
            DrawLine((int)(x - radius * 0.4f), (int)(eyeY - eyeSize), (int)(x - radius * 0.2f), (int)(eyeY + eyeSize), WHITE);
            DrawLine((int)(x - radius * 0.4f), (int)(eyeY + eyeSize), (int)(x - radius * 0.2f), (int)(eyeY - eyeSize), WHITE);
            DrawLine((int)(x + radius * 0.2f), (int)(eyeY - eyeSize), (int)(x + radius * 0.4f), (int)(eyeY + eyeSize), WHITE);
            DrawLine((int)(x + radius * 0.2f), (int)(eyeY + eyeSize), (int)(x + radius * 0.4f), (int)(eyeY - eyeSize), WHITE);
            break;
    }
    
    // Draw mouth based on mouthType (0-5)
    float mouthY = y + radius * 0.2f;
    float mouthWidth = radius * 0.4f;
    
    switch(mouthType){
        case 0: // smile
            DrawLine((int)(x - mouthWidth), (int)mouthY, (int)(x + mouthWidth), (int)mouthY, WHITE);
            DrawLine((int)(x - mouthWidth), (int)mouthY, (int)(x - mouthWidth + 5), (int)(mouthY - 5), WHITE);
            DrawLine((int)(x + mouthWidth), (int)mouthY, (int)(x + mouthWidth - 5), (int)(mouthY - 5), WHITE);
            break;
        case 1: // frown
            DrawLine((int)(x - mouthWidth), (int)mouthY, (int)(x + mouthWidth), (int)mouthY, WHITE);
            DrawLine((int)(x - mouthWidth), (int)mouthY, (int)(x - mouthWidth + 5), (int)(mouthY + 5), WHITE);
            DrawLine((int)(x + mouthWidth), (int)mouthY, (int)(x + mouthWidth - 5), (int)(mouthY + 5), WHITE);
            break;
        case 2: // neutral
            DrawLine((int)(x - mouthWidth), (int)mouthY, (int)(x + mouthWidth), (int)mouthY, WHITE);
            break;
        case 3: // open (O shape)
            DrawCircleLines((int)x, (int)mouthY, (int)(scale * 0.6f), WHITE);
            break;
        case 4: // jagged teeth
            DrawLine((int)(x - mouthWidth), (int)mouthY, (int)(x - mouthWidth + 8), (int)(mouthY - 6), WHITE);
            DrawLine((int)(x - mouthWidth + 8), (int)(mouthY - 6), (int)(x - mouthWidth + 16), (int)mouthY, WHITE);
            DrawLine((int)(x - mouthWidth + 16), (int)mouthY, (int)(x - mouthWidth + 24), (int)(mouthY - 6), WHITE);
            DrawLine((int)(x - mouthWidth + 24), (int)(mouthY - 6), (int)(x + mouthWidth), (int)mouthY, WHITE);
            break;
        case 5: // tongue
            DrawLine((int)(x - mouthWidth), (int)mouthY, (int)(x + mouthWidth), (int)mouthY, WHITE);
            DrawCircle((int)x, (int)(mouthY + scale * 0.4f), (int)(scale * 0.3f), PINK);
            break;
    }
    
    // Draw extra features based on extraType (0-3)
    switch(extraType){
        case 0: // eyebrows
            DrawLine((int)(x - radius * 0.4f), (int)(eyeY - eyeSize - 3), (int)(x - radius * 0.2f), (int)(eyeY - eyeSize - 3), WHITE);
            DrawLine((int)(x + radius * 0.2f), (int)(eyeY - eyeSize - 3), (int)(x + radius * 0.4f), (int)(eyeY - eyeSize - 3), WHITE);
            break;
        case 1: // scar
            DrawLine((int)(x - radius * 0.3f), (int)(y - radius * 0.1f), (int)(x + radius * 0.3f), (int)(y + radius * 0.1f), RED);
            break;
        case 2: // antenna
            DrawLine((int)x, (int)(y - radius), (int)x, (int)(y - radius - scale * 2.0f), WHITE);
            DrawCircle((int)x, (int)(y - radius - scale * 2.0f), (int)(scale * 0.3f), WHITE);
            break;
        case 3: // wart
            DrawCircle((int)(x + radius * 0.3f), (int)(y - radius * 0.1f), (int)(scale * 0.2f), BROWN);
            break;
    }
}

// Evolution Mode Functions
void Simulador::initializeEvolution() {
    currentMode = Evolution;
    
    // Initialize Evolution Mode state
    evolution.isActive = true;
    evolution.runStartTime = GetTime();
    evolution.survivalTime = 0.0f;
    evolution.enemiesKilled = 0;
    evolution.xpCollected = 0;
    evolution.playerLevel = 1;
    evolution.currentWave = 1;
    evolution.nextDifficultyTime = 10.0f; // 10 seconds per wave
    evolution.difficultyMultiplier = 1.0f;
    evolution.upgradeMenuVisible = false;
    evolution.selectedUpgradeIndex = 0;
    evolution.currentUpgrades.clear();
    evolution.currentUpgradeChoices.clear();
    
    // Initialize active skill states
    for (int i = 0; i < UPGRADE_TYPE_COUNT; i++) evolution.skillLevel[i] = 0;
    evolution.orbitAngle = 0.0f;
    evolution.coneBlastTimer = 0.0f;
    evolution.coneBlastAngle = 0.0f;
    evolution.shieldUp = false;
    evolution.shieldRechargeTimer = 0.0f;
    evolution.repulsionTimer = 0.0f;
    evolution.blackHoleTimer = 0.0f;
    evolution.blackHoleX = 0.0f;
    evolution.blackHoleY = 0.0f;
    evolution.blackHoleLife = 0.0f;
    evolution.blackHoleActive = false;
    evolution.meteorTimer = 0.0f;
    evolution.overloadTimer = 0.0f;
    
    // Initialize basic attack system (player starts with basic attack)
    evolution.basicAttackCooldown = 1.0f; // Slower firing rate
    evolution.basicAttackTimer = 0.0f;
    
    // Initialize boss system
    evolution.bossWave = false;
    evolution.enemiesInWave = 30; // Start with heavy presence (30 initially)
    evolution.enemiesSpawned = 0;
    
    // Spawn system
    evolution.spawnTimer = 0.5f;
    evolution.hudBottomY = 0.0f;
    
    // Adjust speed for Evolution mode (disable 0.25x)
    currentSpeedIndex = getValidSpeedIndex(currentSpeedIndex, currentMode);
    
    // Reset player state for Evolution mode
    player.radius = 12.0f;
    player.score = 0;
    player.x = WORLD_W / 2.0f; // Center of larger world
    player.y = WORLD_H / 2.0f;
    player.spriteKey = "player"; // Set player sprite key
    
    // Clear existing entities
    enemies.clear();
    resources.clear();
    projectiles.clear();
    visualEffects.clear();
    
    // Generate random map for this run
    generateRandomMap();
}

void Simulador::updateEvolution(float deltaTime) {
    if (currentMode != Evolution) return;
    
    // Update survival time
    evolution.survivalTime = GetTime() - evolution.runStartTime;
    
    // Update difficulty scaling based on time (10 seconds per wave)
    if (evolution.survivalTime >= evolution.nextDifficultyTime) {
        evolution.currentWave++;
        evolution.nextDifficultyTime = evolution.currentWave * 10.0f; // Every 10 seconds
        evolution.difficultyMultiplier = 1.0f + (evolution.currentWave - 1) * 0.1f; // 10% increase per wave
        
        // Check if this is a boss wave (every 3 waves)
        evolution.bossWave = (evolution.currentWave % 3 == 0);
        
        // Reset wave spawning - significantly increased for intense survival pressure
        evolution.enemiesSpawned = 0;
        evolution.enemiesInWave = 30 + evolution.currentWave * 15; // Rapidly escalating horde
        if (evolution.bossWave) {
            evolution.enemiesInWave = 20 + evolution.currentWave * 10; // Extra enemies even on boss waves
        }
    }
    
    // Update basic attack cooldown
    if (evolution.basicAttackTimer > 0) {
        evolution.basicAttackTimer -= deltaTime;
    }
    
    // Auto-fire basic attack (or handle input for manual firing)
    if (evolution.basicAttackTimer <= 0) {
        fireBasicAttack();
        evolution.basicAttackTimer = evolution.basicAttackCooldown;
    }
    
    // Update projectiles
    updateProjectiles(deltaTime);
    
    // Update visual effects
    updateVisualEffects(deltaTime);
    
    // Update all active skills
    updateSkills(deltaTime);
}

void Simulador::renderEvolutionUI() {
    if (currentMode != Evolution) return;
    
    // Calculate boundaries of the rendered 900x600 play area relative to the window
    float scaleX = (float)GetScreenWidth() / WORLD_W;
    float scaleY = (float)GetScreenHeight() / WORLD_H;
    float scale = std::min(scaleX, scaleY);
    float drawW = WORLD_W * scale;
    float drawH = WORLD_H * scale;
    float offsetX = (GetScreenWidth() - drawW) / 2.0f;
    float offsetY = (GetScreenHeight() - drawH) / 2.0f;
    
    // Render Evolution Mode statistics with clear vertical stacking
    if (evolution.upgradeMenuVisible) {
        renderUpgradeMenu();
        return;
    }

    Font uiFont = UIFont::getFont(UIFont::UI);
    // Use the texture scale as universal UI scale, clamped between 1.0f and 2.5f for readability
    float uiScale = std::min(std::max(1.0f, scale), 2.5f);
    float fontSize = 16.0f * uiScale;
    float lineH = fontSize + 6.0f * uiScale; // consistent vertical spacing between rows
    float leftX = offsetX + 10.0f * uiScale;
    float curY = offsetY + 10.0f * uiScale; // running Y cursor
    
    // Row 1 — Wave
    char waveText[64];
    sprintf(waveText, "%s %d", Localization::getText("wave"), evolution.currentWave);
    DrawTextEx(uiFont, waveText, (Vector2){leftX, curY}, fontSize, 1.0f, WHITE);
    curY += lineH;
    
    
    // Row 3 — Kills
    char killsText[64];
    sprintf(killsText, "%s: %d", Localization::getText("kills"), evolution.enemiesKilled);
    DrawTextEx(uiFont, killsText, (Vector2){leftX, curY}, fontSize, 1.0f, WHITE);
    curY += lineH;
    
    // Row 4 — Next Wave countdown
    float timeToWave = evolution.nextDifficultyTime - evolution.survivalTime;
    if (timeToWave > 0) {
        char nextWaveText[64];
        sprintf(nextWaveText, "%s: %.1fs", Localization::getText("next_wave"), timeToWave);
        DrawTextEx(uiFont, nextWaveText, (Vector2){leftX, curY}, fontSize, 1.0f, YELLOW);
        curY += lineH;
    }
    
    // Row 5 — Survival time
    char timeText[64];
    sprintf(timeText, "%s: %.1fs", Localization::getText("time"), evolution.survivalTime);
    DrawTextEx(uiFont, timeText, (Vector2){leftX, curY}, fontSize, 1.0f, Fade(WHITE, 0.7f));
    curY += lineH;
    
    // Store the bottom Y for the XP bar that is drawn later in updateGame
    evolution.hudBottomY = curY;
    
    // Right side: Evolution Level
    char levelText[64];
    sprintf(levelText, "%s: %d", Localization::getText("evolution_level"), evolution.playerLevel);
    Vector2 levelTextSize = MeasureTextEx(uiFont, levelText, fontSize, 1.0f);
    DrawTextEx(uiFont, levelText, (Vector2){offsetX + drawW - levelTextSize.x - 10.0f * uiScale, offsetY + 10.0f * uiScale}, fontSize, 1.0f, WHITE);
    
    // Right side: Boss wave indicator
    if (evolution.bossWave) {
        const char* bossWaveText = Localization::getText("boss_wave");
        Vector2 bossTextSize = MeasureTextEx(uiFont, bossWaveText, fontSize, 1.0f);
        DrawTextEx(uiFont, bossWaveText, (Vector2){offsetX + drawW - bossTextSize.x - 10.0f * uiScale, offsetY + 10.0f * uiScale + lineH}, fontSize, 1.0f, RED);
    }
}

std::string Simulador::getSkillStatsDescription(UpgradeType type, int level) {
    if (level < 1) return "";
    char buf[128];
    const char* dmgL = Localization::getText("stat_damage");
    const char* cdL = Localization::getText("stat_cooldown");
    const char* radL = Localization::getText("stat_radius");
    const char* rngL = Localization::getText("stat_range");
    const char* projL = Localization::getText("stat_projectiles");
    const char* durL = Localization::getText("stat_duration");
    const char* metL = Localization::getText("stat_meteors");
    const char* slowL = Localization::getText("stat_slow");
    const char* bladeL = Localization::getText("stat_blades");
    const char* jumpL = Localization::getText("stat_jumps");

    switch (type) {
        case ORBIT_BLADES:
            sprintf(buf, "%d %s, %d %s", level + 1, bladeL, level + 1, dmgL);
            break;
        case CONE_BLAST:
            sprintf(buf, "%.1fs %s, %d %s", 2.5f - level * 0.3f, cdL, 3 + level * 2, dmgL);
            break;
        case CHAIN_LIGHTNING:
            sprintf(buf, "%d %s, %d %s", 2 + level, jumpL, 1 + level, dmgL);
            break;
        case EXPLOSIVE_KILLS:
            sprintf(buf, "%d %s, %d %s", (int)(50.0f + level * 12.0f), radL, 2 + level, dmgL);
            break;
        case RICOCHET_SHOTS:
            sprintf(buf, "%d %s", (int)(130.0f + level * 25.0f), rngL);
            break;
        case MULTISHOT:
            sprintf(buf, "%d %s", 2 + level, projL);
            break;
        case ENERGY_SHIELD:
            sprintf(buf, "%.1fs %s", 7.0f - level * 0.8f, cdL);
            break;
        case REPULSION_PULSE:
            sprintf(buf, "%.1fs %s, %d %s", 3.5f - level * 0.4f, cdL, level, dmgL);
            break;
        case FROST_FIELD:
            sprintf(buf, "%d %s, %d%% %s", (int)(80.0f + level * 20.0f), radL, (int)((1.0f - (0.45f - level * 0.05f)) * 100.0f), slowL);
            break;
        case BLACK_HOLE:
            sprintf(buf, "%.1fs %s, %d %s", 3.0f + level * 0.5f, durL, 1 + level, dmgL);
            break;
        case METEOR_STRIKE:
            sprintf(buf, "%.1fs %s, %d %s", 2.0f - level * 0.3f, cdL, level, metL);
            break;
        case OVERLOAD:
            sprintf(buf, "%.1fs %s, %d %s", 4.5f - level * 0.5f, cdL, 2 + level, dmgL);
            break;
        default: return "";
    }
    return std::string(buf);
}


void Simulador::drawTextWithHighlights(Font font, const char* text, Vector2 pos, float size, Color baseCol, Color highlightCol) {
    std::string str(text);
    float curX = pos.x;
    std::string segment;
    bool isHighlight = false;
    
    for (size_t i = 0; i <= str.size(); i++) {
        char ch = (i < str.size()) ? str[i] : '\0';
        bool isDigit = (ch >= '0' && ch <= '9') || ch == '.';
        
        if (i == str.size() || isDigit != isHighlight) {
            if (!segment.empty()) {
                DrawTextEx(font, segment.c_str(), (Vector2){curX, pos.y}, size, 1.0f, isHighlight ? highlightCol : baseCol);
                curX += MeasureTextEx(font, segment.c_str(), size, 1.0f).x;
            }
            segment = "";
            isHighlight = isDigit;
        }
        if (ch != '\0') segment += ch;
    }
}

void Simulador::renderUpgradeMenu() {

    // Calculate boundaries of the rendered 900x600 play area relative to the window
    float scaleX = (float)GetScreenWidth() / WORLD_W;
    float scaleY = (float)GetScreenHeight() / WORLD_H;
    float scale = std::min(scaleX, scaleY);
    float drawW = WORLD_W * scale;
    float drawH = WORLD_H * scale;
    float offsetX = (GetScreenWidth() - drawW) / 2.0f;
    float offsetY = (GetScreenHeight() - drawH) / 2.0f;
    
    // Simple upgrade menu UI for Evolution Mode
    Font uiFont = UIFont::getFont(UIFont::UI);
    Font titleFont = UIFont::getFont(UIFont::TITLE);
    float uiScale = std::min(std::max(1.0f, scale), 2.5f);
    
    // Darken background restricted to play area bounds
    DrawRectangle((int)offsetX, (int)offsetY, (int)drawW, (int)drawH, Fade(BLACK, 180));
    
    // Title
    const char* title = Localization::getText("choose_upgrade");
    float titleSize = 32.0f * uiScale;
    Vector2 titleSizeVec = MeasureTextEx(titleFont, title, titleSize, 1.0f);
    DrawTextEx(titleFont, title, (Vector2){offsetX + drawW/2.0f - titleSizeVec.x/2.0f, offsetY + 50.0f * uiScale}, titleSize, 1.0f, YELLOW);    // Get actual choices and build display strings
    int numChoices = (int)evolution.currentUpgradeChoices.size();
    if (numChoices == 0) return;
    
    // Render upgrade options — taller cards, proper text layout
    float optionWidth = 240.0f * uiScale;
    float optionHeight = 180.0f * uiScale;
    float optionSpacing = 16.0f * uiScale;
    float totalWidth = numChoices * optionWidth + (numChoices - 1) * optionSpacing;
    float startX = offsetX + (drawW - totalWidth) / 2.0f;
    float cardY = offsetY + 130.0f * uiScale;
    float padding = 12.0f * uiScale;
    
    for (int i = 0; i < numChoices; i++) {
        float cx = startX + i * (optionWidth + optionSpacing);
        UpgradeType choice = (UpgradeType)evolution.currentUpgradeChoices[i];
        int currentLevel = evolution.skillLevel[choice];
        int nextLevel = currentLevel + 1;
        
        // Card background
        bool selected = (i == evolution.selectedUpgradeIndex);
        Color bgCol = selected ? (Color){20, 60, 20, 220} : (Color){30, 30, 40, 220};
        Color borderCol = selected ? (Color){80, 255, 80, 255} : (Color){120, 120, 140, 255};
        DrawRectangle((int)cx, (int)cardY, (int)optionWidth, (int)optionHeight, bgCol);
        DrawRectangleLines((int)cx, (int)cardY, (int)optionWidth, (int)optionHeight, borderCol);
        if (selected) {
            DrawRectangleLines((int)(cx-1), (int)(cardY-1), (int)(optionWidth+2), (int)(optionHeight+2), borderCol);
        }
        
        // Skill name with level
        const char* baseName = Localization::getUpgradeName(choice);
        const char* displayName;
        static char nameBuf[3][64]; // static buffer for formatted names
        if (currentLevel > 0) {
            // Show level: "Skill II", "Skill III", etc.
            const char* romanNumerals[] = {"", "I", "II", "III", "IV", "V"};
            snprintf(nameBuf[i], 64, "%s %s", baseName, romanNumerals[std::min(nextLevel, 5)]);
            displayName = nameBuf[i];
        } else {
            displayName = baseName;
        }
        
        float nameSize = 15.0f * uiScale;
        Vector2 nameSizeVec = MeasureTextEx(uiFont, displayName, nameSize, 1.0f);
        float nameX = cx + optionWidth / 2.0f - nameSizeVec.x / 2.0f;
        DrawTextEx(uiFont, displayName, (Vector2){nameX, cardY + padding}, nameSize, 1.0f, WHITE);
        
        // Level bar (small dots showing current level)
        if (currentLevel > 0) {
            float dotY = cardY + padding + nameSize + 4.0f * uiScale;
            float dotSpacing = 10.0f * uiScale;
            float dotsWidth = EvolutionState::MAX_SKILL_LEVEL * dotSpacing;
            float dotStartX = cx + optionWidth / 2.0f - dotsWidth / 2.0f;
            for (int d = 0; d < EvolutionState::MAX_SKILL_LEVEL; d++) {
                Color dotCol = (d < currentLevel) ? (Color){80, 255, 80, 255} : (Color){60, 60, 70, 200};
                DrawCircle((int)(dotStartX + d * dotSpacing + dotSpacing/2), (int)dotY, 3.0f * uiScale, dotCol);
            }
        }
        
        // Description with word-wrap or Comparison
        float descSize = 10.0f * uiScale;
        float descY = cardY + padding + nameSize + (currentLevel > 0 ? 18.0f : 8.0f) * uiScale;
        float maxDescW = optionWidth - 2.0f * padding;
        float lineH = descSize + 2.0f * uiScale;
        
        if (currentLevel >= 1) {
            // Show Comparison: Atual vs Upgrade
            std::string curText = std::string(Localization::getText("current_label")) + ": " + getSkillStatsDescription(choice, currentLevel);
            std::string nextText = std::string(Localization::getText("upgrade_label")) + ": " + getSkillStatsDescription(choice, nextLevel);
            
            DrawTextEx(uiFont, curText.c_str(), (Vector2){cx + padding, descY}, descSize, 1.0f, (Color){160, 160, 170, 255});
            drawTextWithHighlights(uiFont, nextText.c_str(), (Vector2){cx + padding, descY + lineH + 4.0f * uiScale}, descSize, WHITE, YELLOW);
        } else {

            // New Skill: Show standard description with word-wrap
            const char* desc = Localization::getUpgradeDescription(choice);
            std::string descStr(desc);
            float curX = cx + padding;
            float curY = descY;
            std::string word;
            float spaceW = MeasureTextEx(uiFont, " ", descSize, 1.0f).x;
            float lineX = 0.0f;
            
            for (size_t ci = 0; ci <= descStr.size(); ci++) {
                char ch = (ci < descStr.size()) ? descStr[ci] : ' ';
                if (ch == ' ' || ci == descStr.size()) {
                    if (!word.empty()) {
                        Vector2 wordSize = MeasureTextEx(uiFont, word.c_str(), descSize, 1.0f);
                        if (lineX + wordSize.x > maxDescW && lineX > 0) {
                            curY += lineH;
                            lineX = 0.0f;
                        }
                        if (curY + lineH < cardY + optionHeight - padding) {
                            DrawTextEx(uiFont, word.c_str(), (Vector2){cx + padding + lineX, curY}, descSize, 1.0f, (Color){180, 180, 200, 255});
                        }
                        lineX += wordSize.x + spaceW;
                        word.clear();
                    }
                } else {
                    word += ch;
                }
            }
        }
    }
    
    // Instructions
    const char* instructions = Localization::getText("upgrade_instructions");
    float instSize = 14.0f * uiScale;
    Vector2 instSizeVec = MeasureTextEx(uiFont, instructions, instSize, 1.0f);
    DrawTextEx(uiFont, instructions, 
              (Vector2){offsetX + drawW/2.0f - instSizeVec.x/2.0f, offsetY + drawH - 40.0f * uiScale}, 
              instSize, 1.0f, (Color){200, 200, 200, 200});
}

void Simulador::handleUpgradeMenuInput() {
    int numChoices = (int)evolution.currentUpgradeChoices.size();
    if (numChoices == 0) return;
    
    if (IsKeyPressed(KEY_LEFT)) {
        evolution.selectedUpgradeIndex = (evolution.selectedUpgradeIndex - 1 + numChoices) % numChoices;
    }
    if (IsKeyPressed(KEY_RIGHT)) {
        evolution.selectedUpgradeIndex = (evolution.selectedUpgradeIndex + 1) % numChoices;
    }
    if (IsKeyPressed(KEY_ENTER) || IsKeyPressed(KEY_SPACE)) {
        // Apply the actual selected upgrade from the choices list
        if (evolution.selectedUpgradeIndex < numChoices) {
            UpgradeType chosen = (UpgradeType)evolution.currentUpgradeChoices[evolution.selectedUpgradeIndex];
            applyUpgrade(chosen);
        }
        evolution.upgradeMenuVisible = false;
    }
}

// Evolution Mode helper functions
void Simulador::generateUpgradeChoices() {
    // Generate upgrade choices — skills below max level can reappear
    std::vector<UpgradeType> availableSkills;
    
    for (int i = 0; i < UPGRADE_TYPE_COUNT; i++) {
        if (evolution.skillLevel[i] < EvolutionState::MAX_SKILL_LEVEL) {
            availableSkills.push_back((UpgradeType)i);
        }
    }
    
    // Shuffle available skills
    std::random_device rd;
    std::mt19937 g(rd());
    std::shuffle(availableSkills.begin(), availableSkills.end(), g);
    
    // Store up to 3 choices
    evolution.currentUpgradeChoices.clear();
    int numToOffer = std::min(3, (int)availableSkills.size());
    for (int i = 0; i < numToOffer; i++) {
        evolution.currentUpgradeChoices.push_back(availableSkills[i]);
    }
    
    evolution.selectedUpgradeIndex = 0;
}

void Simulador::applyUpgrade(UpgradeType type) {
    // Increment skill level (multi-level system)
    evolution.skillLevel[type]++;
    if (evolution.skillLevel[type] > EvolutionState::MAX_SKILL_LEVEL) {
        evolution.skillLevel[type] = EvolutionState::MAX_SKILL_LEVEL;
    }
    evolution.currentUpgrades.push_back((int)type);
    
    // Initialize skill-specific state on first acquisition
    if (evolution.skillLevel[type] == 1) {
        switch (type) {
            case ORBIT_BLADES:
                evolution.orbitAngle = 0.0f;
                break;
            case CONE_BLAST:
                evolution.coneBlastTimer = 0.0f;
                break;
            case ENERGY_SHIELD:
                evolution.shieldUp = true;
                evolution.shieldRechargeTimer = 0.0f;
                break;
            case REPULSION_PULSE:
                evolution.repulsionTimer = 0.0f;
                break;
            case BLACK_HOLE:
                evolution.blackHoleTimer = 0.0f;
                evolution.blackHoleActive = false;
                break;
            case METEOR_STRIKE:
                evolution.meteorTimer = 0.0f;
                break;
            case OVERLOAD:
                evolution.overloadTimer = 0.0f;
                break;
            default:
                break;
        }
    }
}

void Simulador::updateSkills(float dt) {
    if (currentMode != Evolution) return;
    
    // --- ORBIT BLADES --- (lvl scales: blade count, dmg, speed, radius)
    if (evolution.skillLevel[ORBIT_BLADES]) {
        int lvl = evolution.skillLevel[ORBIT_BLADES];
        int bladeCount = 1 + lvl; // 2,3,4,5,6 blades
        int bladeDmg = 1 + lvl;   // 2,3,4,5,6 dmg
        float spinSpeed = 3.5f + lvl * 0.8f; // faster
        float orbitRadius = player.radius + 25.0f + lvl * 5.0f;
        float bladeRadius = 10.0f + lvl * 2.0f;
        
        evolution.orbitAngle += dt * spinSpeed;
        
        for (int b = 0; b < bladeCount; b++) {
            float angle = evolution.orbitAngle + b * (6.28318f / bladeCount);
            float bladeX = player.x + cosf(angle) * orbitRadius;
            float bladeY = player.y + sinf(angle) * orbitRadius;
            
            for (auto &e : enemies) {
                if (!e.alive) continue;
                float dx = bladeX - e.x;
                float dy = bladeY - e.y;
                float dist = sqrtf(dx*dx + dy*dy);
                if (dist < bladeRadius + e.radius) {
                    e.hp -= bladeDmg;
                    e.hitFlashTimer = 0.15f;
                    if (e.hp <= 0) {
                        e.alive = false;
                        evolution.enemiesKilled++;
                        int xpReward = 1;
                        if (e.isBoss) xpReward = 20 + evolution.currentWave * 5;
                        else { switch (e.enemyType) { case 0: xpReward=1; break; case 1: xpReward=3; break; case 2: xpReward=5; break; } }
                        player.score += xpReward;
                        if (evolution.skillLevel[EXPLOSIVE_KILLS]) {
                            int exLvl = evolution.skillLevel[EXPLOSIVE_KILLS];
                            float exRadius = 50.0f + exLvl * 12.0f;
                            int exDmg = 2 + exLvl;
                            visualEffects.push_back({e.x, e.y, 0.0f, exRadius, 0.0f, 0.5f, ORANGE, 3, "explosion"});
                            for (auto &ex : enemies) {
                                if (!ex.alive || &ex == &e) continue;
                                float edx = ex.x - e.x; float edy = ex.y - e.y;
                                if (sqrtf(edx*edx+edy*edy) < exRadius) { ex.hp -= exDmg; ex.hitFlashTimer = 0.2f; }
                            }
                        }
                    }
                }
            }
        }
    }
    
    // --- CONE BLAST --- (lvl scales: cooldown, range, dmg, cone width)
    if (evolution.skillLevel[CONE_BLAST]) {
        int lvl = evolution.skillLevel[CONE_BLAST];
        float cooldown = 2.5f - lvl * 0.3f; // 2.2, 1.9, 1.6, 1.3, 1.0
        float coneRange = 130.0f + lvl * 20.0f; // 150, 170, 190, 210, 230
        int coneDmg = 3 + lvl * 2; // 5, 7, 9, 11, 13
        float coneHalfAngle = 0.7f + lvl * 0.1f; // wider cone
        
        evolution.coneBlastTimer += dt;
        if (evolution.coneBlastTimer >= cooldown) {
            evolution.coneBlastTimer = 0.0f;
            
            for (auto &e : enemies) {
                if (!e.alive) continue;
                float dx = e.x - player.x;
                float dy = e.y - player.y;
                float dist = sqrtf(dx*dx + dy*dy);
                if (dist < coneRange) {
                    float angleToEnemy = atan2f(dy, dx);
                    float angleDiff = angleToEnemy - evolution.coneBlastAngle;
                    while (angleDiff > 3.14159f) angleDiff -= 6.28318f;
                    while (angleDiff < -3.14159f) angleDiff += 6.28318f;
                    if (fabsf(angleDiff) < coneHalfAngle) {
                        e.hp -= coneDmg;
                        e.hitFlashTimer = 0.2f;
                        if (e.hp <= 0) {
                            e.alive = false;
                            evolution.enemiesKilled++;
                            int xpReward = 1;
                            if (e.isBoss) xpReward = 20 + evolution.currentWave * 5;
                            else { switch(e.enemyType) { case 0: xpReward=1; break; case 1: xpReward=3; break; case 2: xpReward=5; break; } }
                            player.score += xpReward;
                        }
                    }
                }
            }
            // Bright cone flash visual
            for (int v = 0; v < 3; v++) {
                float vAngle = evolution.coneBlastAngle + (v - 1) * 0.3f;
                float vDist = 40.0f + v * 20.0f;
                visualEffects.push_back({
                    player.x + cosf(vAngle) * vDist, player.y + sinf(vAngle) * vDist, 0.0f, 30.0f + lvl * 8.0f, 0.0f, 0.4f, RED, 3, "cone_blast"
                });
            }
        }
    }
    
    // --- ENERGY SHIELD --- (lvl scales: recharge speed)
    if (evolution.skillLevel[ENERGY_SHIELD]) {
        int lvl = evolution.skillLevel[ENERGY_SHIELD];
        float rechargeCd = 7.0f - lvl * 0.8f; // 6.2, 5.4, 4.6, 3.8, 3.0
        if (!evolution.shieldUp) {
            evolution.shieldRechargeTimer += dt;
            if (evolution.shieldRechargeTimer >= rechargeCd) {
                evolution.shieldUp = true;
                evolution.shieldRechargeTimer = 0.0f;
                visualEffects.push_back({player.x, player.y, 0.0f, player.radius + 25.0f, 0.0f, 0.6f, (Color){100, 200, 255, 200}, 0, "energy_shield"});
            }
        }
    }
    
    // --- REPULSION PULSE --- (lvl scales: cooldown, radius, force)
    if (evolution.skillLevel[REPULSION_PULSE]) {
        int lvl = evolution.skillLevel[REPULSION_PULSE];
        float cooldown = 3.5f - lvl * 0.4f; // 3.1, 2.7, 2.3, 1.9, 1.5
        float pushRadius = 100.0f + lvl * 25.0f; // 125, 150, 175, 200, 225
        float pushForce = 200.0f + lvl * 60.0f;
        int pushDmg = lvl; // 1, 2, 3, 4, 5 dmg at higher levels
        
        evolution.repulsionTimer += dt;
        if (evolution.repulsionTimer >= cooldown) {
            evolution.repulsionTimer = 0.0f;
            
            for (auto &e : enemies) {
                if (!e.alive) continue;
                float dx = e.x - player.x;
                float dy = e.y - player.y;
                float dist = sqrtf(dx*dx + dy*dy);
                if (dist < pushRadius && dist > 0.1f) {
                    float nx = dx / dist;
                    float ny = dy / dist;
                    e.x += nx * pushForce * 0.5f;
                    e.y += ny * pushForce * 0.5f;
                    e.x = std::max(0.0f, std::min((float)WORLD_W, e.x));
                    e.y = std::max(0.0f, std::min((float)WORLD_H, e.y));
                    if (pushDmg > 0) {
                        e.hp -= pushDmg;
                        e.hitFlashTimer = 0.15f;
                        if (e.hp <= 0) {
                            e.alive = false;
                            evolution.enemiesKilled++;
                            int xpReward = 1;
                            if (e.isBoss) xpReward = 20 + evolution.currentWave * 5;
                            else { switch(e.enemyType) { case 0: xpReward=1; break; case 1: xpReward=3; break; case 2: xpReward=5; break; } }
                            player.score += xpReward;
                        }
                    }
                }
            }
            // Strong pulse visual
            visualEffects.push_back({player.x, player.y, 0.0f, pushRadius, 0.0f, 0.6f, (Color){200, 150, 255, 220}, 6, "repulsion_pulse"});
        }
    }
    
    // --- FROST FIELD --- (lvl scales: radius, slow%)
    if (evolution.skillLevel[FROST_FIELD]) {
        int lvl = evolution.skillLevel[FROST_FIELD];
        float frostRadius = 80.0f + lvl * 20.0f; // 100, 120, 140, 160, 180
        float slowFactor = 0.45f - lvl * 0.05f;  // 0.40, 0.35, 0.30, 0.25, 0.20
        
        for (auto &e : enemies) {
            if (!e.alive) continue;
            float dx = e.x - player.x;
            float dy = e.y - player.y;
            float dist = sqrtf(dx*dx + dy*dy);
            if (dist < frostRadius) {
                float targetVx = (player.x - e.x);
                float targetVy = (player.y - e.y);
                float targetDist = sqrtf(targetVx*targetVx + targetVy*targetVy);
                if (targetDist > 0.1f) {
                    float baseSpeed = e.speed;
                    e.vx = (targetVx / targetDist) * baseSpeed * slowFactor;
                    e.vy = (targetVy / targetDist) * baseSpeed * slowFactor;
                }
                // Frost damage at higher levels
                if (lvl >= 3) {
                    e.hitFlashTimer = std::max(e.hitFlashTimer, 0.05f);
                }
            }
        }
    }
    
    // --- BLACK HOLE --- (lvl scales: cooldown, duration, pull, radius, dmg)
    if (evolution.skillLevel[BLACK_HOLE]) {
        int lvl = evolution.skillLevel[BLACK_HOLE];
        float cooldown = 7.0f - lvl * 0.8f; // 6.2, 5.4, 4.6, 3.8, 3.0
        float duration = 3.0f + lvl * 0.5f; // 3.5, 4.0, 4.5, 5.0, 5.5
        float bhRadius = 100.0f + lvl * 20.0f; // 120, 140, 160, 180, 200
        float pullForce = 150.0f + lvl * 40.0f;
        int bhDmg = 1 + lvl; // 2, 3, 4, 5, 6
        float dmgRadius = 15.0f + lvl * 3.0f;
        
        if (!evolution.blackHoleActive) {
            evolution.blackHoleTimer += dt;
            if (evolution.blackHoleTimer >= cooldown) {
                evolution.blackHoleTimer = 0.0f;
                evolution.blackHoleActive = true;
                evolution.blackHoleLife = duration;
                evolution.blackHoleX = player.x + GetRandomValue(-100, 100);
                evolution.blackHoleY = player.y + GetRandomValue(-100, 100);
                evolution.blackHoleX = std::max(30.0f, std::min((float)WORLD_W - 30.0f, evolution.blackHoleX));
                evolution.blackHoleY = std::max(30.0f, std::min((float)WORLD_H - 30.0f, evolution.blackHoleY));
            }
        } else {
            evolution.blackHoleLife -= dt;
            if (evolution.blackHoleLife <= 0.0f) {
                evolution.blackHoleActive = false;
            } else {
                for (auto &e : enemies) {
                    if (!e.alive) continue;
                    float dx = evolution.blackHoleX - e.x;
                    float dy = evolution.blackHoleY - e.y;
                    float dist = sqrtf(dx*dx + dy*dy);
                    if (dist < bhRadius && dist > 5.0f) {
                        float nx = dx / dist;
                        float ny = dy / dist;
                        float pullStr = pullForce * (1.0f - dist / bhRadius); // stronger near center
                        e.x += nx * pullStr * dt;
                        e.y += ny * pullStr * dt;
                    }
                    if (dist < dmgRadius) {
                        e.hp -= bhDmg;
                        e.hitFlashTimer = 0.1f;
                        if (e.hp <= 0) {
                            e.alive = false;
                            evolution.enemiesKilled++;
                            int xpReward = 1;
                            if (e.isBoss) xpReward = 20 + evolution.currentWave * 5;
                            else { switch(e.enemyType) { case 0: xpReward=1; break; case 1: xpReward=3; break; case 2: xpReward=5; break; } }
                            player.score += xpReward;
                        }
                    }
                }
            }
        }
    }
    
    // --- METEOR STRIKE --- (lvl scales: cooldown, meteor count, radius, dmg)
    if (evolution.skillLevel[METEOR_STRIKE]) {
        int lvl = evolution.skillLevel[METEOR_STRIKE];
        float cooldown = 2.0f - lvl * 0.3f; // 1.7, 1.4, 1.1, 0.8, 0.5
        int meteorCount = lvl; // 1, 2, 3, 4, 5 per wave
        float meteorRadius = 22.0f + lvl * 4.0f; // 26, 30, 34, 38, 42
        int meteorDmg = 3 + lvl * 2; // 5, 7, 9, 11, 13
        
        evolution.meteorTimer += dt;
        if (evolution.meteorTimer >= cooldown) {
            evolution.meteorTimer = 0.0f;
            for (int mc = 0; mc < meteorCount; mc++) {
                Meteor m;
                m.targetX = player.x + GetRandomValue(-160, 160);
                m.targetY = player.y + GetRandomValue(-160, 160);
                m.targetX = std::max(20.0f, std::min((float)WORLD_W - 20.0f, m.targetX));
                m.targetY = std::max(20.0f, std::min((float)WORLD_H - 20.0f, m.targetY));
                m.x = m.targetX + GetRandomValue(-50, 50);
                m.y = m.targetY - 200.0f;
                m.progress = 0.0f;
                m.radius = meteorRadius;
                m.active = true;
                meteors.push_back(m);
            }
        }
        
        // Update active meteors
        for (auto &m : meteors) {
            if (!m.active) continue;
            m.progress += dt * 2.5f; // Faster fall
            if (m.progress >= 1.0f) {
                m.active = false;
                for (auto &e : enemies) {
                    if (!e.alive) continue;
                    float dx = e.x - m.targetX;
                    float dy = e.y - m.targetY;
                    float dist = sqrtf(dx*dx + dy*dy);
                    if (dist < m.radius + 10.0f) {
                        e.hp -= meteorDmg;
                        e.hitFlashTimer = 0.2f;
                        if (e.hp <= 0) {
                            e.alive = false;
                            evolution.enemiesKilled++;
                            int xpReward = 1;
                            if (e.isBoss) xpReward = 20 + evolution.currentWave * 5;
                            else { switch(e.enemyType) { case 0: xpReward=1; break; case 1: xpReward=3; break; case 2: xpReward=5; break; } }
                            player.score += xpReward;
                        }
                    }
                }
                // Big impact visual
                visualEffects.push_back({m.targetX, m.targetY, 0.0f, m.radius + 20.0f, 0.0f, 0.6f, ORANGE, 5, "meteor"});
                visualEffects.push_back({m.targetX, m.targetY, 0.0f, m.radius * 0.5f, 0.0f, 0.3f, YELLOW, 2, ""});
            }
        }
        meteors.erase(std::remove_if(meteors.begin(), meteors.end(), [](const Meteor& m) { return !m.active; }), meteors.end());
    }
    
    // --- OVERLOAD --- (lvl scales: cooldown, radius, dmg)
    if (evolution.skillLevel[OVERLOAD]) {
        int lvl = evolution.skillLevel[OVERLOAD];
        float cooldown = 4.5f - lvl * 0.5f; // 4.0, 3.5, 3.0, 2.5, 2.0
        float overloadRadius = 120.0f + lvl * 20.0f; // 140, 160, 180, 200, 220
        int overloadDmg = 2 + lvl; // 3, 4, 5, 6, 7
        
        evolution.overloadTimer += dt;
        if (evolution.overloadTimer >= cooldown) {
            evolution.overloadTimer = 0.0f;
            
            for (auto &e : enemies) {
                if (!e.alive) continue;
                float dx = e.x - player.x;
                float dy = e.y - player.y;
                float dist = sqrtf(dx*dx + dy*dy);
                if (dist < overloadRadius) {
                    e.hp -= overloadDmg;
                    e.hitFlashTimer = 0.2f;
                    if (e.hp <= 0) {
                        e.alive = false;
                        evolution.enemiesKilled++;
                        int xpReward = 1;
                        if (e.isBoss) xpReward = 20 + evolution.currentWave * 5;
                        else { switch(e.enemyType) { case 0: xpReward=1; break; case 1: xpReward=3; break; case 2: xpReward=5; break; } }
                        player.score += xpReward;
                    }
                }
            }
            // Strong electric burst visuals
            visualEffects.push_back({player.x, player.y, 0.0f, overloadRadius, 0.0f, 0.7f, (Color){120, 180, 255, 220}, 4, "overload"});
            // Additional lightning sparks
            for (int s = 0; s < 4 + lvl; s++) {
                float sa = GetRandomValue(0, 628) / 100.0f;
                float sd = GetRandomValue(20, (int)overloadRadius);
                chainSegments.push_back({player.x, player.y, player.x + cosf(sa) * sd, player.y + sinf(sa) * sd, 0.4f, "chain_lightning"});
            }
        }
    }
    
    // --- Update chain lightning segments ---
    for (auto &seg : chainSegments) {
        seg.life -= dt;
    }
    chainSegments.erase(std::remove_if(chainSegments.begin(), chainSegments.end(), [](const ChainSegment& s) { return s.life <= 0; }), chainSegments.end());
}

void Simulador::renderSkills() {
    if (currentMode != Evolution) return;
    
    // --- ORBIT BLADES visual ---
    if (evolution.skillLevel[ORBIT_BLADES]) {
        int lvl = evolution.skillLevel[ORBIT_BLADES];
        int bladeCount = 1 + lvl;
        float orbitRadius = player.radius + 25.0f + lvl * 5.0f;
        float bladeLen = 10.0f + lvl * 3.0f;
        float bladeWidth = 3.0f + lvl * 1.0f;
        
        for (int b = 0; b < bladeCount; b++) {
            float angle = evolution.orbitAngle + b * (6.28318f / bladeCount);
            float bx = player.x + cosf(angle) * orbitRadius;
            float by = player.y + sinf(angle) * orbitRadius;
            float perpAngle = angle + 1.5708f;
            Vector2 v1 = {bx + cosf(angle) * bladeLen, by + sinf(angle) * bladeLen};
            Vector2 v2 = {bx + cosf(perpAngle) * bladeWidth, by + sinf(perpAngle) * bladeWidth};
            Vector2 v3 = {bx - cosf(perpAngle) * bladeWidth, by - sinf(perpAngle) * bladeWidth};
            Color bladeCol = {(unsigned char)(180 + lvl * 15), 220, 255, 230};
            DrawTriangle(v1, v2, v3, bladeCol);
            DrawTriangle(v1, v3, v2, bladeCol);
            DrawCircle((int)bx, (int)by, 4.0f + lvl, Fade(bladeCol, 100));
        }
    }
    
    // --- FROST FIELD visual ---
    if (evolution.skillLevel[FROST_FIELD]) {
        int lvl = evolution.skillLevel[FROST_FIELD];
        float frostRadius = 80.0f + lvl * 20.0f;
        DrawCircle((int)player.x, (int)player.y, frostRadius, (Color){100, 180, 255, (unsigned char)(30 + lvl * 8)});
        DrawCircleLines((int)player.x, (int)player.y, frostRadius, (Color){100, 180, 255, (unsigned char)(100 + lvl * 20)});
        DrawCircleLines((int)player.x, (int)player.y, frostRadius * 0.6f, (Color){150, 200, 255, (unsigned char)(60 + lvl * 15)});
    }
    
    // --- ENERGY SHIELD visual ---
    if (evolution.skillLevel[ENERGY_SHIELD]) {
        int lvl = evolution.skillLevel[ENERGY_SHIELD];
        float shieldRadius = player.radius + 6.0f + lvl * 2.0f;
        if (evolution.shieldUp) {
            float pulse = sinf(GetTime() * 6.0f) * 2.0f;
            DrawCircleLines((int)player.x, (int)player.y, (int)(shieldRadius + pulse), (Color){100, 220, 255, 220});
            DrawCircleLines((int)player.x, (int)player.y, (int)(shieldRadius + pulse + 3.0f), (Color){80, 180, 255, 120});
        } else {
            float flicker = sinf(GetTime() * 12.0f) * 0.3f + 0.3f;
            DrawCircleLines((int)player.x, (int)player.y, (int)shieldRadius, (Color){100, 200, 255, (unsigned char)(flicker * 80)});
        }
    }
    
    // --- BLACK HOLE visual ---
    if (evolution.skillLevel[BLACK_HOLE] && evolution.blackHoleActive) {
        int lvl = evolution.skillLevel[BLACK_HOLE];
        float bhPulse = sinf(GetTime() * 8.0f) * 3.0f;
        float baseSize = 10.0f + lvl * 3.0f;
        DrawCircle((int)evolution.blackHoleX, (int)evolution.blackHoleY, baseSize + bhPulse, (Color){20, 0, 40, 230});
        DrawCircleLines((int)evolution.blackHoleX, (int)evolution.blackHoleY, baseSize + 8.0f + bhPulse, (Color){180, 60, 220, 200});
        DrawCircleLines((int)evolution.blackHoleX, (int)evolution.blackHoleY, baseSize + 16.0f + bhPulse * 0.5f, (Color){140, 40, 200, 120});
    }
    
    // --- CHAIN LIGHTNING segments ---
    for (auto &seg : chainSegments) {
        float alpha = seg.life / 0.4f;
        unsigned char a = (unsigned char)(alpha * 255);
        Color lightningColor = {120, 200, 255, a};
        float midX = (seg.x1 + seg.x2) / 2.0f + GetRandomValue(-8, 8);
        float midY = (seg.y1 + seg.y2) / 2.0f + GetRandomValue(-8, 8);
        DrawLine((int)seg.x1, (int)seg.y1, (int)midX, (int)midY, lightningColor);
        DrawLine((int)midX, (int)midY, (int)seg.x2, (int)seg.y2, lightningColor);
        DrawLine((int)seg.x1+1, (int)seg.y1, (int)midX+1, (int)midY, lightningColor);
        DrawLine((int)midX+1, (int)midY, (int)seg.x2+1, (int)seg.y2, lightningColor);
    }
    
    // --- METEOR visuals ---
    for (auto &m : meteors) {
        if (!m.active) continue;
        float currentX = m.x + (m.targetX - m.x) * m.progress;
        float currentY = m.y + (m.targetY - m.y) * m.progress;
        float currentRadius = m.radius * (0.5f + m.progress * 0.5f);
        float shadowAlpha = 40.0f + m.progress * 120.0f;
        DrawCircle((int)m.targetX, (int)m.targetY, m.radius * 0.6f, (Color){255, 60, 30, (unsigned char)shadowAlpha});
        DrawCircle((int)currentX, (int)currentY, (int)currentRadius, ORANGE);
        DrawCircle((int)currentX, (int)currentY, (int)(currentRadius * 0.6f), YELLOW);
        DrawCircleLines((int)currentX, (int)currentY, (int)currentRadius, RED);
    }
}

void Simulador::resumeFromPauseMenu() {
    pauseMenu = false; 
    menuInputCooldown = 1.0f;  // Same as Resume
}

void Simulador::selectRandomGameOverMessage() {
    const char* messages[] = {
        Localization::getText("you_died"),
        Localization::getText("extinction"),
        Localization::getText("evolution_failed"),
        Localization::getText("absorbed"),
        Localization::getText("outcompeted"),
        Localization::getText("natural_selection")
    };
    int messageCount = sizeof(messages) / sizeof(messages[0]);
    int randomIndex = rand() % messageCount;
    currentGameOverMessage = messages[randomIndex];
}

void Simulador::returnToMainMenu() {
    // Reset to initial Main Menu state (same as constructor)
    showMenu = true;
    showOptions = false;
    showTutorial = false;
    pauseMenu = false;
    gameOver = false;
    running = false;
    menuTimer = 0.0f;
    timeAlive = 0.0f;
}

void Simulador::renderMenusAndUI(float delta) {
    // Calculate UI scaling - only grows when window is larger
    const float baseHeight = 1080.0f;
    const float uiScale = std::max(1.0f, GetScreenHeight() / baseHeight);
    
    // Handle language selector visibility
    LanguageSelector::setVisible(showMenu || pauseMenu);
    
    // Pause Menu
    if (pauseMenu && !gameOver && !showMenu){
        // Background gradient
        DrawRectangleGradientV(0, 0, GetScreenWidth(), GetScreenHeight(), (Color){10,10,30,255}, (Color){25,25,60,255});
        
        if (IsKeyPressed(KEY_DOWN) && menuInputCooldown <= 0) pauseSelection = (pauseSelection + 1) % 3;
        if (IsKeyPressed(KEY_UP) && menuInputCooldown <= 0) pauseSelection = (pauseSelection + 2) % 3;
        
        // Handle language selector input in pause menu
        LanguageSelector::handleInput();
        
        if ((IsKeyPressed(KEY_ENTER) || IsKeyPressed(KEY_KP_ENTER)) && menuInputCooldown <= 0){
            if (pauseSelection == 0){ resumeFromPauseMenu(); }  // Resume
            else if (pauseSelection == 1){ returnToMainMenu(); menuInputCooldown = 1.0f; }  // Menu
            else if (pauseSelection == 2){ CloseWindow(); return; }  // Quit
        }

        menuTimer += delta;
        const char* pauseTitle = Localization::getText("paused");
        Font titleFont = UIFont::getFont(UIFont::TITLE);
        float titleFontSize = 60.0f * uiScale;
        Vector2 pauseSize = MeasureTextEx(titleFont, pauseTitle, titleFontSize, 1.0f);
        DrawTextEx(titleFont, pauseTitle, (Vector2){(float)(GetScreenWidth()/2 - pauseSize.x/2), 80.0f * uiScale}, titleFontSize, 1.0f, GOLD);
        
        const char* pauseItems[3] = {Localization::getText("resume"), Localization::getText("menu"), Localization::getText("quit")};
        Font uiFont = UIFont::getFont(UIFont::UI);
        for (int i=0; i<3; i++){
            int y = 200 + i*80;
            float scaledY = y * uiScale;
            Color col = (i==pauseSelection)? GOLD : LIGHTGRAY;
            float sz = (i==pauseSelection)? 32.0f : 28.0f;
            float scaledSz = sz * uiScale;
            if (i==pauseSelection){
                DrawRectangle(GetScreenWidth()/2 - 100 * uiScale, scaledY-10, 200 * uiScale, 50 * uiScale, Fade(GOLD, 0.2f));
            }
            Vector2 textSize = MeasureTextEx(uiFont, pauseItems[i], scaledSz, 1.0f);
            DrawTextEx(uiFont, pauseItems[i], (Vector2){(float)(GetScreenWidth()/2 - textSize.x/2), (float)scaledY}, scaledSz, 1.0f, col);
        }
    }
    
    // Game Over Menu
    if (gameOver && !showMenu && !pauseMenu){
        // Background gradient
        DrawRectangleGradientV(0, 0, GetScreenWidth(), GetScreenHeight(), (Color){10,10,30,255}, (Color){25,25,60,255});
        if (IsKeyPressed(KEY_R) && menuInputCooldown <= 0){ 
            // Retry
            gameOver = false;
            running = true;
            timeAlive = 0.0f;
            
            if (currentMode == Evolution) {
                // Full Evolution Mode reset — clears all skill state
                initializeEvolution();
                meteors.clear();
                chainSegments.clear();
            } else {
                // Infinite Mode reset
                initialPopulation = 20;
                int resetWidth = WORLD_W;
                int resetHeight = WORLD_H;
                pop.inicializar(initialPopulation, resetWidth, resetHeight);
                player.radius = 12.0f;
                player.score = 0;
                nivel = 1;
                nivelMeta = 5;
                player.spriteKey = "player"; // Set player sprite key
                int ambResetWidth = WORLD_W;
                int ambResetHeight = WORLD_H;
                amb.gerarNivel(nivel, ambResetWidth, ambResetHeight);
                resources.clear();
                enemies.clear();
                levelUpAnimating = false;
                levelUpTimer = 0.0f;
            }
            menuInputCooldown = 0.5f;
        }
        if (IsKeyPressed(KEY_M) && menuInputCooldown <= 0){ 
            // Back to Menu
            gameOver = false;
            showMenu = true;
            menuInputCooldown = 0.5f;  // Reset cooldown
        }

        menuTimer += delta;
        float scale = 1.0f + 0.08f * sinf(menuTimer * 2.0f);
        const char *diedMsg = currentGameOverMessage.c_str();
        Font titleFont = UIFont::getFont(UIFont::TITLE);
        float titleFontSize = 80.0f * uiScale;
        Vector2 diedSize = MeasureTextEx(titleFont, diedMsg, titleFontSize, 1.0f);
        DrawTextEx(titleFont, diedMsg, (Vector2){(float)(GetScreenWidth()/2 - diedSize.x/2), 100.0f * uiScale}, titleFontSize, 1.0f, RED);
        
        Font uiFont = UIFont::getFont(UIFont::UI);
        float uiFontSize = 28.0f * uiScale;
        DrawTextEx(uiFont, TextFormat("%s: %i", Localization::getText("level"), nivel), (Vector2){(float)(GetScreenWidth()/2 - 100 * uiScale), 220.0f * uiScale}, uiFontSize, 1.0f, WHITE);
        
        float buttonFontSize = 24.0f * uiScale;
        DrawTextEx(uiFont, Localization::getText("press_r_retry"), (Vector2){(float)(GetScreenWidth()/2 - 130 * uiScale), 420.0f * uiScale}, buttonFontSize, 1.0f, ((((int)(menuTimer*4))%2)==0)?YELLOW:LIGHTGRAY);
        DrawTextEx(uiFont, Localization::getText("press_m_menu"), (Vector2){(float)(GetScreenWidth()/2 - 130 * uiScale), 470.0f * uiScale}, buttonFontSize, 1.0f, LIGHTGRAY);
    }
    
    // Tutorial Screen
    if (showTutorial && !showMenu && !pauseMenu){
        // Background gradient
        DrawRectangleGradientV(0, 0, GetScreenWidth(), GetScreenHeight(), (Color){10,10,30,255}, (Color){25,25,60,255});
        
        if (IsKeyPressed(KEY_SPACE) || IsKeyPressed(KEY_ENTER)){
            showTutorial = false;
            running = true;
            player.radius = 12.0f;
            player.score = 0;
            nivel = 1;
            player.spriteKey = "player"; // Set player sprite key
            nivelMeta = 5;
            levelUpAnimating = false;
            levelUpTimer = 0.0f;
            timeAlive = 0.0f;
        }
        
        menuTimer += delta;
        
        // Title
        const char* tutTitle = Localization::getText("quick_start");
        Font titleFont = UIFont::getFont(UIFont::TITLE);
        float tutTitleFontSize = 50.0f * uiScale;
        Vector2 tutSize = MeasureTextEx(titleFont, tutTitle, tutTitleFontSize, 1.0f);
        DrawTextEx(titleFont, tutTitle, (Vector2){(float)(GetScreenWidth()/2 - tutSize.x/2), (float)(GetScreenHeight()/8)}, tutTitleFontSize, 1.0f, GOLD);
        
        // Tutorial steps
        int y = 120;
        int lineHeight = 35;
        Font uiFont = UIFont::getFont(UIFont::UI);
        float titleFontSize = 20.0f * uiScale;
        float descFontSize = 14.0f * uiScale;
        
        float t1X = (float)(GetScreenWidth()/2) - MeasureTextEx(uiFont, Localization::getText("tutorial_grow_cell"), titleFontSize, 1.0f).x / 2;
        float d1X = (float)(GetScreenWidth()/2) - MeasureTextEx(uiFont, Localization::getText("tutorial_grow_cell_desc"), descFontSize, 1.0f).x / 2;
        DrawTextEx(uiFont, Localization::getText("tutorial_grow_cell"), (Vector2){t1X, (float)y * uiScale}, titleFontSize, 1.0f, SKYBLUE);
        DrawTextEx(uiFont, Localization::getText("tutorial_grow_cell_desc"), (Vector2){d1X, (float)(y + 25) * uiScale}, descFontSize, 1.0f, LIGHTGRAY);
        
        y += lineHeight * 2;
        float t2X = (float)(GetScreenWidth()/2) - MeasureTextEx(uiFont, Localization::getText("tutorial_avoid_dangers"), titleFontSize, 1.0f).x / 2;
        float d2X = (float)(GetScreenWidth()/2) - MeasureTextEx(uiFont, Localization::getText("tutorial_avoid_dangers_desc"), descFontSize, 1.0f).x / 2;
        DrawTextEx(uiFont, Localization::getText("tutorial_avoid_dangers"), (Vector2){t2X, (float)y * uiScale}, titleFontSize, 1.0f, LIME);
        DrawTextEx(uiFont, Localization::getText("tutorial_avoid_dangers_desc"), (Vector2){d2X, (float)(y + 25) * uiScale}, descFontSize, 1.0f, LIGHTGRAY);
        
        y += lineHeight * 2;
        float t3X = (float)(GetScreenWidth()/2) - MeasureTextEx(uiFont, Localization::getText("tutorial_level_up"), titleFontSize, 1.0f).x / 2;
        float d3X = (float)(GetScreenWidth()/2) - MeasureTextEx(uiFont, Localization::getText("tutorial_level_up_desc"), descFontSize, 1.0f).x / 2;
        DrawTextEx(uiFont, Localization::getText("tutorial_level_up"), (Vector2){t3X, (float)y * uiScale}, titleFontSize, 1.0f, YELLOW);
        DrawTextEx(uiFont, Localization::getText("tutorial_level_up_desc"), (Vector2){d3X, (float)(y + 25) * uiScale}, descFontSize, 1.0f, LIGHTGRAY);
        
        y += lineHeight * 2;
        float t4X = (float)(GetScreenWidth()/2) - MeasureTextEx(uiFont, Localization::getText("tutorial_gameplay_controls"), titleFontSize, 1.0f).x / 2;
        float d4X = (float)(GetScreenWidth()/2) - MeasureTextEx(uiFont, Localization::getText("tutorial_gameplay_controls_desc"), descFontSize, 1.0f).x / 2;
        DrawTextEx(uiFont, Localization::getText("tutorial_gameplay_controls"), (Vector2){t4X, (float)y * uiScale}, titleFontSize, 1.0f, ORANGE);
        DrawTextEx(uiFont, Localization::getText("tutorial_gameplay_controls_desc"), (Vector2){d4X, (float)(y + 25) * uiScale}, descFontSize, 1.0f, LIGHTGRAY);
        
        // Instructions at bottom
        float blink = (((int)(menuTimer*3))%2 == 0) ? 1.0f : 0.5f;
        float startFontSize = 16.0f * uiScale;
        DrawTextEx(uiFont, Localization::getText("press_space_start"), (Vector2){(float)(GetScreenWidth()/2 - 150 * uiScale), (float)(GetScreenHeight() - 60) * uiScale}, startFontSize, 1.0f, Fade(YELLOW, blink));
    }
    
    // Main Menu
    if (showMenu){
        if (!showOptions){
            menuTimer += delta;
            if (IsKeyPressed(KEY_DOWN) && menuInputCooldown <= 0) menuSelection = (menuSelection + 1) % 5;
            if (IsKeyPressed(KEY_UP) && menuInputCooldown <= 0) menuSelection = (menuSelection + 4) % 5;
            
            // Handle language selector input in main menu
            LanguageSelector::handleInput();
            
            if ((IsKeyPressed(KEY_ENTER) || IsKeyPressed(KEY_KP_ENTER)) && menuInputCooldown <= 0){
                if (menuSelection == 0){ 
                    showMenu = false; 
                    currentMode = Infinite;  // Start in Infinite Mode
                    // Reset game state for Infinite Mode
                    player.radius = 12.0f;
                    player.score = 0;
                    player.x = WORLD_W / 2.0f;
                    player.y = WORLD_H / 2.0f;
                    player.spriteKey = "player"; // Set player sprite key
                    nivel = 1;
                    nivelMeta = 5;
                    initialPopulation = 20;
                    pop.inicializar(initialPopulation, WORLD_W, WORLD_H);
                    amb.gerarNivel(nivel, WORLD_W, WORLD_H);
                    resources.clear();
                    enemies.clear();
                    running = true;
                    gameOver = false;
                    menuTimer = 0.0f;
                    timeAlive = 0.0f;
                    menuInputCooldown = 0.5f;  // Reset cooldown
                }
                else if (menuSelection == 1){ 
                    showMenu = false; 
                    initializeEvolution();  // Start Evolution Mode
                    menuInputCooldown = 0.5f;  // Reset cooldown
                }
                else if (menuSelection == 2){ showOptions = true; optionsSelection = 0; menuInputCooldown = 1.0f; }
                else if (menuSelection == 3){ showOptions = true; optionsSelection = 1; menuInputCooldown = 1.0f; }
                else if (menuSelection == 4){ return; }  // Quit
            }

            // Background gradient
            DrawRectangleGradientV(0, 0, GetScreenWidth(), GetScreenHeight(), (Color){10,10,30,255}, (Color){25,25,60,255});
            
            // Background effects
            for (int i=0; i<4; ++i){
                float px = sinf(menuTimer * 0.3f + i) * 100.0f + GetScreenWidth()/2;
                float py = 100.0f + cosf(menuTimer * 0.4f + i*0.8f) * 60.0f;
                DrawCircle((int)px, (int)py, 2.0f, Fade(SKYBLUE, 0.3f));
            }
            
            // Calculate UI scaling - only grows when window is larger
            const float baseHeight = 1080.0f;
            const float uiScale = std::max(1.0f, GetScreenHeight() / baseHeight);
            
            float titleScale = 1.0f + 0.08f * sinf(menuTimer * 2.0f);
            const char* title = "Pixel Game Life";
            Font titleFont = UIFont::getFont(UIFont::TITLE);
            float titleFontSize = 60.0f * uiScale;
            int tw = MeasureTextEx(titleFont, title, titleFontSize, 1.0f).x;
            float titleY = 40 * uiScale + sinf(menuTimer*1.2f) * 8.0f * uiScale;
            DrawTextEx(titleFont, title, (Vector2){(float)(GetScreenWidth()/2 - tw/2), (float)titleY}, titleFontSize, 1.0f, Fade(SKYBLUE, 0.2f));
            DrawTextEx(titleFont, title, (Vector2){(float)(GetScreenWidth()/2 - tw/2 - 2), (float)(titleY - 2)}, titleFontSize, 1.0f, Fade(SKYBLUE, 0.15f));
            DrawTextEx(titleFont, title, (Vector2){(float)(GetScreenWidth()/2 - tw/2), (float)titleY}, titleFontSize, 1.0f, SKYBLUE);
            const char* items[5] = {
        Localization::getText("infinite_mode"),
        Localization::getText("evolution_mode"),
        Localization::getText("instructions"),
        Localization::getText("achievements"),
        Localization::getText("quit")
    };
            int menuX = GetScreenWidth() / 2;
            int menuY = GetScreenHeight() / 2 - 140 * uiScale; // Apply UI scale to menu base position
            for (int i=0;i<5;i++){
                int y = menuY + i*60 * uiScale; // Apply UI scale to spacing
                float wobble = 1.0f + 0.08f * ((i==menuSelection)?sinf(menuTimer*6.0f):0.0f);
                Color col = (i==menuSelection)? GOLD : LIGHTGRAY;
                float itemSize = 32.0f * uiScale; // Apply UI scale to font size
                if (i==menuSelection) {
                    DrawRectangle(menuX - 120 * uiScale, y-10, 240 * uiScale, 50 * uiScale, Fade(GOLD, 0.2f));
                }
                Font uiFont = UIFont::getFont(UIFont::UI);
                Vector2 textSize = MeasureTextEx(uiFont, items[i], itemSize, 1.0f);
                DrawTextEx(uiFont, items[i], (Vector2){(float)(menuX - textSize.x/2), (float)y}, itemSize, 1.0f, col);
            }
            const char* helpText = Localization::getText("use_up_down");
            Font uiFont = UIFont::getFont(UIFont::UI);
            float helpFontSize = 12.0f * uiScale; // Apply UI scale to help text
            Vector2 helpTextSize = MeasureTextEx(uiFont, helpText, helpFontSize, 1.0f);
            DrawTextEx(uiFont, helpText, (Vector2){(float)(GetScreenWidth()/2 - helpTextSize.x/2), (float)(GetScreenHeight() - 50) * uiScale}, helpFontSize, 1.0f, Fade(GRAY, 0.8f));
            
            // Display global stats
            int unlockedCount = 0;
            for (auto &ach : achievements) if (ach.unlocked) unlockedCount++;
            const char* achievementsText = TextFormat("%s: %d / %zu", Localization::getText("achievements"), unlockedCount, achievements.size());
            float achievementsFontSize = 14.0f * uiScale; // Apply UI scale to achievements text
            DrawTextEx(uiFont, achievementsText, (Vector2){20.0f * uiScale, (float)(GetScreenHeight() - 30) * uiScale}, achievementsFontSize, 1.0f, SKYBLUE);
            
            // Draw language selector
            LanguageSelector::draw();
        } else {
            // Instructions submenu
            if (optionsSelection == 0 && (IsKeyPressed(KEY_BACKSPACE) || IsKeyPressed(KEY_ESCAPE))) showOptions = false;

            // Background gradient
            DrawRectangleGradientV(0, 0, GetScreenWidth(), GetScreenHeight(), (Color){10,10,30,255}, (Color){25,25,60,255});

            if (optionsSelection == 0) {
                // Instructions screen
                if (IsKeyPressed(KEY_BACKSPACE) || IsKeyPressed(KEY_ESCAPE)) showOptions = false;
                
                // Calculate UI scaling
                const float baseHeight = 1080.0f;
                const float uiScale = GetScreenHeight() / baseHeight;
                
                Font titleFont = UIFont::getFont(UIFont::TITLE);
                Font uiFont = UIFont::getFont(UIFont::UI);
                const char* title = Localization::getText("how_to_play");
                float titleFontSize = 40.0f * uiScale;
                Vector2 titleSize = MeasureTextEx(titleFont, title, titleFontSize, 1.0f);
                DrawTextEx(titleFont, title, (Vector2){(float)(width/2 - titleSize.x/2), 40.0f * uiScale}, titleFontSize, 1.0f, SKYBLUE);
                
                int instr_y = 100;
                int line_h = 26;
                float sectionFontSize = 18.0f * uiScale;
                float textFontSize = 14.0f * uiScale;
                DrawTextEx(uiFont, Localization::getText("objective"), (Vector2){40.0f * uiScale, (float)instr_y * uiScale}, sectionFontSize, 1.0f, GOLD);
                DrawTextEx(uiFont, Localization::getText("objective_desc"), (Vector2){60.0f * uiScale, (float)(instr_y + line_h) * uiScale}, textFontSize, 1.0f, LIGHTGRAY);
                
                instr_y += line_h * 3;
                DrawTextEx(uiFont, Localization::getText("controls"), (Vector2){40.0f * uiScale, (float)instr_y * uiScale}, sectionFontSize, 1.0f, GOLD);
                DrawTextEx(uiFont, Localization::getText("controls_wasd"), (Vector2){60.0f * uiScale, (float)(instr_y + line_h) * uiScale}, textFontSize, 1.0f, LIGHTGRAY);
                DrawTextEx(uiFont, Localization::getText("controls_space"), (Vector2){60.0f * uiScale, (float)(instr_y + line_h*2) * uiScale}, textFontSize, 1.0f, LIGHTGRAY);
                
                instr_y += line_h * 5;
                DrawTextEx(uiFont, Localization::getText("game_speed"), (Vector2){40.0f * uiScale, (float)instr_y * uiScale}, sectionFontSize, 1.0f, GOLD);
                DrawTextEx(uiFont, Localization::getText("game_speed_desc"), (Vector2){60.0f * uiScale, (float)(instr_y + line_h) * uiScale}, textFontSize, 1.0f, LIGHTGRAY);
                DrawTextEx(uiFont, Localization::getText("game_speed_pause"), (Vector2){60.0f * uiScale, (float)(instr_y + line_h*2) * uiScale}, textFontSize, 1.0f, LIGHTGRAY);
                
                instr_y += line_h * 4;
                DrawTextEx(uiFont, Localization::getText("progression"), (Vector2){40.0f * uiScale, (float)instr_y * uiScale}, sectionFontSize, 1.0f, GOLD);
                DrawTextEx(uiFont, Localization::getText("progression_desc"), (Vector2){60.0f * uiScale, (float)(instr_y + line_h) * uiScale}, textFontSize, 1.0f, LIGHTGRAY);
                
                instr_y += line_h * 3;
                DrawTextEx(uiFont, Localization::getText("press_esc_return"), (Vector2){(float)(width/2 - 200 * uiScale), (float)(height - 60) * uiScale}, textFontSize, 1.0f, Fade(GRAY, 0.8f));
            } else if (optionsSelection == 1) {
                // Achievements screen
                if (IsKeyPressed(KEY_BACKSPACE) || IsKeyPressed(KEY_ESCAPE)) { showOptions = false; optionsSelection = 0; }
                
                // Handle scrolling input
                if (IsKeyPressed(KEY_UP) && achievementsScrollOffset > 0) {
                    achievementsScrollOffset--;
                }
                if (IsKeyPressed(KEY_DOWN) && achievementsScrollOffset < (int)achievements.size() - maxAchievementsVisible) {
                    achievementsScrollOffset++;
                }

                // Background gradient
                DrawRectangleGradientV(0, 0, GetScreenWidth(), GetScreenHeight(), (Color){10,10,30,255}, (Color){25,25,60,255});

                // Calculate UI scaling
                const float baseHeight = 1080.0f;
                const float uiScale = GetScreenHeight() / baseHeight;

                Font titleFont = UIFont::getFont(UIFont::TITLE);
                Font uiFont = UIFont::getFont(UIFont::UI);
                const char* achTitle = Localization::getText("achievements");
                float titleFontSize = 40.0f * uiScale;
                Vector2 achTitleSize = MeasureTextEx(titleFont, achTitle, titleFontSize, 1.0f);
                DrawTextEx(titleFont, achTitle, (Vector2){(float)(width/2 - achTitleSize.x/2), 20.0f * uiScale}, titleFontSize, 1.0f, GOLD);
                
                int ach_y = 80;
                int ach_line_h = 48;
                int displayCount = (height - 140 * uiScale) / (ach_line_h * uiScale); // Apply UI scale to calculation
                
                for (int i = 0; i < maxAchievementsVisible && (i + achievementsScrollOffset) < (int)achievements.size(); i++) {
                    const auto &ach = achievements[i + achievementsScrollOffset];
                    Color col = ach.unlocked ? GOLD : DARKGRAY;
                    
                    // Draw achievement box aligned to center
                    float boxWidth = GetScreenWidth() * 0.8f;
                    float boxStart = GetScreenWidth() / 2.0f - boxWidth / 2.0f;
                    DrawRectangleLines(boxStart, ach_y * uiScale + i * ach_line_h * uiScale, boxWidth, 44 * uiScale, col);
                    if (ach.unlocked) {
                        DrawRectangle(boxStart + 1.0f, ach_y * uiScale + i * ach_line_h * uiScale + 1, boxWidth - 2.0f, 42 * uiScale, Fade(GOLD, 0.1f));
                    }
                    
                    // Draw achievement info centered
                    float nameFontSize = 16.0f * uiScale;
                    float descFontSize = 11.0f * uiScale;
                    float statusFontSize = 12.0f * uiScale;
                    
                    float nameX = (float)(GetScreenWidth()/2) - MeasureTextEx(uiFont, ach.name.c_str(), nameFontSize, 1.0f).x / 2;
                    DrawTextEx(uiFont, ach.name.c_str(), (Vector2){nameX, (float)(ach_y + i * ach_line_h + 4) * uiScale}, nameFontSize, 1.0f, col);
                    
                    float descX = (float)(GetScreenWidth()/2) - MeasureTextEx(uiFont, ach.description.c_str(), descFontSize, 1.0f).x / 2;
                    DrawTextEx(uiFont, ach.description.c_str(), (Vector2){descX, (float)(ach_y + i * ach_line_h + 23) * uiScale}, descFontSize, 1.0f, Fade(col, 0.7f));
                    
                    // Status badge logic at default edge, or keep it bottom right of box
                    if (ach.unlocked) {
                        DrawTextEx(uiFont, Localization::getText("unlocked"), (Vector2){boxStart + boxWidth - MeasureTextEx(uiFont, Localization::getText("unlocked"), statusFontSize, 1.0f).x - 10, (float)(ach_y + i * ach_line_h + 14) * uiScale}, statusFontSize, 1.0f, col);
                    } else {
                        DrawTextEx(uiFont, Localization::getText("locked"), (Vector2){boxStart + boxWidth - MeasureTextEx(uiFont, Localization::getText("locked"), statusFontSize, 1.0f).x - 10, (float)(ach_y + i * ach_line_h + 14) * uiScale}, statusFontSize, 1.0f, col);
                    }
                }
                
                // Add scrolling indicator
                if (achievements.size() > maxAchievementsVisible) {
                    const char* scrollText = TextFormat("%d / %zu", achievementsScrollOffset + 1, achievements.size());
                    DrawTextEx(uiFont, scrollText, (Vector2){(float)(width/2 - 30) * uiScale, (float)(height - 70) * uiScale}, 12.0f * uiScale, 1.0f, Fade(WHITE, 0.7f));
                }
                
                DrawTextEx(uiFont, Localization::getText("press_esc_return"), (Vector2){(float)(width/2 - 150) * uiScale, (float)(height - 40) * uiScale}, 14.0f * uiScale, 1.0f, Fade(GRAY, 0.8f));
            }
        }
    }
}

void Simulador::run(){
    // Set config flags BEFORE InitWindow
    SetConfigFlags(FLAG_WINDOW_RESIZABLE);
    // Create window with a reasonable default size (larger than base resolution)
    InitWindow(1600, 900, "Pixel Game Life");
    
    // Check if window was created successfully
    if (!IsWindowReady()) {
        // Window failed to initialize
        return;
    }
    
    // Initialize font system now that OpenGL context exists
    UIFont::initialize();
    
    // Allocate render target to hold fixed resolution map before upscaling
    worldRenderTarget = LoadRenderTexture(WORLD_W, WORLD_H);
    
    SetWindowMinSize(640, 480);
    // Disable default ESC behavior (pressing ESC closes the window in raylib)
    SetExitKey(KEY_NULL);
    SetTargetFPS(60);
    
    // Main loop - use direct rendering instead of render texture
    while (!WindowShouldClose()){
        float deltaTime = GetFrameTime();
        
        // Update menu input cooldown
        menuInputCooldown -= deltaTime;
        if (menuInputCooldown < 0) menuInputCooldown = 0;
        
        // Check for window resize
        if (IsWindowResized()) {
            windowWidth = GetScreenWidth();
            windowHeight = GetScreenHeight();
        }
        
        // Control language selector visibility based on game state
        if (showMenu || pauseMenu) {
            LanguageSelector::setVisible(true);
        } else {
            LanguageSelector::setVisible(false);
        }
        
        // ============================================
        // MAIN GAME LOOP - Core Game Systems
        // ============================================
        
        // Handle different game states
        if (showMenu) {
            // Main Menu - render directly to window
            BeginDrawing();
            ClearBackground(BLACK);
            renderMenusAndUI(GetFrameTime());
            Transition::update(GetFrameTime());
            Transition::draw(player.x, player.y, player.radius);
            EndDrawing();
            continue;
        }
        
        if (pauseMenu) {
            // Pause Menu - render directly to window
            BeginDrawing();
            ClearBackground(BLACK);
            renderMenusAndUI(GetFrameTime());
            Transition::update(GetFrameTime());
            Transition::draw(player.x, player.y, player.radius);
            EndDrawing();
            continue;
        }
        
        if (gameOver) {
            // Game Over - render directly to window
            BeginDrawing();
            ClearBackground(BLACK);
            renderMenusAndUI(GetFrameTime());
            Transition::update(GetFrameTime());
            Transition::draw(player.x, player.y, player.radius);
            EndDrawing();
            continue;
        }
        
                
                
                
        // ESC toggle for Pause Menu - single authoritative handler
        if (IsKeyPressed(KEY_ESCAPE)) {
            if (pauseMenu) {
                // Same behavior as Resume
                pauseMenu = false;
                menuInputCooldown = 1.0f;
                continue; // stop processing the rest of the frame
            }
            else if (!showMenu && !gameOver && !showTutorial && !showOptions) {
                // Gameplay active → open pause
                pauseMenu = true;
                menuInputCooldown = 1.0f;
                continue;
            }
        }
        if (IsKeyPressed(KEY_SPACE)) pauseMenu = !pauseMenu;
        
        // Handle language selector input
        LanguageSelector::handleInput();
        
        // Handle upgrade menu input for Evolution Mode
        if (currentMode == Evolution && evolution.upgradeMenuVisible) {
            handleUpgradeMenuInput();
        }
        
        if (IsKeyPressed(KEY_UP)) {
        int newIndex = clampSpeedIndex(currentSpeedIndex + 1, 0, 2);
        currentSpeedIndex = getValidSpeedIndex(newIndex, currentMode);
    }
    if (IsKeyPressed(KEY_DOWN)) {
        int newIndex = clampSpeedIndex(currentSpeedIndex - 1, 0, 2);
        currentSpeedIndex = getValidSpeedIndex(newIndex, currentMode);
    }

        // Speed multiplier options: (0.5x, 1.0x, 2.0x)
        float speedMultiplier = 0.5f;
        if (currentSpeedIndex == 1) speedMultiplier = 1.0f;
        else if (currentSpeedIndex == 2) speedMultiplier = 2.0f;

        // Pause updates when in pause menu, during level-up animation (Infinite Mode only), or upgrade menu (Evolution only)
        float delta = (pauseMenu || (currentMode == Infinite && levelUpAnimating) || (currentMode == Evolution && evolution.upgradeMenuVisible)) ? 0.0f : (GetFrameTime() * speedMultiplier);
        const float HITBOX_SCALE = 0.90f; // slightly smaller effective hitboxes for player and enemies
        
        // Update player highlight timer (always runs, even during pause)
        if (playerHighlightActive) {
            playerHighlightTimer += GetFrameTime();
            if (playerHighlightTimer > playerHighlightDuration) {
                playerHighlightActive = false;
            }
        }
        // update background and screen shake
        bgOffset += delta * 24.0f;
        if (screenShakeTimer > 0.0f) { screenShakeTimer -= delta; screenShake = screenShakeTimer * 6.0f; } else { screenShake = 0.0f; }
        float sx = 0.0f, sy = 0.0f;
        if (screenShake > 0.0f) { sx = (GetRandomValue(-100,100)/100.0f) * screenShake; sy = (GetRandomValue(-100,100)/100.0f) * screenShake; }
        
        // Update time alive and check achievements
        if (!pauseMenu && !gameOver && !showMenu) timeAlive += delta;
        checkAchievements();
        
        // Update campaign mode - now handled by updateCampaign()
        // Legacy campaign update methods removed for survival-run system

        // player movement (WASD) with environment effects
        float playerSpeed = player.speed;
        for (auto &mo: amb.objetos){
            if (mo.tipo == 2){ // building slows player inside
                if (fabs(player.x - mo.x) < mo.w*0.5f && fabs(player.y - mo.y) < mo.h*0.5f) playerSpeed *= 0.55f;
            }
        }
        if (IsKeyDown(KEY_W)) player.y -= playerSpeed * delta;
        if (IsKeyDown(KEY_S)) player.y += playerSpeed * delta;
        if (IsKeyDown(KEY_A)) player.x -= playerSpeed * delta;
        if (IsKeyDown(KEY_D)) player.x += playerSpeed * delta;
        // clamp - use different bounds for Evolution Mode
        player.x = std::clamp(player.x, player.radius, (float)WORLD_W - player.radius);
        player.y = std::clamp(player.y, player.radius, (float)WORLD_H - player.radius);

        // Hole.io-style eating: automatically consume organisms smaller than hole
        for (int i = 0; i < (int)pop.individuos.size(); ++i){
            auto &o = pop.individuos[i];
            if (!o.vivo) continue;
            float osize = 4 + o.energia * 0.05f; if (osize>12) osize=12;
            float dx = o.x - player.x; float dy = o.y - player.y; float d = sqrtf(dx*dx + dy*dy);
            if (d < player.radius * HITBOX_SCALE && player.radius > osize * 1.05f){
                // eat
                o.vivo = false;
                // growth proportional to organism size (Infinite Mode only)
                if (currentMode == Infinite) {
                    player.radius += osize * 0.12f;
                }
                player.score += 1;
                // spawn satisfying particles
                spawnParticles(o.x, o.y, 14, 255, 200, 80, 200);
            }
        }

        // Death check
        if (player.radius <= 0.0f){
            gameOver = true;
            running = false;
            menuTimer = 0.0f;
            
            // End survival run if in Evolution mode
            if (currentMode == Evolution) {
                evolution.isActive = false;
            }
            
            // Select random game over message
            selectRandomGameOverMessage();
            // Add death screen shake
            screenShake = 15.0f;
            screenShakeTimer = 0.5f;
        }

        // Level progression based on score - Infinite Mode and Evolution Mode
        if (player.score >= nivelMeta){
            if (currentMode == Infinite) {
                // Infinite Mode: traditional level-up with enemy reset
                // advance
                nivel++;
                nivelMeta += nivel * 5;
                initialPopulation = std::min(400, initialPopulation + 8);
                pop.inicializar(initialPopulation, WORLD_W, WORLD_H);
                amb.gerarNivel(nivel, WORLD_W, WORLD_H);
                resources.clear();
                player.radius = 12.0f;
                player.highestLevel = std::max(player.highestLevel, nivel);
                spawnParticles(player.x, player.y, 40, 255, 180, 80, 220);
                // start level-up animation - ONLY for Infinite Mode
                levelUpAnimating = true; levelUpTimer = 0.0f;
                // start player highlight with enhanced pulse
                playerHighlightActive = true; playerHighlightTimer = 0.0f;
                // Add level-up screen shake
                screenShake = 8.0f;
                screenShakeTimer = 0.3f;
                // spawn enemies for new level with increased difficulty - ONLY for Infinite Mode
                enemies.clear();
                int enemyCount = std::min(12, 2 + nivel);
                for (int ei=0; ei<enemyCount; ++ei){ 
                    Enemy en; 
                    // Spawn with collision safety
                    float spawnX, spawnY;
                    bool validSpawn = false;
                    int attempts = 0;
                    while (!validSpawn && attempts < Collision::SPAWN_ATTEMPTS) {
                        spawnX = GetRandomValue(40, WORLD_W-40); 
                        spawnY = GetRandomValue(40, WORLD_H-40);
                        en.radius = 10.0f + nivel * 2.5f + (float)GetRandomValue(-5, 8);
                        validSpawn = Collision::isValidSpawnPosition(spawnX, spawnY, en.radius, enemies, player.x, player.y, player.radius);
                        attempts++;
                    }
                    
                    if (!validSpawn) continue; // Skip spawn if no valid position found
                    
                    en.x = spawnX; 
                    en.y = spawnY; 
                    en.vx = en.vy = 0; 
                    en.speed = 60.0f + nivel * 10.0f; 
                    en.alive = true; 
                    en.damage = 2 + nivel * 2;
                    en.eyeType = GetRandomValue(0, 7);  // 8 eye types
                    en.mouthType = GetRandomValue(0, 5);  // 6 mouth types  
                    en.extraType = GetRandomValue(0, 3);  // 4 extra types
                    enemies.push_back(en); 
                }
            } else if (currentMode == Evolution) {
                // Evolution Mode: slower progression
                nivel++;
                // Slower XP progression: baseXP * levelMultiplier
                int baseXP = 5; // Start with 5 kills for level 1
                int levelMultiplier = nivel; // Linear scaling
                nivelMeta += baseXP * levelMultiplier;
                player.highestLevel = std::max(player.highestLevel, nivel);
                evolution.playerLevel = nivel;
                spawnParticles(player.x, player.y, 40, 255, 180, 80, 220);
                
                // Show upgrade menu for Evolution level-up
                evolution.upgradeMenuVisible = true;
                generateUpgradeChoices();
                
                // Add level-up screen shake for Evolution too
                screenShake = 8.0f;
                screenShakeTimer = 0.3f;
            }
        }
        
        // Evolution Mode enemy spawning - wave-based system
        if (currentMode == Evolution && evolution.isActive && !evolution.upgradeMenuVisible) {
            // Update spawn timer
            evolution.spawnTimer -= delta;
            
            // Spawn enemies for current wave
            if (evolution.enemiesSpawned < evolution.enemiesInWave && evolution.spawnTimer <= 0.0f) {
                // Calculate next spawn interval based on wave (gradual pressure heavily increased)
                // Spawn interval drops down to 0.05 instantly creating intense spawn density
                float spawnInterval = std::max(0.05f, 0.8f - evolution.currentWave * 0.05f);
                
                // Check if this should be a boss spawn
                bool spawnBoss = evolution.bossWave && evolution.enemiesSpawned == 0;
                
                if (spawnBoss) {
                    spawnEvolutionEnemy(true); // Spawn boss
                    evolution.enemiesSpawned++;
                    // Give a slightly longer pause after spawning a boss
                    evolution.spawnTimer = spawnInterval * 3.0f;
                } else {
                    spawnEvolutionEnemy(false); // Spawn normal enemy
                    evolution.enemiesSpawned++;
                    evolution.spawnTimer = spawnInterval;
                }
            }
        }

        if (running) pop.atualizar(amb, delta, WORLD_W, WORLD_H);
        
        // Update Evolution Mode
        updateEvolution(delta);

        // resources spawn - maintain consistent amount
        resourceTimer -= delta;
        int activeResources = 0;
        for (auto &res: resources) if (res.active) activeResources++;
        
        // First spawn: spawn initial resources gradually (less overwhelming) - NOT for Evolution Mode
        if (!firstSpawnDone && activeResources < 10 && currentMode != Evolution){
              if (resourceTimer <= 0.0f) {
                  resourceTimer = 0.15f; // fast initial spawn
                  Resource r; 
                  r.x = GetRandomValue(40, WORLD_W-40); 
                  r.y = GetRandomValue(40, WORLD_H-40);
                  r.value = 0; r.active = true;
                  int roll = GetRandomValue(0,100);
                  if (roll < 60 - nivel*5) { r.tier = 0; r.sizeRadius = 3.0f; r.points = 1; }
                  else if (roll < 85 - nivel*3) { r.tier = 1; r.sizeRadius = 6.0f; r.points = 3; }
                  else if (roll < 95) { r.tier = 2; r.sizeRadius = 10.0f; r.points = 6; }
                  else { r.tier = 3; r.sizeRadius = 18.0f; r.points = 12; }
                  resources.push_back(r);
              }
        } else if (activeResources >= 10 && !firstSpawnDone) {
              firstSpawnDone = true;
        }
        
        // Normal spawn: maintain resources during gameplay
        if (firstSpawnDone && resourceTimer <= 0.0f && activeResources < 14 && currentMode != Evolution) {
              float spawnRate = 0.8f; // default spawn rate
              
              // Use evolution-specific spawn rate if in evolution mode
              if (currentMode == Evolution) {
                  spawnRate = 1.0f; // Consistent XP spawn rate for Evolution Mode
              }
              
              resourceTimer = spawnRate;
              Resource r; 
              r.x = GetRandomValue(40, WORLD_W-40); 
              r.y = GetRandomValue(40, WORLD_H-40);
              r.value = 0; r.active = true;
              int roll = GetRandomValue(0,100);
              if (roll < 60 - nivel*5) { r.tier = 0; r.sizeRadius = 3.0f; r.points = 1; }
              else if (roll < 85 - nivel*3) { r.tier = 1; r.sizeRadius = 6.0f; r.points = 3; }
              else if (roll < 95) { r.tier = 2; r.sizeRadius = 10.0f; r.points = 6; }
              else { r.tier = 3; r.sizeRadius = 16.0f; r.points = 12; }
              resources.push_back(r);
        }

        // check resource collisions with accurate circle-circle collision
        for (auto &res: resources){
            if (!res.active) continue;
            
            // organisms may eat resources if close
            for (auto &o: pop.individuos){
                if (!o.vivo) continue;
                float dx = o.x - res.x; 
                float dy = o.y - res.y; 
                float distSq = dx*dx + dy*dy;  // squared distance
                float collisionDist = 12.0f;  // organism collision radius
                if (distSq < collisionDist * collisionDist){ 
                    o.energia += (int)res.value; 
                    res.active = false; 
                    break; 
                }
            }
            
            if (!res.active) continue;
            
            // player collects resource - accurate circle-circle collision - NOT for Evolution Mode
            if (currentMode != Evolution) {
                float dxp = player.x - res.x; 
                float dyp = player.y - res.y; 
                float distSq = dxp*dxp + dyp*dyp;  // squared distance
                float collisionRadius = player.radius * HITBOX_SCALE + res.sizeRadius;  // both radii
                if (distSq < collisionRadius * collisionRadius){ 
                    player.radius += res.value * 0.06f; 
                    player.score += 1; 
                    res.active = false; 
                    
                    // Enhanced XP pickup particles with burst effect
                    for (int i = 0; i < 12; i++) {
                        float angle = (float)i / 12.0f * 2.0f * PI;
                        float speed = 2.0f + (float)(rand() % 100) / 100.0f;
                        float pvx = cosf(angle) * speed;
                        float pvy = sinf(angle) * speed;
                        particles.push_back({res.x, res.y, pvx, pvy, 0.4f, 200, 240, 80, 255});
                    } 
                }
            }
        }

        // RENDER GAME WORLD TO TEXTURE (Fixed 900x600)
        BeginTextureMode(worldRenderTarget);
        ClearBackground(biomeBackgroundColor);
        
        // ============================================
        // CAMERA SYSTEM - REMOVED
        // ============================================
        
        // Render world elements
        renderMapZones();
        
        // layered parallax background - changes by level
        Color bgColor1, bgColor2, layer1Col, layer2Col, layer3Col;
        
        // Theme system - simplified for survival-run
        Theme currentTheme;
        if (currentMode == Evolution) {
            // Use wave-based theming for Evolution Mode
            int wave = evolution.currentWave;
            Theme survivalThemes[] = {
                {{25,20,15,255}, {35,30,20,255}, {40,35,25,40}, {45,40,30,35}, {50,45,35,28}, {200,150,100,255}}, // Wave 1-2: Skin theme
                {{20,15,10,255}, {30,20,15,255}, {35,25,15,40}, {40,30,20,35}, {45,35,25,28}, {180,100,80,255}},   // Wave 3-4: Tissues theme
                {{15,5,5,255}, {25,10,10,255}, {30,15,15,40}, {35,20,20,35}, {40,25,25,28}, {150,50,50,255}},     // Wave 5-6: Bloodstream theme
                {{25,15,20,255}, {35,25,30,255}, {40,30,35,40}, {45,35,40,35}, {50,40,45,28}, {200,100,150,255}},   // Wave 7-8: Lungs theme
                {{20,10,15,255}, {30,20,25,255}, {35,25,30,40}, {40,30,35,35}, {45,35,40,28}, {180,80,120,255}},     // Wave 9-10: Organs theme
                {{10,5,15,255}, {20,15,25,255}, {25,20,30,40}, {30,25,35,35}, {35,30,40,28}, {120,80,200,255}}       // Wave 11+: Brain theme
            };
            int themeCount = sizeof(survivalThemes) / sizeof(survivalThemes[0]);
            int themeIndex = std::min((wave - 1) / 2, themeCount - 1);
            currentTheme = survivalThemes[themeIndex];
        } else {
            // Infinite mode themes
            Theme themes[] = {
                {{6,10,22,255}, {16,20,46,255}, {10,40,80,40}, {15,50,110,35}, {20,70,150,28}, {100,150,255,255}},
                {{10,15,8,255}, {20,35,15,255}, {30,60,30,40}, {40,80,40,35}, {50,100,50,28}, {80,200,80,255}},
                {{15,8,20,255}, {30,15,45,255}, {60,30,80,40}, {80,40,110,35}, {100,50,140,28}, {200,100,255,255}},
                {{25,10,5,255}, {45,20,10,255}, {100,50,20,40}, {130,70,30,35}, {160,90,40,28}, {255,100,50,255}},
                {{15,20,25,255}, {25,35,45,255}, {40,80,100,40}, {60,110,130,35}, {80,140,160,28}, {150,200,255,255}},
                {{25,20,10,255}, {45,35,20,255}, {80,60,30,40}, {110,80,40,35}, {140,100,50,28}, {255,200,100,255}}
            };
            int themeCount = sizeof(themes) / sizeof(themes[0]);
            currentTheme = themes[(nivel - 1) % themeCount];
        }
        
        // Use current theme colors
        bgColor1 = currentTheme.bg1;
        bgColor2 = currentTheme.bg2;
        layer1Col = currentTheme.bubble1;
        layer2Col = currentTheme.bubble2;
        layer3Col = currentTheme.bubble3;
        
        DrawRectangleGradientV(0,0,GetScreenWidth(),GetScreenHeight(), bgColor1, bgColor2);
        
        for (int layer=0; layer<3; ++layer){
            float speed = 6.0f * (layer+1);
            float yoff = fmodf(bgOffset * (0.2f * (layer+1)), 200.0f);
            Color col = (layer==0)? layer1Col : (layer==1)? layer2Col : layer3Col;
            int size = 36 - layer*6;
            
            // Draw bubbles for all themes (simple and consistent) - do NOT apply camera offset (parallax background)
            for (int i=-2;i< (GetScreenWidth()/120)+3;i++){
                float xx = i*120.0f + fmodf(bgOffset*speed, 120.0f) - 60.0f;
                float yy = 40.0f + layer*60.0f + sinf((xx+bgOffset)*0.01f + layer)*14.0f;
                
                // Background bubbles are parallax, do NOT apply camera offset
                
                DrawCircle((int)xx, (int)(yy + yoff), size, col);
                DrawCircleLines((int)xx, (int)(yy + yoff), size-2, Fade(col, 0.6f));
            }
        }
        // no map objects (houses removed)
        // Organisms - NOT for Evolution Mode (these are old XP/resource visuals)
        if (currentMode != Evolution) {
            for (auto &o: pop.individuos){
                if (!o.vivo) continue;
                float tamanho = 4 + o.energia * 0.05f; if (tamanho>12) tamanho=12;
                o.desenhar(tamanho);
            }
        }

        // draw resources (standardized XP types) - NOT for Evolution Mode
        if (currentMode != Evolution) {
            for (auto &res: resources){ 
                if (!res.active) continue; 
                Color c;
                switch (res.tier) {
                    case 0: c = SKYBLUE; break;     // Small XP - cyan (using SKYBLUE)
                    case 1: c = GREEN; break;       // Medium XP - green  
                    case 2: c = PURPLE; break;      // Large XP - purple
                    case 3: c = GOLD; break;        // Rare XP - gold (slightly larger)
                    default: c = SKYBLUE; break;
                }
                DrawCircle((int)res.x,(int)res.y,(int)res.sizeRadius,c); 
                DrawCircleLines((int)res.x,(int)res.y,(int)res.sizeRadius, WHITE); 
            }
        }
        
        // Debug hitbox visualization - NOT for Evolution Mode
        if (debugHitboxes && currentMode != Evolution) {
            // Draw player hitbox
            DrawCircleLines((int)player.x, (int)player.y, (int)(player.radius * HITBOX_SCALE), YELLOW);
            
            // Draw resource hitboxes
            for (auto &res: resources) {
                if (!res.active) continue;
                DrawCircleLines((int)res.x, (int)res.y, (int)res.sizeRadius, GREEN);
            }
        }

        // draw player with sprite or fallback to primitive
        drawEntityWithSprite(player.spriteKey, player.x, player.y, player.radius, BLACK);
        
        // Add eyes to player (only if using primitive fallback)
        if (!AssetManager::hasSprite(player.spriteKey)) {
            float eyeOffset = player.radius * 0.35f;
            float eyeSize = player.radius * 0.18f;
            DrawCircle((int)(player.x - eyeOffset), (int)(player.y - eyeOffset), (int)eyeSize, WHITE);
            DrawCircle((int)(player.x + eyeOffset), (int)(player.y - eyeOffset), (int)eyeSize, WHITE);
        }
        // subtle pulse around player when big
        if (player.radius > 30.0f) DrawCircleLines((int)player.x,(int)player.y, player.radius + 6.0f * (sinf((menuTimer)*3.0f)*0.25f+0.75f), Fade(WHITE, 0.08f));
        
        // Player highlight effect for new level
        if (playerHighlightActive) {
            float t = playerHighlightTimer / playerHighlightDuration;
            float pulse = sinf(playerHighlightTimer * 4.0f) * 0.3f + 0.7f;  // Pulsating between 0.4 and 1.0
            float alpha = (1.0f - t) * pulse;  // Fade out over time
            float highlightRadius = player.radius + 15.0f + sinf(playerHighlightTimer * 6.0f) * 5.0f;
            DrawCircleLines((int)player.x, (int)player.y, (int)highlightRadius, Fade(YELLOW, alpha));
            // Add a second ring for more visibility
            DrawCircleLines((int)player.x, (int)player.y, (int)(highlightRadius + 8.0f), Fade(YELLOW, alpha * 0.5f));
        }
        
        // Generate electric particles for Neural biome
        if (currentBiome == NEURAL && rand() % 30 == 0) {
            float px = (float)(rand() % WORLD_W);
            float py = (float)(rand() % WORLD_H);
            float pvx = ((float)(rand() % 100 - 50)) / 50.0f;
            float pvy = ((float)(rand() % 100 - 50)) / 50.0f;
            particles.push_back({px, py, pvx, pvy, 0.5f, 100, 150, 255, 200});
        }
        
        // update and draw particles
        for (int i = (int)particles.size()-1; i>=0; --i){
            Particle &p = particles[i];
            p.x += p.vx * delta;
            p.y += p.vy * delta;
            p.vx *= 0.98f; p.vy *= 0.98f;
            p.life -= delta * 1.0f;
            if (p.life <= 0.0f){ particles.erase(particles.begin() + i); continue; }
            Color col = {(unsigned char)p.r, (unsigned char)p.g, (unsigned char)p.b, (unsigned char)(p.a * p.life)};
            float particleSize = 2.0f * p.life + 1.5f;
            if (particleSize >= 1.5f) DrawCircle((int)p.x, (int)p.y, particleSize, col);
        }
        // level-up animation overlay world-space logic (particles) - ONLY for Infinite Mode
        if (currentMode == Infinite && levelUpAnimating){
            levelUpTimer += GetFrameTime();
            // small celebratory particles during animation
            if ((int)(levelUpTimer*10) % 3 == 0) spawnParticles(WORLD_W/2 + GetRandomValue(-80,80), WORLD_H/2 + GetRandomValue(-40,40), 6, 255, 200, 120, 200);
            if (levelUpTimer > levelUpDuration) levelUpAnimating = false;
        }
        // check collisions: player with map objects
        for (auto &mo: amb.objetos){ if (!mo.active) continue; if (!mo.consumable) continue; float dx = mo.x - player.x; float dy = mo.y - player.y; float d = sqrtf(dx*dx+dy*dy); if (d < player.radius * HITBOX_SCALE + mo.sizeRadius * 0.8f && player.radius > mo.sizeRadius * 0.7f){ mo.active = false; player.score += mo.points; player.radius += mo.sizeRadius * 0.06f; spawnParticles(mo.x,mo.y,24,255,200,120,220); } }

        // update enemies and let them eat resources - Evolution Mode changes
        for (int i=(int)enemies.size()-1;i>=0;--i){ 
            auto &e = enemies[i]; 
            if (!e.alive) { enemies.erase(enemies.begin()+i); continue; } 
            
            // Update hit flash timer
            if (e.hitFlashTimer > 0) {
                e.hitFlashTimer -= GetFrameTime();
            }
            
            // enemies chase and eat organisms like player does (Infinite Mode only)
            if (currentMode == Infinite) {
                for (int oi=0; oi<(int)pop.individuos.size(); ++oi){
                    auto &o = pop.individuos[oi];
                    if (!o.vivo) continue;
                    float osize = 4 + o.energia * 0.05f; if (osize>12) osize=12;
                    float edx = o.x - e.x; float edy = o.y - e.y; float ed = sqrtf(edx*edx + edy*edy);
                    if (ed < e.radius * HITBOX_SCALE && e.radius > osize * 1.05f){
                        o.vivo = false;
                        e.radius += osize * 0.12f;
                        spawnParticles(o.x, o.y, 8, 200, 100, 50, 180);
                    }
                }
            }
            
            // enemies chase player
            float dx = player.x - e.x; float dy = player.y - e.y; float dist = sqrtf(dx*dx + dy*dy); 
            if (dist > 1.0f) { 
                float actualSpeed = e.speed * biomeEnemySpeedMultiplier;
                e.vx += (dx/dist) * actualSpeed * delta * 0.8f; 
                e.vy += (dy/dist) * actualSpeed * delta * 0.8f; 
            }
            e.x += e.vx * delta; e.y += e.vy * delta; e.vx *= 0.86f; e.vy *= 0.86f;
            
            // Clamp enemies to world bounds (ONLY in Infinite Mode)
            if (currentMode != Evolution) {
                e.x = std::max(e.radius, std::min((float)WORLD_W - e.radius, e.x));
                e.y = std::max(e.radius, std::min((float)WORLD_H - e.radius, e.y));
            }
            
            // Check collision with player
            float playerDist = sqrtf((e.x - player.x) * (e.x - player.x) + (e.y - player.y) * (e.y - player.y));
            if (playerDist < e.radius + player.radius) {
                // In Evolution Mode, player takes damage from enemy
                if (currentMode == Evolution) {
                    // Check Energy Shield
                    if (evolution.skillLevel[ENERGY_SHIELD] && evolution.shieldUp) {
                        // Shield absorbs the hit
                        evolution.shieldUp = false;
                        evolution.shieldRechargeTimer = 0.0f;
                        // Knock back the enemy
                        float kdx = e.x - player.x;
                        float kdy = e.y - player.y;
                        float kdist = sqrtf(kdx*kdx + kdy*kdy);
                        if (kdist > 0.1f) {
                            e.x += (kdx / kdist) * 60.0f;
                            e.y += (kdy / kdist) * 60.0f;
                        }
                        // Shield break visual
                        visualEffects.push_back({player.x, player.y, 0.0f, player.radius + 20.0f, 0.0f, 0.4f, (Color){100, 200, 255, 255}, 5});
                        screenShake = 6.0f;
                        screenShakeTimer = 0.2f;
                    } else {
                        gameOver = true;
                        selectRandomGameOverMessage();
                    }
                } else {
                    // Infinite Mode logic (player can eat enemies)
                    bool isVulnerable = player.radius > e.radius * 1.05f;
                    
                    if (isVulnerable) {
                        e.alive = false;
                        player.radius += e.radius * 0.08f;
                        player.score += 1;
                        
                        // Add enemy-colored particles for visual feedback
                        Color enemyColor = e.radius < player.radius ? GREEN : RED;
                        spawnEnemyParticles(e.x, e.y, enemyColor);
                        
                        // Enhanced enemy pop effect
                        for (int i = 0; i < 20; i++) {
                            float angle = (float)i / 20.0f * 2.0f * PI;
                            float speed = 3.0f + (float)(rand() % 150) / 100.0f;
                            float pvx = cosf(angle) * speed;
                            float pvy = sinf(angle) * speed;
                            particles.push_back({e.x, e.y, pvx, pvy, 0.3f, enemyColor.r, enemyColor.g, enemyColor.b, 255});
                        }
                        
                        spawnParticles(e.x,e.y,18,255,80,80,220);
                        // Check for kill achievements
                        static int eKilled = 0;
                        eKilled++;
                        if (eKilled >= 10 && eKilled < 50) {
                            for (auto &ach : achievements) {
                                if (ach.id == "kill_10_antibodies") ach.unlocked = true;
                            }
                        } else if (eKilled >= 50) {
                            for (auto &ach : achievements) {
                                if (ach.id == "kill_50_antibodies") ach.unlocked = true;
                            }
                        }
                    } else {
                        // Enemy eats player
                        gameOver = true;
                        selectRandomGameOverMessage();
                    }
                }
            }
            
            // Draw enemy with new color system
            Color enemyColor;
            if (currentMode == Evolution) {
                enemyColor = e.color;
                if (e.hitFlashTimer > 0) {
                    enemyColor = WHITE;
                }
            } else {
                // Infinite Mode: keep old size-based color logic
                enemyColor = e.radius < player.radius ? GREEN : RED;
            }
            
            DrawCircle((int)e.x, (int)e.y, (int)e.radius, enemyColor);
            DrawCircleLines((int)e.x, (int)e.y, (int)e.radius, WHITE);
            
            // Draw boss indicator
            if (currentMode == Evolution && e.isBoss) {
                Font uiFont = UIFont::getFont(UIFont::UI);
                const char* bossText = Localization::getText("boss");
                Vector2 textSize = MeasureTextEx(uiFont, bossText, 12.0f, 1.0f);
                DrawTextEx(uiFont, bossText, 
                          (Vector2){e.x - textSize.x/2, e.y - e.radius - 15.0f}, 
                          12.0f, 1.0f, RED);
            }
            
            // Draw procedural face
            drawEnemyFace(e.x, e.y, e.radius, e.eyeType, e.mouthType, e.extraType);
        }
        
        // Separate overlapping enemies
        Collision::separateEnemies(enemies, 2.0f, currentMode == Evolution);
        
        // Evolution Mode: render projectiles and visual effects
        if (currentMode == Evolution) {
            // Render visual effects (behind enemies)
            for (auto &effect : visualEffects) {
                float alpha = 1.0f - (effect.life / effect.maxLife);
                Color effectColor = Fade(effect.color, alpha * 255);
                
                if (effect.type == 0) { // Expanding ring
                    DrawCircleLines((int)effect.x, (int)effect.y, (int)effect.radius, effectColor);
                } else { // Burst effect
                    DrawCircle((int)effect.x, (int)effect.y, (int)effect.radius, effectColor);
                }
            }
            
            // Render projectiles
            for (auto &p : projectiles) {
                if (!p.alive) continue;
                
                // Calculate rotation based on movement direction
                float rotation = atan2f(p.vy, p.vx) * (180.0f / PI);
                
                drawEntityWithSprite(p.spriteKey, p.x, p.y, p.radius, p.color, rotation);
            }
            
            // Skill indicators moved to screen-space render
        }
        
        // Update and draw transition animation in world texture
        Transition::update(delta);
        Transition::draw(player.x, player.y, player.radius);

        EndTextureMode();
        
        BeginDrawing();
        ClearBackground(BLACK);
        
        // Draw the scaled world texture centered
        float scaleX = (float)GetScreenWidth() / WORLD_W;
        float scaleY = (float)GetScreenHeight() / WORLD_H;
        float scale = std::min(scaleX, scaleY);
        Rectangle source = { 0.0f, 0.0f, (float)worldRenderTarget.texture.width, -(float)worldRenderTarget.texture.height };
        Rectangle dest = { 
            (GetScreenWidth() - (float)WORLD_W * scale) / 2.0f, 
            (GetScreenHeight() - (float)WORLD_H * scale) / 2.0f, 
            (float)WORLD_W * scale, 
            (float)WORLD_H * scale 
        };
        DrawTexturePro(worldRenderTarget.texture, source, dest, (Vector2){0.0f, 0.0f}, 0.0f, WHITE);
        
        // Calculate coordinates of the 900x600 game view inside the window
        float drawW = WORLD_W * scale;
        float drawH = WORLD_H * scale;
        float offsetX = (GetScreenWidth() - drawW) / 2.0f;
        float offsetY = (GetScreenHeight() - drawH) / 2.0f;
        
        // Calculate UI scaling bound to the game view scale
        float uiScl = std::min(std::max(1.0f, scale), 2.5f);
        
        // Speed HUD
        bool hudVisible = (currentMode != Evolution || !evolution.upgradeMenuVisible);
        
        if (hudVisible) {
            const char* speedNames[] = {
                Localization::getText("slow"),
                Localization::getText("normal"), 
                Localization::getText("fast")
            };
            Color speedColors[] = {BLUE, WHITE, RED};
            Font uiFont = UIFont::getFont(UIFont::UI);
            const char* speedText = TextFormat("%s: %s", Localization::getText("speed"), speedNames[currentSpeedIndex]);
            Vector2 speedTextSize = MeasureTextEx(uiFont, speedText, 14.0f * uiScl, 1.0f);
            DrawTextEx(uiFont, speedText, (Vector2){offsetX + drawW - speedTextSize.x - 20.0f * uiScl, offsetY + 50.0f * uiScl}, 14.0f * uiScl, 1.0f, speedColors[currentSpeedIndex]);
        }
        
        // Evolution Mode UI
        if (currentMode == Evolution) {
            renderEvolutionUI();
        }
        
        // level-up animation overlay screen-space drawing - ONLY for Infinite Mode
        if (currentMode == Infinite && levelUpAnimating){
            float t = levelUpTimer / levelUpDuration;
            float animScale = 1.0f + 1.2f * (1.0f - (t>1.0f?1.0f:t));
            int alpha = (int)(255 * (1.0f - (t>1.0f?1.0f:t)));
            unsigned char a8 = (unsigned char)alpha;
            // Darken the game view bounds
            DrawRectangle((int)offsetX, (int)offsetY, (int)drawW, (int)drawH,Fade(BLACK, 0.45f * (1.0f - (t>1.0f?1.0f:t))));
            const char *msg = Localization::getText("level_up");
            Font titleFont = UIFont::getFont(UIFont::TITLE);
            float fs = 48.0f * animScale * uiScl;
            Vector2 textSize = MeasureTextEx(titleFont, msg, fs, 1.0f);
            DrawTextEx(titleFont, msg, (Vector2){offsetX + drawW/2.0f - textSize.x/2.0f, offsetY + drawH/2.0f - fs/2.0f}, fs, 1.0f, (Color){255,220,120, a8});
        }
        
        // XP Progress bar — position depends on mode to avoid overlap
        float xpProg = std::min(1.0f, (float)player.score / (float)nivelMeta);
        float bw = 400.0f * uiScl; float bh = 24.0f * uiScl;
        float bx, by;
        
        if (currentMode == Evolution) {
            // Place XP bar directly below the Evolution HUD stack
            bx = offsetX + 10.0f * uiScl;
            by = evolution.hudBottomY + 4.0f * uiScl;
        } else {
            // Infinite Mode: XP bar at the top
            bx = offsetX + 20.0f * uiScl;
            by = offsetY + 10.0f * uiScl;
        }
        
        // Current Level display for Infinite Mode only (below the XP bar)
        if (currentMode == Infinite) {
            float infoCurY = by + bh + 8.0f * uiScl;
            const char* levelText = TextFormat("%s: %i", Localization::getText("level"), nivel);
            DrawTextEx(uiFont, levelText, (Vector2){offsetX + 20.0f * uiScl, infoCurY}, 14.0f * uiScl, 1.0f, WHITE);
            infoCurY += 20.0f * uiScl;
            
            // Best Score/Highest Level display
            const char* bestFormattedText = TextFormat("Best Level: %i", player.highestLevel);
            DrawTextEx(uiFont, bestFormattedText, (Vector2){offsetX + 20.0f * uiScl, infoCurY}, 14.0f * uiScl, 1.0f, YELLOW);
        }
        
        if (hudVisible) {
            // Background bar (target)
            DrawRectangleRec((Rectangle){bx, by, bw, bh}, Fade(DARKGRAY, 0.6f));
            // Progress bar (XP obtained)
            DrawRectangleRec((Rectangle){bx, by, bw * xpProg, bh}, GREEN);
            // Border
            DrawRectangleLinesEx((Rectangle){bx, by, bw, bh}, 1.0f, WHITE);
            // XP text
            const char* xpText = TextFormat("%i / %i XP", player.score, nivelMeta);
            DrawTextEx(uiFont, xpText, (Vector2){bx + 12.0f * uiScl, by + 4.0f * uiScl}, 14.0f * uiScl, 1.0f, WHITE);
        }
        
        
        EndDrawing();
    }

    UnloadRenderTexture(worldRenderTarget);
    CloseWindow();
}
