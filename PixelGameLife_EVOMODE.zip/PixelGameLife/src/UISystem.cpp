#include "UISystem.h"
#include "raylib.h"
#include <algorithm>
#include <cmath>

// Static member definitions
bool UISystem::s_initialized = false;

void UISystem::initialize() { s_initialized = true; }

float UISystem::getUIScale() {
  const float baseHeight = 1080.0f;
  return std::max(1.0f, GetScreenHeight() / baseHeight);
}

float UISystem::getCenteredTextX(const char *text, float fontSize) {
  Font uiFont = UIFont::getFont(UIFont::UI);
  Vector2 textSize = MeasureTextEx(uiFont, text, fontSize, 1.0f);
  return GetScreenWidth() / 2.0f - textSize.x / 2.0f;
}

void UISystem::renderMainMenu(float menuTimer, int menuSelection,
                              bool showOptions, int optionsSelection) {
  if (!s_initialized)
    return;

  // Background gradient
  DrawRectangleGradientV(0, 0, GetScreenWidth(), GetScreenHeight(),
                         (Color){10, 10, 30, 255}, (Color){25, 25, 60, 255});

  // Background effects
  for (int i = 0; i < 4; ++i) {
    float px = sinf(menuTimer * 0.3f + i) * 100.0f + GetScreenWidth() / 2;
    float py = 100.0f + cosf(menuTimer * 0.4f + i * 0.8f) * 60.0f;
    DrawCircle((int)px, (int)py, 2.0f, Fade(SKYBLUE, 0.3f));
  }

  float uiScale = getUIScale();

  // Title with animation
  float titleScale = 1.0f + 0.08f * sinf(menuTimer * 2.0f);
  const char *title = "Pixel Game Life";
  Font titleFont = UIFont::getFont(UIFont::TITLE);
  float titleFontSize = 60.0f * uiScale;
  Vector2 titleSize = MeasureTextEx(titleFont, title, titleFontSize, 1.0f);
  float titleY = 40 * uiScale + sinf(menuTimer * 1.2f) * 8.0f * uiScale;

  DrawTextEx(titleFont, title,
             (Vector2){getCenteredTextX(title, titleFontSize), titleY},
             titleFontSize, 1.0f, Fade(SKYBLUE, 0.2f));
  DrawTextEx(titleFont, title,
             (Vector2){getCenteredTextX(title, titleFontSize) - 2, titleY - 2},
             titleFontSize, 1.0f, Fade(SKYBLUE, 0.15f));
  DrawTextEx(titleFont, title,
             (Vector2){getCenteredTextX(title, titleFontSize), titleY},
             titleFontSize, 1.0f, SKYBLUE);

  if (!showOptions) {
    // Main menu items
    const char *items[5] = {Localization::getText("infinite_mode"),
                            Localization::getText("evolution_mode"),
                            Localization::getText("instructions"),
                            Localization::getText("achievements"),
                            Localization::getText("quit")};

    int menuX = GetScreenWidth() / 2;
    int menuY = GetScreenHeight() / 2 - 140 * uiScale;

    for (int i = 0; i < 5; i++) {
      int y = menuY + i * 60 * uiScale;
      float wobble =
          1.0f + 0.08f * ((i == menuSelection) ? sinf(menuTimer * 6.0f) : 0.0f);
      Color col = (i == menuSelection) ? GOLD : LIGHTGRAY;
      float itemSize = 32.0f * uiScale;

      if (i == menuSelection) {
        DrawRectangle(menuX - 120 * uiScale, y - 10, 240 * uiScale,
                      50 * uiScale, Fade(GOLD, 0.2f));
      }

      Font uiFont = UIFont::getFont(UIFont::UI);
      Vector2 textSize = MeasureTextEx(uiFont, items[i], itemSize, 1.0f);
      DrawTextEx(uiFont, items[i],
                 (Vector2){(float)(menuX - textSize.x / 2), (float)y}, itemSize,
                 1.0f, col);
    }

    // Help text at bottom
    const char *helpText = Localization::getText("use_up_down");
    float helpFontSize = 12.0f * uiScale;
    DrawTextEx(UIFont::getFont(UIFont::UI), helpText,
               (Vector2){getCenteredTextX(helpText, helpFontSize),
                         (float)(GetScreenHeight() - 50) * uiScale},
               helpFontSize, 1.0f, Fade(GRAY, 0.8f));
  }
}

void UISystem::renderPauseMenu(float menuTimer, int pauseSelection) {
  if (!s_initialized)
    return;

  // Background gradient
  DrawRectangleGradientV(0, 0, GetScreenWidth(), GetScreenHeight(),
                         (Color){10, 10, 30, 255}, (Color){25, 25, 60, 255});

  float uiScale = getUIScale();

  // Title
  const char *pauseTitle = Localization::getText("paused");
  Font titleFont = UIFont::getFont(UIFont::TITLE);
  float titleFontSize = 60.0f * uiScale;
  Vector2 pauseSize = MeasureTextEx(titleFont, pauseTitle, titleFontSize, 1.0f);
  DrawTextEx(
      titleFont, pauseTitle,
      (Vector2){getCenteredTextX(pauseTitle, titleFontSize), 80.0f * uiScale},
      titleFontSize, 1.0f, GOLD);

  // Menu items
  const char *pauseItems[3] = {Localization::getText("resume"),
                               Localization::getText("menu"),
                               Localization::getText("quit")};
  Font uiFont = UIFont::getFont(UIFont::UI);

  for (int i = 0; i < 3; i++) {
    int y = 200 + i * 80;
    float scaledY = y * uiScale;
    Color col = (i == pauseSelection) ? GOLD : LIGHTGRAY;
    float sz = (i == pauseSelection) ? 32.0f : 28.0f;
    float scaledSz = sz * uiScale;

    if (i == pauseSelection) {
      DrawRectangle(GetScreenWidth() / 2 - 100 * uiScale, scaledY - 10,
                    200 * uiScale, 50 * uiScale, Fade(GOLD, 0.2f));
    }

    Vector2 textSize = MeasureTextEx(uiFont, pauseItems[i], scaledSz, 1.0f);
    DrawTextEx(uiFont, pauseItems[i],
               (Vector2){(float)(GetScreenWidth() / 2 - textSize.x / 2),
                         (float)scaledY},
               scaledSz, 1.0f, col);
  }
}

void UISystem::renderGameOverMenu(float menuTimer, const char *gameOverMessage,
                                  int level, int score) {
  if (!s_initialized)
    return;

  // Background gradient
  DrawRectangleGradientV(0, 0, GetScreenWidth(), GetScreenHeight(),
                         (Color){10, 10, 30, 255}, (Color){25, 25, 60, 255});

  float uiScale = getUIScale();
  float scale = 1.0f + 0.08f * sinf(menuTimer * 2.0f);

  // Game over message
  Font titleFont = UIFont::getFont(UIFont::TITLE);
  float titleFontSize = 80.0f * uiScale;
  Vector2 diedSize =
      MeasureTextEx(titleFont, gameOverMessage, titleFontSize, 1.0f);
  DrawTextEx(titleFont, gameOverMessage,
             (Vector2){getCenteredTextX(gameOverMessage, titleFontSize),
                       100.0f * uiScale},
             titleFontSize, 1.0f, RED);

  // Level and score
  Font uiFont = UIFont::getFont(UIFont::UI);
  float uiFontSize = 28.0f * uiScale;
  const char *levelText =
      TextFormat("%s: %i", Localization::getText("level"), level);
  DrawTextEx(
      uiFont, levelText,
      (Vector2){getCenteredTextX(levelText, uiFontSize), 220.0f * uiScale},
      uiFontSize, 1.0f, WHITE);

  // Instructions
  float buttonFontSize = 24.0f * uiScale;
  const char *retryText = Localization::getText("press_r_retry");
  const char *menuText = Localization::getText("press_m_menu");

  DrawTextEx(
      uiFont, retryText,
      (Vector2){getCenteredTextX(retryText, buttonFontSize), 420.0f * uiScale},
      buttonFontSize, 1.0f,
      ((((int)(menuTimer * 4)) % 2) == 0) ? YELLOW : LIGHTGRAY);
  DrawTextEx(
      uiFont, menuText,
      (Vector2){getCenteredTextX(menuText, buttonFontSize), 470.0f * uiScale},
      buttonFontSize, 1.0f, LIGHTGRAY);
}

void UISystem::renderTutorialScreen(float menuTimer) {
  if (!s_initialized)
    return;

  // Background gradient
  DrawRectangleGradientV(0, 0, GetScreenWidth(), GetScreenHeight(),
                         (Color){10, 10, 30, 255}, (Color){25, 25, 60, 255});

  float uiScale = getUIScale();

  // Title
  const char *tutTitle = Localization::getText("quick_start");
  Font titleFont = UIFont::getFont(UIFont::TITLE);
  float tutTitleFontSize = 50.0f * uiScale;
  Vector2 tutSize = MeasureTextEx(titleFont, tutTitle, tutTitleFontSize, 1.0f);
  DrawTextEx(titleFont, tutTitle,
             (Vector2){getCenteredTextX(tutTitle, tutTitleFontSize),
                       (float)(GetScreenHeight() / 8)},
             tutTitleFontSize, 1.0f, GOLD);

  // Tutorial steps
  int y = 120;
  int lineHeight = 35;
  Font uiFont = UIFont::getFont(UIFont::UI);
  float titleFontSize = 20.0f * uiScale;
  float descFontSize = 14.0f * uiScale;

  // Tutorial content with proper centering
  const char *tutorials[][2] = {
      {Localization::getText("tutorial_grow_cell"),
       Localization::getText("tutorial_grow_cell_desc")},
      {Localization::getText("tutorial_avoid_dangers"),
       Localization::getText("tutorial_avoid_dangers_desc")},
      {Localization::getText("tutorial_level_up"),
       Localization::getText("tutorial_level_up_desc")},
      {Localization::getText("tutorial_gameplay_controls"),
       Localization::getText("tutorial_gameplay_controls_desc")}};

  for (int i = 0; i < 4; i++) {
    float tX = getCenteredTextX(tutorials[i][0], titleFontSize);
    float dX = getCenteredTextX(tutorials[i][1], descFontSize);
    DrawTextEx(uiFont, tutorials[i][0],
               (Vector2){tX, (float)(y + i * lineHeight * 2) * uiScale},
               titleFontSize, 1.0f,
               (i == 0)   ? SKYBLUE
               : (i == 1) ? LIME
               : (i == 2) ? YELLOW
                          : ORANGE);
    DrawTextEx(uiFont, tutorials[i][1],
               (Vector2){dX, (float)(y + i * lineHeight * 2 + 25) * uiScale},
               descFontSize, 1.0f, LIGHTGRAY);
  }

  // Instructions at bottom
  float blink = (((int)(menuTimer * 3)) % 2 == 0) ? 1.0f : 0.5f;
  float startFontSize = 16.0f * uiScale;
  const char *startText = Localization::getText("press_space_start");
  DrawTextEx(uiFont, startText,
             (Vector2){getCenteredTextX(startText, startFontSize),
                       (float)(GetScreenHeight() - 60) * uiScale},
             startFontSize, 1.0f, Fade(YELLOW, blink));
}

void UISystem::renderAchievementsScreen(
    int scrollOffset, const std::vector<class Achievement> &achievements) {
  if (!s_initialized)
    return;

  // Background gradient
  DrawRectangleGradientV(0, 0, GetScreenWidth(), GetScreenHeight(),
                         (Color){10, 10, 30, 255}, (Color){25, 25, 60, 255});

  float uiScale = getUIScale();

  // Title
  const char *achTitle = Localization::getText("achievements");
  Font titleFont = UIFont::getFont(UIFont::TITLE);
  float titleFontSize = 40.0f * uiScale;
  Vector2 achTitleSize =
      MeasureTextEx(titleFont, achTitle, titleFontSize, 1.0f);
  DrawTextEx(
      titleFont, achTitle,
      (Vector2){getCenteredTextX(achTitle, titleFontSize), 20.0f * uiScale},
      titleFontSize, 1.0f, GOLD);

  // Achievement list
  int ach_y = 80;
  int ach_line_h = 48;
  int maxAchievementsVisible =
      (GetScreenHeight() - 140 * uiScale) / (ach_line_h * uiScale);

  Font uiFont = UIFont::getFont(UIFont::UI);
  float achievementFontSize = 16.0f * uiScale;

  for (int i = 0; i < maxAchievementsVisible &&
                  (i + scrollOffset) < (int)achievements.size();
       i++) {
    const auto &ach = achievements[i + scrollOffset];
    Color col = ach.unlocked ? GOLD : DARKGRAY;

    // Achievement box
    float boxWidth = GetScreenWidth() * 0.8f;
    float boxStart = GetScreenWidth() / 2.0f - boxWidth / 2.0f;
    DrawRectangle(boxStart, (ach_y + i * ach_line_h) * uiScale, boxWidth,
                  40 * uiScale, Fade(col, 0.2f));

    // Achievement text
    float nameX = getCenteredTextX(ach.name.c_str(), achievementFontSize);
    DrawTextEx(uiFont, ach.name.c_str(),
               (Vector2){nameX, (float)(ach_y + i * ach_line_h + 5) * uiScale},
               achievementFontSize, 1.0f, col);

    float descX =
        getCenteredTextX(ach.description.c_str(), achievementFontSize * 0.8f);
    DrawTextEx(uiFont, ach.description.c_str(),
               (Vector2){descX, (float)(ach_y + i * ach_line_h + 25) * uiScale},
               achievementFontSize * 0.8f, 1.0f, LIGHTGRAY);
  }
}
