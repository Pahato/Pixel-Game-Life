#pragma once

// Upgrade types for Evolution Mode skill system
enum UpgradeType {
    ORBIT_BLADES,       // Two rotating blades around player
    CONE_BLAST,         // Periodic frontal cone AoE
    CHAIN_LIGHTNING,    // Projectile hit chains to nearby enemies
    EXPLOSIVE_KILLS,    // Enemy death causes AoE explosion
    RICOCHET_SHOTS,     // Projectiles bounce to a second target
    MULTISHOT,          // Fire 3 projectiles instead of 1
    ENERGY_SHIELD,      // Absorbs 1 hit, recharges after 8s
    REPULSION_PULSE,    // Periodic knockback pulse
    FROST_FIELD,        // Aura that slows nearby enemies
    BLACK_HOLE,         // Periodic gravity well that pulls enemies
    METEOR_STRIKE,      // Random meteors fall near player
    OVERLOAD,           // Periodic electric AoE burst
    UPGRADE_TYPE_COUNT  // Sentinel for iteration
};
