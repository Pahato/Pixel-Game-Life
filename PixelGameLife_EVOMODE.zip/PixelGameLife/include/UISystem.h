#pragma once
#include "raylib.h"
#include "Localization.h"
#include "AchievementSystem.h"
#include <vector>
#include "UIFont.h"

class UISystem {
public:
    // Initialize UI system
    static void initialize();
    
    // Render main menu
    static void renderMainMenu(float menuTimer, int menuSelection, bool showOptions, int optionsSelection);
    
    // Render pause menu
    static void renderPauseMenu(float menuTimer, int pauseSelection);
    
    // Render game over menu
    static void renderGameOverMenu(float menuTimer, const char* gameOverMessage, int level, int score);
    
    // Render tutorial screen
    static void renderTutorialScreen(float menuTimer);
    
    // Render achievements screen
    static void renderAchievementsScreen(int scrollOffset, const std::vector<class Achievement>& achievements);
    
    // Calculate UI scaling based on window size
    static float getUIScale();
    
private:
    static bool s_initialized;
    
    // Helper function to center text horizontally
    static float getCenteredTextX(const char* text, float fontSize);
};
