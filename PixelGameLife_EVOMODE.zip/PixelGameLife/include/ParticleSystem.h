#pragma once
#include "raylib.h"
#include <vector>

struct Particle {
    float x, y;
    float vx, vy;
    float life;
    float maxLife;
    int r, g, b, a;
};

class ParticleSystem {
public:
    // Initialize particle system
    static void initialize();
    
    // Spawn particles at position
    static void spawnParticles(float x, float y, int count, int r, int g, int b, int a = 255);
    
    // Spawn enemy death particles
    static void spawnEnemyParticles(float x, float y, int r, int g, int b);
    
    // Update all particles
    static void update(float deltaTime);
    
    // Draw all particles
    static void draw();
    
    // Clear all particles
    static void clear();
    
    // Get particle count
    static size_t getParticleCount();
    
private:
    static std::vector<Particle> s_particles;
    static bool s_initialized;
};
