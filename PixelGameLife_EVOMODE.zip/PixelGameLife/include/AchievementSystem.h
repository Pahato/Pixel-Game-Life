#pragma once
#include <string>
#include <vector>

struct Achievement {
    std::string id;           // unique ID
    std::string name;         // display name
    std::string description;  // description
    bool unlocked;
    Achievement() {}
    Achievement(const std::string& i, const std::string& n, const std::string& d) 
        : id(i), name(n), description(d), unlocked(false) {}
};

class AchievementSystem {
public:
    // Initialize achievement system
    static void initialize();
    
    // Check and unlock achievements based on game state
    static void checkAchievements(int level, int score, int enemiesKilled, float timeAlive);
    
    // Get all achievements
    static const std::vector<Achievement>& getAchievements();
    
    // Get count of unlocked achievements
    static int getUnlockedCount();
    
    // Reset achievements (for new session)
    static void reset();
    
private:
    static std::vector<Achievement> s_achievements;
    static bool s_initialized;
    static int s_totalEnemiesKilled;
    static int s_currentLevelEnemiesKilled;
    
    // Initialize default achievements
    static void initializeDefaultAchievements();
};
