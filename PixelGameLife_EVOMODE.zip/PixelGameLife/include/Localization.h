#pragma once
#include "raylib.h"
#include <string>
#include <unordered_map>
#include "UpgradeType.h"

enum Language {
    LANG_ENGLISH,
    LANG_PORTUGUESE
};

// Forward declaration for UpgradeType
//enum UpgradeType;

class Localization {
public:
    static void setLanguage(Language lang);
    static Language getCurrentLanguage();
    static const char* getText(const std::string& key);
    
    // Helper functions for upgrade names and descriptions
    static const char* getUpgradeName(UpgradeType type);
    static const char* getUpgradeDescription(UpgradeType type);
    
    static void initialize();
    
private:
    static Language s_currentLanguage;
    static std::unordered_map<std::string, std::string> s_texts;
    
    static void loadEnglishTexts();
    static void loadPortugueseTexts();
};
