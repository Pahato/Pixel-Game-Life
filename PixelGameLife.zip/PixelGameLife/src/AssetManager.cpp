#include "../include/AssetManager.h"
#include <filesystem>
#include <iostream>

// Static member definitions
std::unordered_map<std::string, Texture2D> AssetManager::s_sprites;
std::unordered_map<std::string, Image> AssetManager::s_images;
bool AssetManager::s_initialized = false;

void AssetManager::initialize() {
    if (s_initialized) return;
    
    initializeSpriteMappings();
    s_initialized = true;
}

void AssetManager::initializeSpriteMappings() {
    printf("[DEBUG] Initializing sprite mappings...\n");
    
    // Player sprites
    loadSprite("player", "Sprites/Player_sprite.png");
    
    // Enemy sprites - Infinite Mode
    loadSprite("enemy_dangerous", "Sprites/InfiniteModeDangerousEnemy_sprite.png");
    loadSprite("enemy_safe", "Sprites/InfiniteModeNonDangerousEnemy_sprite.png");
    
    // Enemy sprites - Evolution Mode
    loadSprite("enemy_tank", "Sprites/TankEnemyEvolutionMode_sprite.png");
    
    // Projectile sprites
    loadSprite("projectile", "Sprites/Projetil_sprite.png");
    loadSprite("projectile_multishot", "Sprites/MultishotsSameAsNormalProjectileJustSpamItAsMultiShotGetsEvolved_sprite.png");
    
    // Effect sprites
    loadSprite("explosion", "Sprites/ExplosiveKills_sprite.png");
    loadSprite("frost_field", "Sprites/FrostField_sprite.png");
    loadSprite("black_hole", "Sprites/BlackHole_sprite.png");
    loadSprite("chain_lightning", "Sprites/ChainLighting_sprite.png");
    loadSprite("cone_blast", "Sprites/ConeBlast_sprite.png");
    
    // Ability sprites
    loadSprite("energy_shield", "Sprites/EnergyShieldChangeThePlayerSpriteForThis_sprite.png");
    
    // Environment sprites
    loadSprite("meteor", "Sprites/MeteorStrike_sprite.png");
    
    // Orbital blade upgrade sprites
    loadSprite("orbital_blades_0", "Sprites/OrbitBladesUpgradeZero_sprite.png");
    loadSprite("orbital_blades_1", "Sprites/OrbitBladesUpgradeOne_sprite.png");
    loadSprite("orbital_blades_2", "Sprites/OrbitalBladesUpgradeTwo_sprite.png");
    loadSprite("orbital_blades_3", "Sprites/OrbitalBladesUpgradeThree_sprite.png");
    loadSprite("orbital_blades_4", "Sprites/OrbitalBladesUpgradeFour_sprite.png");
    loadSprite("orbital_blades_5", "Sprites/OrbitalBladesUpgradeFive_sprite.png");
    loadSprite("orbital_blades_6", "Sprites/OrbitalBladesUpgradeSix_sprite.png");
    
    // Other ability sprites
    loadSprite("overload", "Sprites/Overload_sprite.png");
    loadSprite("repulsion_pulse", "Sprites/RepulsionPulse_sprite.png");
    loadSprite("ricochet_shots", "Sprites/RicochetShots_sprite.png");
    
    printf("[DEBUG] Sprite initialization complete. Total sprites loaded: %d\n", (int)s_sprites.size());
}

bool AssetManager::loadSprite(const std::string& key, const std::string& filename) {
    if (s_sprites.find(key) != s_sprites.end()) {
        return true; // Already loaded
    }
    
    // Load image first (works without OpenGL context)
    Image image = LoadImage(filename.c_str());
    if (image.data == NULL) {
        printf("[DEBUG] FAILED to load image: %s from %s\n", key.c_str(), filename.c_str());
        return false;
    }
    
    // Store the image for later texture conversion
    s_images[key] = image;
    return true;
}

Texture2D AssetManager::getSprite(const std::string& key) {
    auto it = s_sprites.find(key);
    if (it != s_sprites.end()) {
        return it->second;
    }
    
    return Texture2D{0}; // Return empty texture instead of invalid
}

int AssetManager::getSpriteCount() {
    return (int)s_sprites.size();
}

void AssetManager::convertImagesToTextures() {
    printf("[DEBUG] Converting images to textures...\n");
    
    for (auto& pair : s_images) {
        const std::string& key = pair.first;
        Image& image = pair.second;
        
        printf("[DEBUG] Converting %s to texture\n", key.c_str());
        Texture2D texture = LoadTextureFromImage(image);
        if (texture.id > 0) {
            s_sprites[key] = texture;
            printf("[DEBUG] Successfully converted %s to texture (id: %d)\n", key.c_str(), texture.id);
        } else {
            printf("[DEBUG] FAILED to convert %s to texture\n", key.c_str());
        }
        
        // Unload the image after conversion
        UnloadImage(image);
    }
    
    // Clear the images map
    s_images.clear();
    printf("[DEBUG] Texture conversion complete. Total textures: %d\n", (int)s_sprites.size());
}

bool AssetManager::hasSprite(const std::string& key) {
    return s_sprites.find(key) != s_sprites.end();
}

Color AssetManager::getFallbackColor(const std::string& key) {
    // Return appropriate fallback colors for missing sprites
    if (key.find("player") != std::string::npos) return BLACK;
    if (key.find("enemy") != std::string::npos) return RED;
    if (key.find("projectile") != std::string::npos) return YELLOW;
    if (key.find("explosion") != std::string::npos) return ORANGE;
    if (key.find("frost") != std::string::npos) return SKYBLUE;
    if (key.find("shield") != std::string::npos) return GREEN;
    if (key.find("black_hole") != std::string::npos) return PURPLE;
    if (key.find("lightning") != std::string::npos) return WHITE;
    if (key.find("cone") != std::string::npos) return GOLD;
    if (key.find("meteor") != std::string::npos) return GRAY;
    
    return WHITE; // Default fallback
}

void AssetManager::cleanup() {
    for (auto& pair : s_sprites) {
        UnloadTexture(pair.second);
    }
    s_sprites.clear();
    s_initialized = false;
}
