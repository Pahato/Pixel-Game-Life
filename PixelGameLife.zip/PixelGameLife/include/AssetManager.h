#pragma once
#include "raylib.h"
#include <unordered_map>
#include <string>

class AssetManager {
public:
    // Initialize asset manager and load all sprites
    static void initialize();
    
    // Get sprite texture by key
    static Texture2D getSprite(const std::string& key);
    
    // Check if sprite exists
    static bool hasSprite(const std::string& key);
    
    // Cleanup all loaded textures
    static void cleanup();
    
    // Get fallback color for missing sprites
    static Color getFallbackColor(const std::string& key);
    
    // Get the number of loaded sprites
    static int getSpriteCount();
    
    // Convert loaded images to textures (call after InitWindow)
    static void convertImagesToTextures();
    
private:
    static std::unordered_map<std::string, Texture2D> s_sprites;
    static std::unordered_map<std::string, Image> s_images;
    static bool s_initialized;
    
    // Load individual sprite
    static bool loadSprite(const std::string& key, const std::string& filename);
    
    // Initialize sprite key mappings
    static void initializeSpriteMappings();
};
