#pragma once

#include "raylib.h"

#include "Populacao.h"

#include "Ambiente.h"

#include "Collision.h"

#include "Transition.h"

#include "Localization.h"

#include "LanguageSelector.h"

#include "UIFont.h"

#include "UpgradeType.h"

#include "ParticleSystem.h"

#include "UISystem.h"

#include "AchievementSystem.h"

#include "AssetManager.h"

#include <vector>

#include <string>



// Base game resolution removed to unify with WORLD dimensions.



// Original fixed map dimensions

const int WORLD_W = 900;

const int WORLD_H = 600;



struct Player {

    float x,y;

    float speed;

    float radius; // hole radius

    int score;

    int highestLevel;

    std::string spriteKey; // Key for AssetManager

    Player(): x(WORLD_W/2), y(WORLD_H/2), speed(180.0f), radius(12.0f), score(0), highestLevel(1), spriteKey("player") {}

    void update(float dt){ }

};



// Achievement struct moved to AchievementSystem.h



// Theme structure for visual theming

struct Theme {

    Color bg1, bg2;           // Background gradient colors

    Color bubble1, bubble2, bubble3; // Bubble layer colors

    Color accent;            // Accent color

};



// Game modes

enum GameMode { Infinite, Evolution };



struct Simulador {



    

    int width, height;  // Fixed world dimensions (should match WORLD_W/WORLD_H)

    int windowWidth, windowHeight;  // Current window dimensions

    RenderTexture2D worldRenderTarget;  // Render target for fixed world size

    

    bool running;

    bool showMenu;

    bool showOptions;

    bool showTutorial;  // tutorial screen

    bool pauseMenu;

    bool gameOver;

    bool isFullscreen;

    int menuSelection;

    int pauseSelection;

    int optionsSelection;

    int initialPopulation;

    // resources and spawn

    struct Resource { float x,y; float value; bool active; int tier; float sizeRadius; int points; };

    std::vector<Resource> resources;

    float resourceTimer;

    bool firstSpawnDone;

    int currentSpeedIndex;  // 0=lenta(0.5x), 1=media(1.0x), 2=rapida(2.0x)

    Populacao pop;

    Ambiente amb;

    Player player;

    // Particle system moved to ParticleSystem.h

    

    // Evolution Mode projectiles and effects

    struct Projectile {

        float x, y;

        float vx, vy;

        float radius;

        int damage;

        bool alive;

        Color color;

        bool hasRicocheted; // For ricochet skill tracking

        std::string spriteKey; // Key for AssetManager

    };

    std::vector<Projectile> projectiles;

    

    struct VisualEffect {

        float x, y;

        float radius;

        float maxRadius;

        float life;

        float maxLife;

        Color color;

        int type; // 0=expanding ring, 1=shrinking burst, 2=basic attack, 3=explosion, 4=electric, 5=meteor impact, 6=repulsion ring

        std::string spriteKey; // Key for AssetManager

    };

    std::vector<VisualEffect> visualEffects;

    

    // Chain lightning visual segments

    struct ChainSegment {

        float x1, y1, x2, y2;

        float life;

    };

    std::vector<ChainSegment> chainSegments;
    
    // Active meteors
    struct Meteor {
        float x, y;
        float targetX, targetY;
        float progress; // 0 to 1 animation
        float radius;
        bool active;
    };

    std::vector<Meteor> meteors;
    
    std::vector<Enemy> enemies;
    std::vector<Particle> particles;
    std::vector<Achievement> achievements;

    float menuTimer;

    float menuInputCooldown;

    float timeAlive;

    int nivel;

    int nivelMeta; // score target for level

    // level-up animation

    bool levelUpAnimating;

    float levelUpTimer;

    float levelUpDuration;

    // player highlight for new level

    bool playerHighlightActive;

    float playerHighlightTimer;

    float playerHighlightDuration;

    

    // Biome system for Infinite Mode

    enum BiomeType { NONE, BLOODSTREAM, TISSUE, NEURAL };

    BiomeType currentBiome;

    float biomeEnemySpeedMultiplier;

    Color biomeBackgroundColor;

    

    // Random game over message

    std::string currentGameOverMessage;

    

    // Achievements scrolling

    int achievementsScrollOffset;

    int maxAchievementsVisible;

    // background / scene

    float bgOffset;

    float screenShake;

    float screenShakeTimer;

    // debug mode for hitbox visualization

    bool debugHitboxes;

    

    // Evolution Mode state

    GameMode currentMode;

    struct EvolutionState {

        bool isActive;

        float runStartTime;

        float survivalTime;

        int enemiesKilled;

        int xpCollected;

        int playerLevel;

        int currentWave;

        float nextDifficultyTime;

        float difficultyMultiplier;

        bool upgradeMenuVisible;

        bool showVictoryScreen;

        int victoryScreenSelection;

        int selectedUpgradeIndex;

        std::vector<int> currentUpgrades; // Applied upgrade IDs

        std::vector<int> currentUpgradeChoices; // Current 3 choices

        

        // Skill levels — 0 = not owned, 1-5 = upgrade level

        static const int MAX_SKILL_LEVEL = 5;

        int skillLevel[UPGRADE_TYPE_COUNT];

        

        // Active skill states

        // Orbit Blades

        float orbitAngle;

        

        // Cone Blast

        float coneBlastTimer;

        float coneBlastAngle; // direction player last moved

        

        // Energy Shield

        bool shieldUp;

        float shieldRechargeTimer;

        

        // Repulsion Pulse

        float repulsionTimer;

        

        // Black Hole

        float blackHoleTimer;

        float blackHoleX, blackHoleY;

        float blackHoleLife;

        bool blackHoleActive;

        

        // Meteor Strike

        float meteorTimer;

        

        // Overload

        float overloadTimer;

        

        // Basic attack system

        float basicAttackCooldown;

        float basicAttackTimer;

        

        // Boss system

        bool bossWave;

        int enemiesInWave;

        int enemiesSpawned;

        

        // Spawn system

        float spawnTimer;

        

        // HUD layout helper (set by renderEvolutionUI, used by XP bar)

        float hudBottomY;

        

        // Random map generation

        struct MapZone {

            float x, y, width, height;

            Color zoneColor;

            int zoneType; // 0=open, 1=dense, 2=special

        };

        std::vector<MapZone> mapZones;

        int mapSeed;

    } evolution;

    

    // Upgrade system for Evolution Mode

    // UpgradeType enum moved to UpgradeType.h

    

    struct Upgrade {

        UpgradeType type;

        std::string name;

        std::string description;

        float value;

        int level;

    };

    

    // Achievement system moved to AchievementSystem.h

    // Particle system moved to ParticleSystem.h

    // UI system moved to UISystem.h

    // Core game functions

    void initializeGame();

    void updateGame(float deltaTime);

    void renderGame();

    void handleInput();

    void renderHUD();

    

    // Restored methods

    void spawnParticles(float x, float y, int count, int r, int g, int b, int a = 255);

    void spawnEnemyParticles(float x, float y, Color enemyColor);

    void drawEnemyFace(float x, float y, float radius, int eyeType, int mouthType, int extraType);

    void checkAchievements();

    

    // Sprite rendering helpers

    void drawSprite(const std::string& spriteKey, float x, float y, float width, float height, float rotation = 0.0f, Color tint = WHITE);

    void drawEntityWithSprite(const std::string& spriteKey, float x, float y, float radius, Color fallbackColor, float rotation = 0.0f);

    

    // Evolution Mode functions

    void initializeEvolution();

    void updateEvolution(float deltaTime);

    void renderEvolutionUI();

    void renderUpgradeMenu();

    std::string getSkillStatsDescription(UpgradeType type, int level);

    void drawTextWithHighlights(Font font, const char* text, Vector2 pos, float size, Color baseCol, Color highlightCol);

    void handleUpgradeMenuInput();



    void generateUpgradeChoices();

    void applyUpgrade(UpgradeType type);

    

    // Evolution Mode gameplay systems

    void updateProjectiles(float deltaTime);

    void updateVisualEffects(float deltaTime);

    void fireBasicAttack();

    void spawnEvolutionEnemy(bool isBoss = false);

    void renderEvolutionWorld();

    void updateSkills(float deltaTime);

    void renderSkills();

    

    // Random map generation

    void generateRandomMap();

    void renderMapZones();

    

    // Utility functions

    void returnToMainMenu();

    void resumeFromPauseMenu();

    void selectRandomGameOverMessage();

    void toggleFullscreen();

    void setWindowSize(int w, int h);

    void renderMenusAndUI(float delta);

    void renderVictoryScreen();

    void handleVictoryScreenInput();

    

    // Constructor and destructor

    Simulador(int w=WORLD_W,int h=WORLD_H);

    ~Simulador();

    void run();

};

