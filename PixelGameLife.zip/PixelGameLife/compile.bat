@echo off
echo Compilando Pixel Game Life (modo rapido)...

set "PATH=C:\raylib\w64devkit\bin;%PATH%"

tasklist /FI "IMAGENAME eq PixelGameLife.exe" /NH | findstr /I "PixelGameLife.exe" >nul
if %ERRORLEVEL%==0 (
    echo Removendo executavel antigo...
    taskkill /F /IM "PixelGameLife.exe" /T 2>nul
    timeout /T 2 /nobreak >nul
    if exist "PixelGameLife.exe" del "PixelGameLife.exe"
    if exist "PixelGameLife.exe" (
        echo Falha ao remover executavel antigo
        pause
        exit /b 1
    )
    echo Executavel antigo removido com sucesso.
)

echo Compilando arquivos fonte...
"C:\raylib\w64devkit\bin\g++.exe" -std=c++17 -O2 -Wall -Iinclude -Isrc ^
    src/Ambiente.cpp ^
    src/AssetManager.cpp ^
    src/Collision.cpp ^
    src/HatSystem.cpp ^
    src/LanguageSelector.cpp ^
    src/Localization.cpp ^
    src/Organismo.cpp ^
    src/ParticleSystem.cpp ^
    src/Populacao.cpp ^
    src/Shop.cpp ^
    src/Simulador.cpp ^
    src/SpeedManager.cpp ^
    src/Transition.cpp ^
    src/UIFont.cpp ^
    src/UISystem.cpp ^
    src/AchievementSystem.cpp ^
    main.cpp ^
    -o PixelGameLife.exe ^
    -lraylib -lopengl32 -lgdi32 -lwinmm -lkernel32 -luser32

if %ERRORLEVEL% neq 0 (
    echo Falha na compilacao - codigo de erro %ERRORLEVEL%
    pause
    exit /b %ERRORLEVEL%
)

echo.
echo ========================================
echo Compilacao concluida com sucesso!
echo Novo executavel criado: PixelGameLife.exe
echo ========================================
echo.
echo Para iniciar o jogo manualmente, execute:
echo PixelGameLife.exe
echo.
pause
