@echo off
echo Criando release do Pixel Game Life...

REM Verifica se o executavel existe
if not exist "PixelGameLife.exe" (
    echo ERRO: PixelGameLife.exe nao encontrado. Execute build.bat primeiro.
    pause
    exit /b 1
)

REM Cria pasta de release
if exist "release" (
    echo Removendo pasta release anterior...
    rmdir /s /q "release"
)
mkdir "release"

REM Copia executavel
echo Copiando executavel...
copy "PixelGameLife.exe" "release\"

REM Copia assets necessarios
echo Copiando assets...
xcopy "Sprites" "release\Sprites\" /E /I /Y

REM Copia arquivos de dados
if exist "achievements.txt" copy "achievements.txt" "release\"
if exist "highscore.txt" copy "highscore.txt" "release\"
if exist "save.csv" copy "save.csv" "release\"

REM Copia arquivos de localizacao se existirem
if exist "Localization" xcopy "Localization" "release\Localization\" /E /I /Y

echo.
echo Release criado com sucesso!
echo Pasta: release\
echo Executavel: release\PixelGameLife.exe
echo.
echo NOTA: O jogo pode precisar de DLLs do MinGW para funcionar em outros PCs.
echo.
pause
